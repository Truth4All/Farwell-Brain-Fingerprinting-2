﻿using System;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.Windows.Forms;
using System.ComponentModel;
using System.Threading;
using System.Collections.Generic;
using BWS.WebServices;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System.DirectoryServices.AccountManagement;
using System.Data;

namespace BWS.WebServicesTest
{
    public partial class Form1 : Form
    {
        ChannelFactory<ISynchro> channelFactory = null;
        EndpointAddress ep = null;
        ISynchro serviceObject = null;

        Uri discoveredAddress;

        string DocumentsFolder  = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\";
        string LocalCatalog     = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\Catalog.xml";
        string TempCatalog      = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\temp\Catalog.xml";
        string CatalogSchema    = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)          + @"\Brainwave\config\Catalog.xsd";
        string FolioSchema      = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)          + @"\Brainwave\config\BrainWave_DB.xsd";


      


        public Form1()
        {
            InitializeComponent();

            BrainwaveServer_tbx.Text        = Registry.GetRegistryValue("BrainwaveServer").ToString();
            Domain_tbx.Text                 = Registry.GetRegistryValue("Domain").ToString();
            DomainAttached_cbx.Checked      = Registry.GetBooleanRegistryValue("DomainAttached");
            HeadSetMAC_tbx.Text             = Registry.GetRegistryValue("HeadSetMAC").ToString();
            Internet_cbx.Checked            = Registry.GetBooleanRegistryValue("Internet");
            LCID_tbx.Text                   = Registry.GetRegistryValue("LCID").ToString();
            RunTimeSecurity_tbx.Text        = Registry.GetRegistryValue("RunTimeSecurity").ToString();
            RunTimeTarget_tbx.Text          = Registry.GetRegistryValue("RunTimeTarget").ToString();

            // Disable buttons
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;

            textBox4.Text = "f7254b15-105e-4457-992b-2f27a2d3e68e";
            textBox5.Text = "f7254b15-105e-4457-992b-2f27a2d3e68e";
            textBox6.Text = "HOSTNAME-007";
            textBox7.Text = "HOSTNAME-007";

            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(this.bw_DoWork);
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.bw_RunWorkerCompleted);
            bw.RunWorkerAsync();
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            channelFactory.Close();
        }

        static Uri FindBrainwaveServerAddress()
        {
            // Create the DiscoveryClient
            DiscoveryClient discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
            // Find Syncho endpoints
            FindCriteria FCriteria = new FindCriteria();
            FCriteria.ScopeMatchBy.Equals("BWS.WebServices.Synchro");
            FindResponse findResponse = discoveryClient.Find(FCriteria);
            if (findResponse.Endpoints.Count > 0)
            {
                return findResponse.Endpoints[0].Address.Uri;
            }
            else
            {
                return null;
            }
        }

        private void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            discoveredAddress = FindBrainwaveServerAddress();
        }

        private void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Open Channel
            ServerUri.Text = discoveredAddress.GetLeftPart(UriPartial.Authority).ToString() + @"/Synchro/"; 
            //ServerUri.Text = @"net.tcp://192.168.5.119:8787/Synchro/";
            //ServerUri.Text = @"net.tcp://thierry-007:8787/Synchro/";
            //ServerUri.Text = BrainwaveServer_tbx.Text;


            X509Certificate2 certificate = new X509Certificate2(@"C:\Program Files\Brainwave\config\BrainwaveServerSecurity.pfx", "c3xQT6Z2");

            ep = new EndpointAddress(ServerUri.Text);
            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.MaxReceivedMessageSize = int.MaxValue; // The ObjectMap is long !!! over 16,000. objects for 60 cases
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            // Enable buttons
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = serviceObject.GetServerHostName().ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Text = serviceObject.GetServerIP();
        }

        private void button3_Click(object sender, EventArgs e) // Get Catalog
        {
            textBox3.Text = "";
            string _UserSID = UserPrincipal.Current.Sid.ToString();
            string _machineName = System.Environment.MachineName.ToString();

            var fileStream = File.Create(TempCatalog);
            Stream FolioStream = serviceObject.GetCatalogFile(_UserSID, _machineName);
            FolioStream.CopyTo(fileStream);
            fileStream.Close();
            textBox3.Text = "Catalog Received";
        }

        private void button4_Click(object sender, EventArgs e) // Get Folio
        {
            textBox3.Text = "";
            string _UserSID = UserPrincipal.Current.Sid.ToString();
            string _machineName = System.Environment.MachineName.ToString();

            var fileStream = File.Create(String.Format(@"{0}{1}.xml", DocumentsFolder, textBox4.Text));
            Stream FolioStream = serviceObject.GetCaseFolio(textBox4.Text, _UserSID, _machineName);
            FolioStream.CopyTo(fileStream);
            fileStream.Close();
            textBox3.Text = "Received";
        }

        private void button5_Click(object sender, EventArgs e) // Save Folio
        {
            textBox3.Text = "";

            string _CaseGUID = textBox5.Text;
            string _JurisdictionID = "";
            string _CaseName = "";
            string _CaseSummary = "";
            string _UserSID = UserPrincipal.Current.Sid.ToString();
            string _MachineName = System.Environment.MachineName.ToString();

            // Read the Folio
            string SourceFile = String.Format("{0}{1}.xml", DocumentsFolder, _CaseGUID);
            DataSet DS = new DataSet();
            DS.ReadXmlSchema(FolioSchema);
            DS.EnforceConstraints = false;
            DS.ReadXml(SourceFile);

            // Get the JurisdictionID
            _JurisdictionID = DS.Tables["Case"].Rows[0]["JurisdictionID"].ToString();
            textBox3.Text += "Jurisdiction ID: " +_JurisdictionID + Environment.NewLine;

            // Resolve the Case Name text
            string expression = String.Format("GUID = '{0}' and LCID = 'en-US'", DS.Tables["Case"].Rows[0]["CaseName"].ToString());
            DataRow[] selectedRows = DS.Tables["Language_Asset"].Select(expression);
            _CaseName = selectedRows[0]["Textual"].ToString();
            textBox3.Text += "Case Name: " + _CaseName + Environment.NewLine;

            // Resolve the Case Summary text
            expression = String.Format("GUID = '{0}' and LCID = 'en-US'", DS.Tables["Case"].Rows[0]["CaseSummary"].ToString());
            selectedRows = DS.Tables["Language_Asset"].Select(expression);
            if (selectedRows.Length > 0) { _CaseSummary = selectedRows[0]["Textual"].ToString(); }
            textBox3.Text += "Case Summary: " + _CaseSummary + Environment.NewLine;


            string fileToSend = String.Format(@"{0}{1}.xml", DocumentsFolder, textBox5.Text);
            using (Stream uploadFolio = new FileStream(fileToSend, FileMode.Open))
            {
                serviceObject.SaveCaseFolio(new CaseMetaData()
                                                    {   CaseGUID = _CaseGUID,
                                                        JurisdictionID = _JurisdictionID,
                                                        CaseName = _CaseName,
                                                        CaseSummary = _CaseSummary,
                                                        UserSID = _UserSID,
                                                        MachineName = _MachineName,
                                                        CaseStream = uploadFolio
                                                    });
            }
            textBox3.Text += "Case Sent" + Environment.NewLine;
        }

        private void button6_Click(object sender, EventArgs e) // GetLicense textBox6
        {
            textBox3.Text = "";
            var _localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            string _UserSID = UserPrincipal.Current.Sid.ToString();

            bool status = serviceObject.GetLicense(textBox6.Text, _localIpAddress.ToString(), _UserSID, "machine");
            if (status)
            {
                textBox3.Text = "Got License";
            }
            else
            {
                textBox3.Text = "Exceeded the number of licenses";
            }
        }

        private void button7_Click(object sender, EventArgs e) // ReleaseLicense textBox7
        {
            textBox3.Text = "";
            serviceObject.ReleaseLicense(textBox6.Text);
            textBox3.Text = "Released License";
        }
    }
}

﻿namespace BWS.WebServicesTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ServerUri = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RunTimeTarget_tbx = new System.Windows.Forms.TextBox();
            this.RunTimeSecurity_tbx = new System.Windows.Forms.TextBox();
            this.LCID_tbx = new System.Windows.Forms.TextBox();
            this.Internet_cbx = new System.Windows.Forms.CheckBox();
            this.HeadSetMAC_tbx = new System.Windows.Forms.TextBox();
            this.DomainAttached_cbx = new System.Windows.Forms.CheckBox();
            this.Domain_tbx = new System.Windows.Forms.TextBox();
            this.BrainwaveServer_tbx = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LCID = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "GetServerHostName";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(154, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(394, 20);
            this.textBox1.TabIndex = 1;
            // 
            // ServerUri
            // 
            this.ServerUri.Location = new System.Drawing.Point(112, 6);
            this.ServerUri.Name = "ServerUri";
            this.ServerUri.Size = new System.Drawing.Size(436, 20);
            this.ServerUri.TabIndex = 2;
            this.ServerUri.Text = "Searching .  .  .";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Brainwave Server:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 67);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "GetServerIP";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(154, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(394, 20);
            this.textBox2.TabIndex = 5;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 96);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "GetCatalog";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(154, 255);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(394, 268);
            this.textBox3.TabIndex = 7;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 125);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "Check-out Case";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 154);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(136, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "Return Case";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(154, 127);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(394, 20);
            this.textBox4.TabIndex = 10;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(154, 156);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(394, 20);
            this.textBox5.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.RunTimeTarget_tbx);
            this.groupBox1.Controls.Add(this.RunTimeSecurity_tbx);
            this.groupBox1.Controls.Add(this.LCID_tbx);
            this.groupBox1.Controls.Add(this.Internet_cbx);
            this.groupBox1.Controls.Add(this.HeadSetMAC_tbx);
            this.groupBox1.Controls.Add(this.DomainAttached_cbx);
            this.groupBox1.Controls.Add(this.Domain_tbx);
            this.groupBox1.Controls.Add(this.BrainwaveServer_tbx);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.LCID);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(554, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(407, 228);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Windows Registry";
            // 
            // RunTimeTarget_tbx
            // 
            this.RunTimeTarget_tbx.Location = new System.Drawing.Point(100, 195);
            this.RunTimeTarget_tbx.Name = "RunTimeTarget_tbx";
            this.RunTimeTarget_tbx.Size = new System.Drawing.Size(301, 20);
            this.RunTimeTarget_tbx.TabIndex = 15;
            // 
            // RunTimeSecurity_tbx
            // 
            this.RunTimeSecurity_tbx.Location = new System.Drawing.Point(100, 169);
            this.RunTimeSecurity_tbx.Name = "RunTimeSecurity_tbx";
            this.RunTimeSecurity_tbx.Size = new System.Drawing.Size(301, 20);
            this.RunTimeSecurity_tbx.TabIndex = 14;
            // 
            // LCID_tbx
            // 
            this.LCID_tbx.Location = new System.Drawing.Point(100, 143);
            this.LCID_tbx.Name = "LCID_tbx";
            this.LCID_tbx.Size = new System.Drawing.Size(301, 20);
            this.LCID_tbx.TabIndex = 13;
            // 
            // Internet_cbx
            // 
            this.Internet_cbx.AutoSize = true;
            this.Internet_cbx.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Internet_cbx.Location = new System.Drawing.Point(52, 120);
            this.Internet_cbx.Name = "Internet_cbx";
            this.Internet_cbx.Size = new System.Drawing.Size(62, 17);
            this.Internet_cbx.TabIndex = 12;
            this.Internet_cbx.Text = "Internet";
            this.Internet_cbx.UseVisualStyleBackColor = true;
            // 
            // HeadSetMAC_tbx
            // 
            this.HeadSetMAC_tbx.Location = new System.Drawing.Point(100, 94);
            this.HeadSetMAC_tbx.Name = "HeadSetMAC_tbx";
            this.HeadSetMAC_tbx.Size = new System.Drawing.Size(301, 20);
            this.HeadSetMAC_tbx.TabIndex = 11;
            // 
            // DomainAttached_cbx
            // 
            this.DomainAttached_cbx.AutoSize = true;
            this.DomainAttached_cbx.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DomainAttached_cbx.Location = new System.Drawing.Point(9, 71);
            this.DomainAttached_cbx.Name = "DomainAttached_cbx";
            this.DomainAttached_cbx.Size = new System.Drawing.Size(105, 17);
            this.DomainAttached_cbx.TabIndex = 10;
            this.DomainAttached_cbx.Text = "DomainAttached";
            this.DomainAttached_cbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DomainAttached_cbx.UseVisualStyleBackColor = true;
            // 
            // Domain_tbx
            // 
            this.Domain_tbx.Location = new System.Drawing.Point(100, 45);
            this.Domain_tbx.Name = "Domain_tbx";
            this.Domain_tbx.Size = new System.Drawing.Size(301, 20);
            this.Domain_tbx.TabIndex = 9;
            // 
            // BrainwaveServer_tbx
            // 
            this.BrainwaveServer_tbx.Location = new System.Drawing.Point(100, 19);
            this.BrainwaveServer_tbx.Name = "BrainwaveServer_tbx";
            this.BrainwaveServer_tbx.Size = new System.Drawing.Size(301, 20);
            this.BrainwaveServer_tbx.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "RunTimeTarget";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "RunTimeSecurity";
            // 
            // LCID
            // 
            this.LCID.AutoSize = true;
            this.LCID.Location = new System.Drawing.Point(6, 146);
            this.LCID.Name = "LCID";
            this.LCID.Size = new System.Drawing.Size(31, 13);
            this.LCID.TabIndex = 5;
            this.LCID.Text = "LCID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "HeadSetMAC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Domain";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "BrainwaveServer";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(12, 183);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(136, 23);
            this.button6.TabIndex = 13;
            this.button6.Text = "GetLicense";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(12, 212);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(136, 23);
            this.button7.TabIndex = 14;
            this.button7.Text = "ReleaseLicense";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(154, 185);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(394, 20);
            this.textBox6.TabIndex = 15;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(154, 214);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(394, 20);
            this.textBox7.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(973, 537);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ServerUri);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Brainwave Web Services Test";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox ServerUri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox RunTimeTarget_tbx;
        private System.Windows.Forms.TextBox RunTimeSecurity_tbx;
        private System.Windows.Forms.TextBox LCID_tbx;
        private System.Windows.Forms.CheckBox Internet_cbx;
        private System.Windows.Forms.TextBox HeadSetMAC_tbx;
        private System.Windows.Forms.CheckBox DomainAttached_cbx;
        private System.Windows.Forms.TextBox Domain_tbx;
        private System.Windows.Forms.TextBox BrainwaveServer_tbx;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label LCID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
    }
}


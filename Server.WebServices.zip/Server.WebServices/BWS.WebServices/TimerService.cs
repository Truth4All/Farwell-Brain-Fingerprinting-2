﻿using Brainwave.Data;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Timers;

namespace BWS.WebServices
{
    public class TimerService
    {
        private Timer ScheduleTimer;
        private BackgroundWorker worker;
        LicenseDL lic = new LicenseDL();

        public TimerService()
        {
            worker = new BackgroundWorker();
            worker.DoWork += ScheduledTask;
            ScheduleTimer = new Timer(TimeSpan.FromMinutes(lic.UpdateLoopPeriod).TotalMilliseconds);
            ScheduleTimer.Elapsed += timer_Elapsed;
            ScheduleTimer.Start();
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (!worker.IsBusy) worker.RunWorkerAsync();
        }

        void ScheduledTask(object sender, DoWorkEventArgs e)
        {
                // Purge the stale licenses
                lic.PurgeIssuedUserLicense();

                string msg = string.Format("The Brainwave server has executed a license purge cycle.");
                EventLogging.BrainwaveLogEvent(msg, 20012, EventLogEntryType.Information);
        }

        public void TimerServiceStop()
        {
        }
    }
}

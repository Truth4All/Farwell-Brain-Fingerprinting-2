﻿using System;
using System.Diagnostics;
using Brainwave.Data;
using Brainwave.Entities;

namespace BWS.WebServices.Licensing
{
    public class LicenseLogic
    {
        public LicenseLogic()
        {
        }

        public LicenseMetaData GetUserLicense(string machineName, string machineIP, string userSID)
        {
            // S200 User License Issued
            // S401 Your are not a Brainwave User
            // S402 Not enough user licenses
            // S403 Application License expired
            // S404 User License Expired
            // S405 Test Licenses Expired
            // S406 Test Licenses Depleted
            // S500 Request failed
            // S501 Cannot reach the license server
            // S510 User License tampered with

            LicenseDL lic           = new LicenseDL();

            LicenseMetaData lmd     = new LicenseMetaData();
            UserEntity ue           = new UserEntity();
            MachineEntity machine   = new MachineEntity();

            lmd.Capabilities = "";
            lmd.Role = "";
            lmd.Status = LicenseCode.S999;
            lmd.SupervisorSID = "";
            lmd.Username = "";
            lmd.UserSID = "";
            lmd.TestLicenseCount = 0;

            // Get the Test License Count
            lmd.TestLicenseCount = lic.ReadValidTestLicenseCount();

            ue = lic.GetUserRecord(userSID);
            if (!IsBF_User(ue.Role))
            {
                string msg = string.Format("User {0} on machine {1} with IP address {2} was denied a license because of not being a Brainwave user.", Utility.GetUserNameFromSID(userSID), machineName, machineIP);
                EventLogging.BrainwaveLogEvent(msg, 20013, EventLogEntryType.Information);

                lmd.UserSID = userSID;
                lmd.Status = LicenseCode.S401;
                return lmd;
            }

            // Check For Application license expiration
            if (lic.CheckForApplicationLicenseExpiration())
            {
                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S403;
                return lmd;
            }

            // Check For User license expiration
            if (lic.CheckForUserLicenseExpiration())
            {
                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S404;
                return lmd;
            }

            // Check For Test license expiration
            if (lic.CheckForTestLicenseExpiration())
            {
                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S405;
                return lmd;
            }

            // Check For license tamper
            if (lic.ReadValidUserLicenseCount() <= 0)
            {
                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S510;
                return lmd;
            }

            // Check For Test license depletion
            if (lmd.TestLicenseCount <= 0)
            {
                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S405;
                return lmd;
            }

            if (lic.CheckIssuedUserLicence() < lic.ReadValidUserLicenseCount()) // Check if the number of issued licenses does not exceed the purchased count
            {
                machine = lic.ReadMachineRecord(machineName);
                // Does the record exist for the machine?
                if (machine != null)
                {
                    MachineEntity machine3 = new MachineEntity();
                    machine3.MachineName = machineName;
                    machine3.MachineIP = machineIP;
                    machine3.UserSID = userSID;
                    machine3.OnlineStatus = "online";
                    machine3.LicenseStatus = "issued";
                    machine3.ModifiedTimestamp = DateTime.Now.ToString();
                    lic.UpdateMachineRecord(machine3);
                }
                else
                {
                    MachineEntity machine2 = new MachineEntity();
                    machine2.MachineName = machineName;
                    machine2.MachineIP = machineIP;
                    machine2.UserSID = userSID;
                    machine2.OnlineStatus = "online";
                    machine2.LicenseStatus = "issued";
                    machine2.ModifiedTimestamp = DateTime.Now.ToString();
                    lic.CreateMachineRecord(machine2);
                }

                // If not create machine record and marked it issued
                string msg = string.Format("User {0} on machine {1} with IP address {2} was granted a user/machine license.", Utility.GetUserNameFromSID(userSID), machineName, machineIP);
                EventLogging.BrainwaveLogEvent(msg, 20002, EventLogEntryType.Information);

                lmd.UserSID = userSID;
                lmd.Username = ue.UserName;
                lmd.Role = ue.Role;
                lmd.Capabilities = ue.Capabilities;
                lmd.SupervisorSID = ue.SupervisorID;
                lmd.Status = LicenseCode.S200;
                return lmd;
            }
            else
            {
                string msg = string.Format("User {0} on machine {1} with IP address {2} was denied a license because of exceeding the authorized license count.", Utility.GetUserNameFromSID(userSID), machineName, machineIP);
                EventLogging.BrainwaveLogEvent(msg, 20003, EventLogEntryType.Information);
                lmd.UserSID = userSID;
                lmd.Status = LicenseCode.S402;
                return lmd;
            }
        }

        public bool TickleUserLicense(string machineName, string machineIP, string userSID)
        {
            LicenseDL lic = new LicenseDL();
            MachineEntity machine = new MachineEntity();

            if (lic.CheckIssuedUserLicence() < lic.ReadValidUserLicenseCount()) // Check if the number of issued licenses does not exceed the purchased count
            {
                machine = lic.ReadMachineRecord(machineName);
                // Does the record exist for the machine?
                if (machine != null)
                {
                    MachineEntity machine3 = new MachineEntity();
                    machine3.MachineName = machineName;
                    machine3.MachineIP = machineIP;
                    machine3.UserSID = userSID;
                    machine3.OnlineStatus = "online";
                    machine3.LicenseStatus = "issued";
                    machine3.ModifiedTimestamp = DateTime.Now.ToString();
                    lic.UpdateMachineRecord(machine3);
                }
                else
                {
                    MachineEntity machine2 = new MachineEntity();
                    machine2.MachineName = machineName;
                    machine2.MachineIP = machineIP;
                    machine2.UserSID = userSID;
                    machine2.OnlineStatus = "online";
                    machine2.LicenseStatus = "issued";
                    machine2.ModifiedTimestamp = DateTime.Now.ToString(); ;
                    lic.CreateMachineRecord(machine2);
                }
                // If not create machine record and marked it issued
                string msg = string.Format("User {0} on machine {1} with IP address {2} was renewed a user/machine license.", Utility.GetUserNameFromSID(userSID), machineName, machineIP);
                EventLogging.BrainwaveLogEvent(msg, 20002, EventLogEntryType.Information);

                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ReleaseUserLicense(string machineName)
        {
            LicenseDL lic = new LicenseDL();
            MachineEntity machine = new MachineEntity();

            machine = lic.ReadMachineRecord(machineName);
            // Does the record exist for the machine?
            if (machine != null)
            {
                machine.LicenseStatus = "released";
                machine.ModifiedTimestamp = DateTime.Now.ToString();
                lic.UpdateMachineRecord(machine);
            }
            return true;
        }

        private bool IsBF_User(string Role)
        {
            if (Role.Trim() == "BF_Managers" || Role.Trim() == "BF_Supervisors" || Role.Trim() == "BF_Investigators" || Role.Trim() == "BF_Operators")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

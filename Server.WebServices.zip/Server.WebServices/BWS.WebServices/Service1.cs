﻿using Brainwave.Data;
using BWS.WebServices.Licensing;
using System;
using System.Diagnostics;
using System.IO;
using System.ServiceModel;
using Brainwave.Entities;

namespace BWS.WebServices
{
    public class Synchro : ISynchro
    {
        string ApplicationFolder = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)          + @"\BrainwaveServer\";
        string DocumentsFolder   = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\BrainwaveServer\documents\";
        string LocalCatalog      = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\BrainwaveServer\documents\Catalog.xml";

        public string GetServerHostName()
        {
            return ServerInfoDL.GetServerHostName();
        }

        public string GetServerIP()
        {
            return ServerInfoDL.GetServerIP();
        }

        public LicenseMetaData GetUserLicense(string machine, string machineIP, string userSID)
        {
            LicenseMetaData lmd = new LicenseMetaData();

            string msg = string.Format("User {0} on machine {1}({2}) has requested a user/machine license.", Utility.GetUserNameFromSID(userSID), machine, machineIP);
            EventLogging.BrainwaveLogEvent(msg, 20001, EventLogEntryType.Information);

            LicenseLogic licL = new LicenseLogic();
            lmd = licL.GetUserLicense(machine, machineIP, userSID);
            return lmd;
        }

        public bool TickleUserLicense(string machine, string machineIP, string userSID)
        {
            LicenseLogic licL = new LicenseLogic();
            return licL.TickleUserLicense(machine, machineIP, userSID);
        }

        public bool ReleaseUserLicense(string machine)
        {
            // No licenseMode, machine licenses are re-usable as flex licenses.  test licenses are consumable -> no need to release them.

            string msg = string.Format("Machine {0} has requested the release of its user/machine license.", machine);
            EventLogging.BrainwaveLogEvent(msg, 20004, EventLogEntryType.Information);

            LicenseLogic licL = new LicenseLogic();
            return licL.ReleaseUserLicense(machine);
        }

        public int GetTestLicense(string userName, string machine)
        {
            string msg = string.Format("User {0} on machine {0} requested a count of valid Test license(s).", userName, machine);
            EventLogging.BrainwaveLogEvent(msg, 20014, EventLogEntryType.Information);

            LicenseDL lic = new LicenseDL();
            return lic.ReadValidTestLicenseCount();
        }

        public bool DebitTestLicense(string userName, string machine, int count)
        {
            string msg = string.Format("User {0} on machine {1} debited Test license (count {2}).", userName, machine, count);
            EventLogging.BrainwaveLogEvent(msg, 20011, EventLogEntryType.Information);

            LicenseDL lic = new LicenseDL();
            return lic.DebitTestLicense(count);
        }

        public Stream GetCatalogFile(string userSID, string machine)
        {
            if (!File.Exists(LocalCatalog))
            {
                string msg = string.Format("User {0} on machine {1} has requested a copy of the Catalog, but the Catalog did not exist.", Utility.GetUserNameFromSID(userSID), machine);
                EventLogging.BrainwaveLogEvent(msg, 20005, EventLogEntryType.Information);
                //throw new FaultException("File was not found");
                CatalogDL cdl = new CatalogDL();
                cdl.CreateCatalogCache();
                return new FileStream(LocalCatalog, FileMode.Open, FileAccess.Read, FileShare.Read);
            }
            else
            {
                string msg = string.Format("User {0} on machine {1} has requested a copy of the Catalog", Utility.GetUserNameFromSID(userSID), machine);
                EventLogging.BrainwaveLogEvent(msg, 20006, EventLogEntryType.Information);
                return new FileStream(LocalCatalog, FileMode.Open, FileAccess.Read, FileShare.Read);
            }
        }

        public FolioMetaData GetFolioMetaData(string CaseGUID, string userSID, string machine)
        {
            string filePath = Path.Combine(DocumentsFolder, CaseGUID + ".xml");
            if (!File.Exists(filePath))
            {
                string msg = string.Format("User {0} on machine {1} has requested a copy of the {2} Folio; but the Folio does not exist.", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                EventLogging.BrainwaveLogEvent(msg, 20007, EventLogEntryType.Information);
                throw new FaultException("The Folio was not found on the server");
            }
            else
            {
                string msg1 = string.Format("User {0} on machine {1} has requested information of the {2} Folio", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                EventLogging.BrainwaveLogEvent(msg1, 20008, EventLogEntryType.Information);

                BWS.WebServices.FolioMetaData fmd = new BWS.WebServices.FolioMetaData();
                CatalogDL cdl = new CatalogDL();
                Brainwave.Entities.FolioMetaData fmd2 = cdl.GetFolioMetaData(CaseGUID, userSID);
                Utility.CopyPropertyValues(fmd2, fmd);
                return fmd;
            }
        }

        public Stream GetCaseFolio(string CaseGUID, string userSID, string machine)
        {
            string filePath = Path.Combine(DocumentsFolder, CaseGUID + ".xml");

            if (!File.Exists(filePath))
            {
                string msg = string.Format("User {0} on machine {1} has requested a copy of the {2} Folio; but the Folio does not exist.", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                EventLogging.BrainwaveLogEvent(msg, 20007, EventLogEntryType.Information);
                throw new FaultException("The Folio was not found on the server");
            }
            else
            {
                string msg1 = string.Format("User {0} on machine {1} has requested a copy of the {2} Folio", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                EventLogging.BrainwaveLogEvent(msg1, 20008, EventLogEntryType.Information);

                // Check if Folio is locked
                //CatalogLogic cl = new CatalogLogic();
                CatalogDL cdl = new CatalogDL();

                if (cdl.ReadCatalogRecord(CaseGUID).IsLocked == true || cdl.GetFolioMetaData(CaseGUID, userSID).Access == "N")
                {
                    string msg2 = string.Format("User {0} on machine {1} was denied a locked copy of {2} Folio", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                    EventLogging.BrainwaveLogEvent(msg2, 20009, EventLogEntryType.Information);
                    string _lockedBy = Utility.GetUserNameFromSID(cdl.ReadCatalogRecord(CaseGUID).LockedBy);
                    throw new FaultException(String.Format("The Folio was locked by {0}", _lockedBy));
                }
                else
                {
                    string msg2 = string.Format("User {0} on machine {1} was served a copy of {2} Folio", Utility.GetUserNameFromSID(userSID), machine, CaseGUID);
                    EventLogging.BrainwaveLogEvent(msg2, 20010, EventLogEntryType.Information);
                    cdl.LockCatalogRecord(CaseGUID, userSID);
                    cdl.UpdateCatalogCache();
                    return new FileStream(filePath, FileMode.Open, FileAccess.Read);
                }
            }
        }

        public void SaveCaseFolio(CaseMetaData CaseInfo)
        {
            // Please note that this method is used for creating new Folio on the server as well.
            int    _Serial           = CaseInfo.Serial;
            string _CaseGUID         = CaseInfo.CaseGUID;
            string _JurisdictionID   = CaseInfo.JurisdictionID;
            string _CaseName         = CaseInfo.CaseName;
            string _CaseSummary      = CaseInfo.CaseSummary;
            string _UserSID          = CaseInfo.UserSID;
            string _MachineName      = CaseInfo.MachineName;

            string filePath = Path.Combine(DocumentsFolder, _CaseGUID + ".xml");
            using(var outputStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
            {
                CaseInfo.CaseStream.CopyTo(outputStream);
                outputStream.Flush();
                outputStream.Close();
                //CaseInfo.CaseStream.Flush();
                CaseInfo.CaseStream.Close();
                CaseInfo.CaseStream.Dispose();
            }

            //CatalogLogic cl = new CatalogLogic();
            CatalogDL cdl = new CatalogDL();
            cdl.UpdateCatalogWithFolio(_Serial, _CaseGUID, _JurisdictionID, _CaseName, _CaseSummary, _UserSID, _MachineName);
            cdl.UpdateCatalogCache();

            string msg = string.Format("User {0} on machine {1} has returned {2} Folio to the server.", _UserSID, _MachineName, _CaseGUID);
            EventLogging.BrainwaveLogEvent(msg, 20011, EventLogEntryType.Information);
        }
    }

}


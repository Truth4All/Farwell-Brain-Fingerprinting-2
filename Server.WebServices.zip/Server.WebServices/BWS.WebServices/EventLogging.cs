﻿using System;
using System.Diagnostics;

namespace BWS.WebServices
{
    class EventLogging
    {
        public static void BrainwaveLogEvent(string message, int eventID, EventLogEntryType level)
        {
            string eventSource = "ServerService";
            string eventLog = "Brainwave";
            string eventSourceMachine = ".";

            if (!EventLog.SourceExists(eventSource))
            {
                EventSourceCreationData mySourceData = new EventSourceCreationData(eventSource, eventLog);
                mySourceData.MachineName = eventSourceMachine;
                EventLog.CreateEventSource(mySourceData);
            }

            DateTime dt = new DateTime();
            dt = System.DateTime.UtcNow;
            message = dt.ToLocalTime() + ": " + message;
            EventLog.WriteEntry(eventSource, message, level, eventID);
        }
    }
}

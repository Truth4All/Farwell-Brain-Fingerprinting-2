﻿using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ServiceModel;
using System.ServiceProcess;
using System.Configuration;
using System.Configuration.Install;

namespace BWS.WindowsService
{
    [RunInstaller(true)]
    public class SynchroInstaller : Installer
    {
        private ServiceProcessInstaller process;
        private ServiceInstaller service;

        public SynchroInstaller()
        {
            process = new ServiceProcessInstaller();
            service = new ServiceInstaller();

            process.Account     = ServiceAccount.NetworkService;
            service.StartType   = ServiceStartMode.Automatic;
            service.ServiceName = "BrainwaveSynchroServices";
            service.DisplayName = "Brainwave Synchro Services";
            service.Description = "Brainwave Windows service for the hosting of Brainwave WCF Synchro Web services";

            this.Installers.AddRange(new Installer[] { process, service });
            this.AfterInstall  += new InstallEventHandler(SynchroInstaller_AfterInstall);
        }

        void SynchroInstaller_AfterInstall(object sender, InstallEventArgs e)
        {
            service.ServiceName         = "BrainwaveSynchroServices";
            using (ServiceController sc = new ServiceController(service.ServiceName))
            {
                sc.Start();
            }
        }
    }
}

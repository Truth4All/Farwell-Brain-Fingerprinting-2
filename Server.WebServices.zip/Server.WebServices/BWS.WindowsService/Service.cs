﻿using BWS.WebServices;
using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;
using System.ServiceProcess;
using System.Configuration;


namespace BWS.WindowsService
{
    public class SynchroWindowsService : ServiceBase
    {
        string CertificateFile = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\BrainwaveServerSecurity.pfx";
        string CertificatePassword = "c3xQT6Z2";
        public ServiceHost serviceHost = null;
        public TimerService ts;

        public static void Main()
        {
            ServiceBase.Run(new SynchroWindowsService());
        }

        public SynchroWindowsService()
        {
            // Service Name
            ServiceName = "Brainwave Web Services";
        }


        //Start the Windows service
        protected override void OnStart(string[] args)
        {
            // Start the 5 minutes purge loop
            ts = new TimerService();

            base.OnStart(args);

            if (serviceHost != null)
            {
                serviceHost.Close();
            }

            // What's our IP address du jour
            var localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            string serviceUri = string.Format("net.tcp://{0}:8787/Synchro/", localIpAddress);

            try
            {
                X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);

                NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
                tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
                tcpb.MaxReceivedMessageSize = int.MaxValue; // should consider reducing that
                tcpb.MaxBufferSize = int.MaxValue; // should consider reducing that
                tcpb.MaxBufferPoolSize = int.MaxValue; // should consider reducing that
                tcpb.TransferMode = TransferMode.Streamed;
                tcpb.CloseTimeout = TimeSpan.FromSeconds(20); // default: 10 seconds
                tcpb.OpenTimeout = TimeSpan.FromMinutes(1);  // default: 1 minute
                tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
                tcpb.SendTimeout = TimeSpan.FromMinutes(10); // default: 1 minute

                Uri addressBase = new Uri(serviceUri);
                serviceHost = new ServiceHost(typeof(Synchro), addressBase);
                serviceHost.Credentials.ServiceCertificate.Certificate = certificate;
                serviceHost.AddServiceEndpoint(typeof(ISynchro), tcpb, serviceUri);

                ServiceMetadataBehavior mBehave = new ServiceMetadataBehavior();
                serviceHost.Description.Behaviors.Add(mBehave);
                serviceHost.AddServiceEndpoint(typeof(IMetadataExchange), MetadataExchangeBindings.CreateMexTcpBinding(), "mex");

                // Enable  Service discovery
                serviceHost.Description.Behaviors.Add(new ServiceDiscoveryBehavior());
                serviceHost.AddServiceEndpoint(new UdpDiscoveryEndpoint());

                serviceHost.Open();
            }
            catch
            {
                serviceHost = null;
            }
        }

        //Stop the Windows service
        protected override void OnStop()
        {
            ts.TimerServiceStop();
            base.OnStop();

            if (serviceHost != null)
            {
                serviceHost.Close();
                serviceHost = null;
            }
        }
    }
}

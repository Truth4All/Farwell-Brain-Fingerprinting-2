﻿

CREATE PROCEDURE [dbo].[AddAppLicense] 
@LicenseCode varchar(255)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		INSERT INTO [dbo].[BF_Licenses]
		([ProductID],[LicenseCode])
     VALUES
		('1001', @LicenseCode)
END
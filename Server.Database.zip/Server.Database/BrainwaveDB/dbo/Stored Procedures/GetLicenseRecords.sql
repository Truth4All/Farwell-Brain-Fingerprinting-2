﻿CREATE PROCEDURE [dbo].[GetLicenseRecords] 
AS

BEGIN
	SET NOCOUNT ON;
	SELECT  [GUID], [Serial], [Sync], [IsActive], [IsDeleted], [IsLocked], [ProductID], [ProductName], [LicenseCode],
	        [ActivationCode], [LicenseExpiration], [OriginalCount], [LicenseCount], [ModifiedBy],
	        [ModifiedTimestamp], [OwnedBy], [CreatedTimestamp], [LockedBy]
	FROM    [dbo].[BF_Licenses] order by [ProductID]

End
﻿
CREATE PROCEDURE [dbo].[ReadUserRecord] 
	-- Add the parameters for the stored procedure here
	@UserSID varchar(60) 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	[SID],
			[Serial],
			[Sync],
			[IsActive],
			[IsDeleted],
			[IsLocked],
			[Username],
			[SupervisorSID],
			[Role],
			[Capabilities],
			[Tags],
			[ModifiedBy],
			[ModifiedTimestamp],
			[OwnedBy],
			[CreatedTimestamp],
			[LockedBy]
	FROM   [dbo].[BF_Users]
	WHERE  [SID] = @UserSID
END
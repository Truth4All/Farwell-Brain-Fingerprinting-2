﻿CREATE PROCEDURE [dbo].[GetLicenseSummaryInfo] 

AS

BEGIN



SET NOCOUNT ON;

Declare @NoOfUsers int

SELECT @NoOfUsers= COUNT(*)
  FROM [dbo].[BF_Users] where IsActive=1 and IsDeleted=0

Select B.ApplicationLicenseTotal,B.ApplicationLicenseRemaining,B.UserLicenseTotal,
		 (B.UserLicenseRemaining - @NoOfUsers) as UserLicensePending ,B.TestLicenseTotal,B.TestLicenseRemaining 

from 



(Select * from

(Select IsNull(Sum(OriginalCount),0) as ApplicationLicenseTotal from BF_Licenses where ProductID = 1001 and IsActive = 1 And IsDeleted =0) As ApplicationLicenseTotal,

(Select IsNull(Sum(LicenseCount),0) as ApplicationLicenseRemaining from BF_Licenses where ProductID = 1001 and IsActive = 1 And IsDeleted =0) As ApplicationLicenseRemaining,



(Select IsNull(Sum(OriginalCount),0) As UserLicenseTotal from BF_Licenses where ProductID = 1002 and IsActive = 1 And IsDeleted =0) As UserLicenseTotal,

(Select IsNull(Sum(LicenseCount),0) As UserLicenseRemaining from BF_Licenses where ProductID = 1002 and IsActive = 1 And IsDeleted =0) As UserLicenseRemaining,




(Select IsNull(Sum(OriginalCount),0) As TestLicenseTotal from BF_Licenses where ProductID = 1003 and IsActive = 1 And IsDeleted =0) As TestLicenseTotal,

(Select IsNull(Sum(LicenseCount),0) As TestLicenseRemaining from BF_Licenses where ProductID = 1003 and IsActive = 1 And IsDeleted =0) As TestLicenseRemaining) As B







END
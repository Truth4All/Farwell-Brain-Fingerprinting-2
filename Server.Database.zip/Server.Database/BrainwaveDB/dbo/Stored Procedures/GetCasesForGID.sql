﻿CREATE PROCEDURE [dbo].[GetCasesForGID]
	@GID uniqueidentifier
AS
	SELECT *   FROM [dbo].[BF_Catalog] where GID=@GID;
RETURN 0

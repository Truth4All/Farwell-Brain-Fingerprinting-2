﻿CREATE PROCEDURE [dbo].[CheckForTestLicenseExpiration]
		-- Add the parameters for the stored procedure here
	@ReturnedValue INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @UserCount varchar(5);
	DECLARE @RetrievedHash varchar(32);
	DECLARE @CalculatedHash varchar(32);

	-- get all license counts (expired or not)
	SELECT @UserCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003';
	SET @CalculatedHash = [master].[sys].[fn_varbintohexsubstring](0, HASHBYTES('MD5',@UserCount), 1, 0);
	
	-- insure that the count was not tampered with
	SELECT @RetrievedHash = [KeyValue] FROM BF_Registry WHERE [KeyClassGUID] = 'FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89';
	
	IF @CalculatedHash = @RetrievedHash
		BEGIN
			-- return only the one that have not expired
			SELECT @UserCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003' 
			AND Convert(Date, [LicenseExpiration], 101) >= Convert(Date, GETDATE(), 101);
			IF @UserCount > 0
				SET @ReturnedValue = 0;
			ELSE
				SET @ReturnedValue = 1
		END
	ELSE
		SET @ReturnedValue = 1;

	RETURN @ReturnedValue;
END
﻿CREATE PROCEDURE [dbo].[GetAppLicenseKey] 

AS

BEGIN

SET NOCOUNT ON;

Select LicenseExpiration,LicenseCode,ActivationCode from BF_Licenses where ProductID = 1001 And

           IsActive = 1 and IsDeleted = 0 And LicenseExpiration >= GETDATE()

End
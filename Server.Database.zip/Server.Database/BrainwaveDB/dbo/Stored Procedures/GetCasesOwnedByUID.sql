﻿CREATE PROCEDURE [dbo].[GetCasesOwnedByUID]
	@GID uniqueidentifier,
	@UID uniqueidentifier
AS
	SELECT CG.*  from [dbo].[BF_Catalog] as CG,
		[dbo].[BF_GroupMembership] as GMS
  WHERE   CG.[GID]=GMS.GID and GMS.Access='O' and GMS.MemberUID=@UID and GMS.GID!=@GID
RETURN 0

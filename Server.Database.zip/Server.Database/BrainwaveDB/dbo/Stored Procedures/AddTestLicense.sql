﻿-- =============================================
-- Author:		Thierry Maison
-- Create date: 2014-02-11
-- Description:	Add test licenses to the license table and correct the tamper-proof registry
-- =============================================
CREATE PROCEDURE [dbo].[AddTestLicense] 
@IsActive bit, 
@IsDeleted bit,
@ProductName varchar(255),
@LicenseCode varchar(255),
@LicenseExpiration smalldatetime,
@OriginalCount int,
@ActivationCode varchar(255) 
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TestCount varchar(5);
	DECLARE @CalculatedHash varchar(32);

	-- Insert license in the table
	INSERT INTO [dbo].[BF_Licenses]
		([GUID],[IsActive],[IsDeleted],[ProductID],[ProductName],[LicenseCode],[LicenseExpiration],[OriginalCount],[LicenseCount],[ActivationCode])
     VALUES
		(NEWID(),@IsActive,@IsDeleted,'1003',@ProductName,@LicenseCode,@LicenseExpiration,@OriginalCount,@OriginalCount,@ActivationCode)

	-- get the new license counts (expired or not)
	SELECT @TestCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003';
	SET @CalculatedHash = [master].[sys].[fn_varbintohexsubstring](0, HASHBYTES('MD5',@TestCount), 1, 0);

	-- replace the MD5 hash value in the registry or insert for the first time
	IF Exists ( Select * from BF_Registry where KeyClassGUID ='FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89')
	 Begin
		Update BF_Registry set KeyValue = @CalculatedHash where KeyClassGUID ='FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89'  
	 End
	Else
	 Begin
		Insert into BF_Registry(KeyClassGUID, KeyValue)
		Values ('FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89',@CalculatedHash)
	 End

END
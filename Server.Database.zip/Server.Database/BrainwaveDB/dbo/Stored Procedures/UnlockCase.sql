﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UnlockCatalogRecord] 
	-- Add the parameters for the stored procedure here
	@GUID uniqueidentifier,
	@ModifiedBy VarChar(60),
	@ModifiedTimestamp DateTime
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE [dbo].[BF_Catalog]
	SET
		[ModifiedBy]        = @ModifiedBy,
		[ModifiedTimestamp] = @ModifiedTimestamp,
		[IsLocked]          = 0,	
		[LockedBy]          = null

	WHERE [GUID] = @GUID
END

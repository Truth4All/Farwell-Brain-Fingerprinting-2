﻿CREATE PROCEDURE [dbo].[CreateGroup]
	-- Add the parameters for the stored procedure here
	@GID uniqueidentifier,
	@GroupName nVarChar(100),
	@OwnerUID uniqueidentifier

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[BF_Groups]
		([GID],
		 [GroupName],
		 [OwnerUID]
		)
     VALUES
		(@GID,
		 @GroupName,
		 @OwnerUID
		)
END

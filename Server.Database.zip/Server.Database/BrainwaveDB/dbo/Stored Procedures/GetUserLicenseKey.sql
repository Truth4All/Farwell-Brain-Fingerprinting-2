﻿CREATE PROCEDURE [dbo].[GetUserLicenseKey] 
AS
BEGIN
SET NOCOUNT ON;
Select LicenseExpiration,LicenseCode from BF_Licenses where ProductID = 1002 And
           IsActive = 1 and IsDeleted = 0 And LicenseExpiration >= GETDATE()

End
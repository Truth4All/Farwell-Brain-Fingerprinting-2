﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE PROCEDURE [dbo].[GetUserDetail]
@SID nvarchar(100)
AS

BEGIN
   SET NOCOUNT ON;
   Select * from [dbo].[BF_Users] where [SID] = @SID AND [IsActive] = 1 AND [IsDeleted] = 0
END
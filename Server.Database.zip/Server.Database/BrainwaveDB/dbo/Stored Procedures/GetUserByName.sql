﻿CREATE PROCEDURE [dbo].[GetUserByName]
@UserName nvarchar(50)
AS

BEGIN
   SET NOCOUNT ON;
   Select * from [dbo].[BF_Users] where Username = @UserName And [IsActive]=1 And [IsDeleted]=0
END
RETURN 0

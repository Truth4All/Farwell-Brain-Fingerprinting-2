﻿CREATE PROCEDURE [dbo].[AccessCatalogRecord]
	-- Add the parameters for the stored procedure here
	@GUID uniqueidentifier,
	@SID varchar(60)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	select Access from BF_Catalog C 
			inner join BF_GroupMembership M 
				on C.GID = M.GID 
			inner join BF_Users U 
				on M.MemberUID = U.UID 
	where U.SID = @SID and C.GUID = @GUID 

END
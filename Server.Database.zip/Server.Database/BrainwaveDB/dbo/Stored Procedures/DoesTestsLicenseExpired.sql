﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Last modified Date 1/20/2015- Added -1 to getdate() for considering the current date
-- also into account for validity
-- =============================================
CREATE PROCEDURE [dbo].[DoesTestsLicenseExpired]
	-- Add the parameters for the stored procedure here
 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT  count(*)   FROM [dbo].[BF_Licenses]  where ProductID=1003 and IsDeleted=0 and IsActive=1
	  and Convert(Date, [LicenseExpiration], 101) >= Convert(Date, GETDATE(), 101)
END
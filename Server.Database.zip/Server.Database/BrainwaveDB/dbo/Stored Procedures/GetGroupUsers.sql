﻿CREATE PROCEDURE [dbo].[GetGroupUsers]
		@GID uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   SELECT MemberUID,Username,Access FROM [dbo].[BF_Users], [dbo].[BF_GroupMembership]
WHERE [dbo].[BF_Users].[UID] = [dbo].[BF_GroupMembership].[MemberUID] AND [dbo].[BF_GroupMembership].[GID] = @GID
END

﻿CREATE PROCEDURE [dbo].[GetUserCount] 

@UserCount int =0 output

AS

BEGIN

 SET NOCOUNT ON;

 Select @UserCount = COUNT(*) from BF_Users 
End
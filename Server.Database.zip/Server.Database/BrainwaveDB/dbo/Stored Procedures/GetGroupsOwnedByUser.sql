﻿CREATE PROCEDURE [dbo].[GetGroupsOwnedByUser]
	@UID uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   

	SELECT  GID,GroupName,OwnerUID FROM [dbo].[BF_Groups] WHERE OwnerUID=@UID and  GroupName is not null
END

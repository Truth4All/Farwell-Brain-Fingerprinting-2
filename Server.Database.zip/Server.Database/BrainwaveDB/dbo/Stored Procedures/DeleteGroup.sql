﻿CREATE PROCEDURE [dbo].[DeleteGroup]
	@GID uniqueidentifier
AS

BEGIN
   SET NOCOUNT ON;
   DELETE [BF_Groups] WHERE [GID] = @GID

END
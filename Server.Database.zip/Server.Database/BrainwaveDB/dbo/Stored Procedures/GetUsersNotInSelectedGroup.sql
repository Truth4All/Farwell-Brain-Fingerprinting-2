﻿CREATE PROCEDURE [dbo].[GetUsersNotInSelectedGroup]
	@GID uniqueidentifier
AS

BEGIN

	SELECT UID,Username FROM dbo.BF_Users

where UID not in ( 
select MemberUID from  

 [dbo].[BF_GroupMembership] where GID=@GID)

 END
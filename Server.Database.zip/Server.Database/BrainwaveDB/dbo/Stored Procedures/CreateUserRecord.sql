﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE PROCEDURE [dbo].[CreateUserRecord]
	-- Add the parameters for the stored procedure here
	@SID varchar(60),
	@Username nchar(50),
	--@SupervisorSID varchar(60),
	@Role varchar(50),
	--@Capabilities varchar(100),
	@uid uniqueidentifier OUTPUT,
	@gid uniqueidentifier OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET @uid = newid()
	SET @gid = newid()

    -- Insert statements for procedure here
	INSERT INTO [dbo].[BF_Users]
		([SID],
		 [UID],
		 [Username],
		 --[SupervisorSID],
		 [Role]
		 --[Capabilities]
		)
     VALUES
		(@SID,
		 @uid,
		 @Username,
		 --@SupervisorSID,
		 @Role
		 --@Capabilities
		)

	-- Insert default group for the new user
	INSERT INTO [dbo].[BF_Groups]	([GID], [GroupName], [OwnerUID])
	VALUES							(@gid, null, @uid)
	
	-- Insert himself as a member into his own group with write permission
	INSERT INTO [dbo].[BF_GroupMembership]	([GID], [MemberUID], [Access])
	VALUES									(@gid, @uid, 'O')

	SELECT @uid AS UID, @gid AS GID

END

﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateMachineRecord]
	-- Add the parameters for the stored procedure here
	@MachineName nchar(100),
	@MachineIP nchar(100),
	@UserSID varchar(60),
	@OnlineStatus nchar(10),
	@LicenseStatus nchar(10),
	@ModifiedTimestamp datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE [dbo].[BF_Machines]
	SET 
	[MachineIP]         = @MachineIP,
	[UserSID]           = @UserSID,
	[OnlineStatus]      = @OnlineStatus,
	[LicenseStatus]     = @LicenseStatus,
	[ModifiedTimestamp] = @ModifiedTimestamp
	WHERE [MachineName] = @MachineName
END

﻿CREATE PROCEDURE [dbo].[GetRegistryEntry] 
@KeyClassGUID nvarChar(255),
@KeyValue nvarChar(255) OUTPUT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here  
	SELECT @KeyValue = [KeyValue] FROM BF_Registry WHERE  KeyClassGUID = @KeyClassGUID;
	RETURN
END
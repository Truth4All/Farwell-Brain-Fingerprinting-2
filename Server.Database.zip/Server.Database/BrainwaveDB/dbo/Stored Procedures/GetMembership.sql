﻿CREATE PROCEDURE [dbo].[GetMembership]
	-- Add the parameters for the stored procedure here
	@GID uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	[GID],
			[MemberUID],
			[Access]
	FROM   [dbo].[BF_GroupMembership] where [GID]=@GID
END

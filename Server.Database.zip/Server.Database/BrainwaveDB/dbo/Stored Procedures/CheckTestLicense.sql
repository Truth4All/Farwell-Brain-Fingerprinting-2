﻿-- =============================================
-- Author:		Thierry Maison	
-- Create date: 2014-02-11
-- Description:	Check how many test license are remaining
-- =============================================
CREATE PROCEDURE [dbo].[CheckTestLicense]
	-- Add the parameters for the stored procedure here
	@ReturnedValue INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TestCount varchar(5);
	DECLARE @RetrievedHash varchar(32);
	DECLARE @CalculatedHash varchar(32);

	-- get all license counts (expired or not)
	SELECT @TestCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003';

	SET @CalculatedHash = [master].[sys].[fn_varbintohexsubstring](0, HASHBYTES('MD5',@TestCount), 1, 0);
	
	-- insure that the count was not tampered with
	SELECT @RetrievedHash = [KeyValue] FROM BF_Registry WHERE [KeyClassGUID] = 'FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89';
	
	IF @CalculatedHash = @RetrievedHash
		BEGIN
			-- return only the one that have not expired
			SELECT @TestCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003'
			  AND Convert(Date, [LicenseExpiration], 101) >= Convert(Date, GETDATE(), 101);
			SET @ReturnedValue = @TestCount;
		END
	ELSE
		BEGIN
			SET @ReturnedValue = 0;
		END

	RETURN @ReturnedValue;
END
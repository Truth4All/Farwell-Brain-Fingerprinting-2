﻿CREATE PROCEDURE [dbo].[AddLicenseInfo] 
@IsActive bit, 
@IsDeleted bit,
@ProductID int, 
@ProductName varchar(255),
@LicenseCode varchar(255), 
@LicenseExpiration dateTime,
@OriginalCount int, 
@LicenseCount int ,
@ActivationCode varchar(255),
@MachineID varchar(255)
AS
BEGIN
SET NOCOUNT ON;

IF(@ProductID = 1003)
Begin
  Exec AddTestLicense @IsActive, @IsDeleted, @ProductName, @LicenseCode, @LicenseExpiration, @OriginalCount, @ActivationCode 
End

IF(@ProductID = 1002)
Begin
  Exec AddUserLicense @IsActive, @IsDeleted, @ProductName, @LicenseCode, @LicenseExpiration, @OriginalCount, @ActivationCode
End

If(@ProductID = 1001)
Begin 
       ---------------------------Expired previous Application Key----------------------------
   IF Exists ( Select * from BF_Licenses where ProductID = 1001 and IsActive = 1 and IsDeleted =0)
   Begin
       Update  BF_Licenses set IsActive = 0 , IsDeleted = 1 where ProductID = 1001
   End 
   --------------------------------------------------------------------
INSERT INTO [dbo].[BF_Licenses]
(
GUID, IsActive, IsDeleted, ProductID, ProductName, LicenseCode, LicenseExpiration, OriginalCount, LicenseCount,ActivationCode
)
VALUES
( 
NEWID(), @IsActive, @IsDeleted, @ProductID, @ProductName, @LicenseCode, @LicenseExpiration, @OriginalCount, @LicenseCount,@ActivationCode
)
	IF Exists ( Select * from BF_Registry where KeyClassGUID ='48AD3E28-88E9-4141-8DF7-E2FBA0B6CB05')
	 Begin
		Update BF_Registry set KeyValue = @MachineID where KeyClassGUID ='48AD3E28-88E9-4141-8DF7-E2FBA0B6CB05'  
	 End
	Else
	 Begin
		Insert into BF_Registry(KeyClassGUID, KeyValue)
		Values ('48AD3E28-88E9-4141-8DF7-E2FBA0B6CB05',@MachineID)
	 End
End
End
﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CreateCatalogRecord]
	-- Add the parameters for the stored procedure here
	@GUID uniqueidentifier,
	@Serial Int,
	@JurisdictionID NVarChar(50),
	@CaseName NVarChar(100),
	@CaseSummary NVarChar(100),
	@ModifiedBy VarChar(60),
	@OwnedBy VarChar(60),
	@UID uniqueidentifier

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GID uniqueidentifier 

	 SELECT @GID= GID FROM [dbo].[BF_Groups] WHERE OwnerUID=@UID and GroupName is null


	IF  @GID IS NOT NULL 
	BEGIN
	
	
	INSERT INTO [dbo].[BF_Catalog]
		([GUID],
		 [Serial],
		 [JurisdictionID],
		 [CaseName],
		 [GID],
		 [CaseSummary],
		 [ModifiedBy],
		 [OwnedBy]
		)
     VALUES
		(@GUID,
		 @Serial,
		 @JurisdictionID,
		 @CaseName,
		 @GID,
		 @CaseSummary,
		 @ModifiedBy,
	     @OwnedBy
		)
	END
	ELSE
	BEGIN

	SET @GID = NEWID() 

	INSERT INTO [dbo].[BF_Catalog]
		([GUID],
		 [Serial],
		 [JurisdictionID],
		 [CaseName],
		 [GID],
		 [CaseSummary],
		 [ModifiedBy],
		 [OwnedBy]
		)
     VALUES
		(@GUID,
		 @Serial,
		 @JurisdictionID,
		 @CaseName,
		 @GID,
		 @CaseSummary,
		 @ModifiedBy,
	     @OwnedBy
		)
	END
    -- Insert statements for procedure here
	
 END
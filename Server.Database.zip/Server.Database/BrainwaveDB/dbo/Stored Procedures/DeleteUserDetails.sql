﻿CREATE PROCEDURE [dbo].[DeleteUserDetails]
@SID varchar(60)
AS

BEGIN
	SET NOCOUNT ON;
	DECLARE @uid uniqueidentifier

	-- Get user UID first
	SET @uid = (SELECT [UID] FROM BF_Users WHERE [SID] = @SID)

	-- Delete all memberships for all the groups that belong to the user
	DELETE [BF_GroupMembership] WHERE [MemberUID] = @uid

	-- Delete all groups that belong to the user
	DELETE [BF_Groups] WHERE [OwnerUID] = @uid

	--Finally delete the user
	DELETE BF_Users WHERE SID = @SID 

END
﻿CREATE PROCEDURE [dbo].[AddRegistryEntry] 
@KeyClassGUID nvarChar(255),
@KeyValue nvarChar(255)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here  
	INSERT INTO BF_Registry (KeyClassGUID, KeyValue) VALUES(@KeyClassGUID, @KeyValue) 
END
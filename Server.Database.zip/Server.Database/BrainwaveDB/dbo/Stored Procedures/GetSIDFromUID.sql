﻿CREATE PROCEDURE [dbo].[GetSIDFromUID]
	@UID uniqueidentifier

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT [SID] FROM [BF_Users] WHERE [SID] = @UID
END

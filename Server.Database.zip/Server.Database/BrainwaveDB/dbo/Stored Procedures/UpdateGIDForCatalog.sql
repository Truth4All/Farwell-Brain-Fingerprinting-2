﻿CREATE PROCEDURE [dbo].[UpdateGIDForCatalog]
	@GID uniqueidentifier,
	@CaseID uniqueidentifier
AS
	UPDATE [dbo].[BF_Catalog]
   SET  
      [GID] = @GID
    
 WHERE GUID=@CaseID
RETURN 0

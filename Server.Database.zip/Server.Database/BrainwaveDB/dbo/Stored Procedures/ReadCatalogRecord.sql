﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ReadCatalogRecord] 
	-- Add the parameters for the stored procedure here
	@GUID uniqueidentifier

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	[GUID],
			[Serial],
			[Sync],
			[IsActive],
			[IsDeleted],
			[IsLocked],
			[JurisdictionID],
			[CaseName],
			[CaseSummary],
			[ModifiedBy],
			[ModifiedTimestamp],
			[OwnedBy],
			[GID],
			[CreatedTimestamp],
			[LockedBy]
	FROM   [dbo].[BF_Catalog]
	WHERE  [GUID] = @GUID
END

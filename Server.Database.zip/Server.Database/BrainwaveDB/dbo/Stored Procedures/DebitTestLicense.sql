﻿-- =============================================
-- Author:		Thierry Maison
-- Create date: 2014-02-11
-- Description:	Remove one test from the test license pool
-- =============================================
CREATE PROCEDURE [dbo].[DebitTestLicense] 
	@Count int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @UserLicenseIndex uniqueidentifier;
	DECLARE @TestCount varchar(5);
	DECLARE @CalculatedHash varchar(32);

	-- get the license to use
	SELECT TOP 1 @UserLicenseIndex = [GUID] FROM BF_Licenses WHERE ProductID = '1003'
	 AND   Convert(Date, [LicenseExpiration], 101) >= Convert(Date, GETDATE(), 101) and LicenseCount>0 ORDER BY LicenseExpiration ASC

	-- Decrement the license count
	UPDATE BF_Licenses SET LicenseCount = LicenseCount - @Count WHERE GUID =  @UserLicenseIndex

	-- Get the resulting total remaining license count for all licenses
	SELECT @TestCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1003' 

	-- replace the MD5 hash value in the registry
	SET @CalculatedHash = [master].[sys].[fn_varbintohexsubstring](0, HASHBYTES('MD5',@TestCount), 1, 0);

	UPDATE BF_Registry SET KeyValue = @CalculatedHash WHERE KeyClassGUID = 'FB6D2CFC-5BBC-4968-AB3F-0CCE3515FA89';
END
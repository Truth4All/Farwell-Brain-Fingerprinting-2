﻿CREATE PROCEDURE [dbo].[GetUIDFromSID]
	@SID VarChar(60)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT [UID] FROM [BF_Users] WHERE [SID] = @SID
END
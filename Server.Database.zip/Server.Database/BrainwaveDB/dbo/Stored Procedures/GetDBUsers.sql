﻿CREATE PROCEDURE [dbo].[GetDBUsers]

AS
	SELECT	[SID],
			[UID],
			[Username],
			[SupervisorSID],
			dbo.fn_GetUserNameForSID(SupervisorSID) as SupervisorName,
			[Role],
			[Capabilities],
			[IsActive] 
			FROM [BF_Users]  where IsDeleted<>1 ORDER BY [Username]

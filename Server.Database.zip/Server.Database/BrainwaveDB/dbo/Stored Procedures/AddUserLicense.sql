﻿-- =============================================
-- Author:		Thierry Maison
-- Create date: 2014-02-11
-- Description:	Add user licenses to the license file and modify the tamper protection in the registry
-- =============================================

CREATE PROCEDURE [dbo].[AddUserLicense] 
	@IsActive bit, 
	@IsDeleted bit,
	@ProductName varchar(255),
	@LicenseCode varchar(255),
	@LicenseExpiration smalldatetime,
	@OriginalCount int,
	@ActivationCode varchar(255) 
AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TestCount varchar(5);
	DECLARE @CalculatedHash varchar(32);

	-- Insert license in the table
	INSERT INTO [dbo].[BF_Licenses]
		([GUID],[IsActive],[IsDeleted],[ProductID],[ProductName],[LicenseCode],[LicenseExpiration],[OriginalCount],[LicenseCount],[ActivationCode])
     VALUES
		(NEWID(),@IsActive,@IsDeleted,'1002',@ProductName,@LicenseCode,@LicenseExpiration,@OriginalCount,@OriginalCount,@ActivationCode)


	-- get the new license counts (expired or not)
	SELECT @TestCount = SUM([LicenseCount]) FROM BF_Licenses WHERE [ProductID] = '1002';
	SET @CalculatedHash = [master].[sys].[fn_varbintohexsubstring](0, HASHBYTES('MD5',@TestCount), 1, 0);

	-- replace the MD5 hash value in the registry or insert for the first time
	IF Exists ( Select * from BF_Registry where KeyClassGUID ='D25AE539-6AC2-49FE-9A5E-E564A9174525')
	 Begin
		Update BF_Registry set KeyValue = @CalculatedHash where KeyClassGUID ='D25AE539-6AC2-49FE-9A5E-E564A9174525'  
	 End
	Else
	 Begin
		Insert into BF_Registry(KeyClassGUID, KeyValue)
		Values ('D25AE539-6AC2-49FE-9A5E-E564A9174525',@CalculatedHash)
	 End

END
﻿CREATE PROCEDURE [dbo].[DeleteMembership]
	@GID uniqueidentifier,
	@MemberUID uniqueidentifier
AS

BEGIN
   SET NOCOUNT ON;
   DELETE [BF_GroupMembership] WHERE [GID] = @GID AND [MemberUID] = @MemberUID

END

﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CheckIssuedUserLicence]
	-- Add the parameters for the stored procedure here
	@ReturnedValue INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- get all license counts (expired or not)
	SELECT @ReturnedValue = COUNT(*) FROM BF_Machines WHERE [LicenseStatus] = 'issued';

	RETURN @ReturnedValue;
END
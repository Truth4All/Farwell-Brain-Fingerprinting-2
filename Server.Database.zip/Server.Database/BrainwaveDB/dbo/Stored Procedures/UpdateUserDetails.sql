﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE  PROCEDURE [dbo].[UpdateUserDetails]


@SID varchar(60),
@Role varchar(50),
@SupervisorSID nvarchar(60),
@Capabilities varchar(100),
@IsActive bit


AS

BEGIN
   SET NOCOUNT ON;
   UPDATE BF_Users SET Role = @Role,SupervisorSID = @SupervisorSID,Capabilities = @Capabilities,  IsActive = @IsActive WHERE SID = @SID

END
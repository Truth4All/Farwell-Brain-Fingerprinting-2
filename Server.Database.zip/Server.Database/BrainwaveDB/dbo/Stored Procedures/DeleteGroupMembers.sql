﻿CREATE PROCEDURE [dbo].[DeleteGroupMembers]
	@GID uniqueidentifier
AS

BEGIN
   SET NOCOUNT ON;
   DELETE [BF_GroupMembership] WHERE [GID] = @GID 

END
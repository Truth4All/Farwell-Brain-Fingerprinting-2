﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE PROCEDURE [dbo].[AddUserInfo] 
@SID varChar(60), 

@Username nvarchar(50),
@Role varChar(50)
AS
BEGIN
       SET NOCOUNT ON;
INSERT INTO [dbo].[BF_Users]
( 

SID,Username ,Role

)

VALUES
( 
@SID, @Username,@Role
)

End
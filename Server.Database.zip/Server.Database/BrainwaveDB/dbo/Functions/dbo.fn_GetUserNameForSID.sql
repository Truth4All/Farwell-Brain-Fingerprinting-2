﻿CREATE FUNCTION [dbo].[fn_GetUserNameForSID]
(
	@BinSID AS varchar(100)
)
RETURNS VARCHAR(100)
AS
BEGIN

Declare @UserName varchar(100)


SELECT @UserName=[Username]   FROM [dbo].[BF_Users]   where SID=@BinSID


	RETURN @UserName
END
﻿CREATE TABLE [dbo].[BF_Users] (
    [SID]               VARCHAR (60)  NOT NULL,
	[UID]               UNIQUEIDENTIFIER NULL DEFAULT (newid()),
    [Serial]            INT           DEFAULT ((0)) NOT NULL,
    [Sync]              BIT           DEFAULT ((0)) NOT NULL,
    [IsActive]          BIT           DEFAULT ((1)) NOT NULL,
    [IsDeleted]         BIT           DEFAULT ((0)) NOT NULL,
    [IsLocked]          BIT           DEFAULT ((0)) NOT NULL,
    [Username]          NVARCHAR (50) NULL,
    [SupervisorSID]     VARCHAR (60)  NULL,
	[SupervisorName]    VARCHAR(60)   NULL,
    [Role]              VARCHAR (50)  NULL,
    [Capabilities]      VARCHAR (100) NULL,
    [Tags]              NVARCHAR (50) NULL,
    [ModifiedBy]        VARCHAR (60)  DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [ModifiedTimestamp] DATETIME      DEFAULT (getdate()) NOT NULL,
    [OwnedBy]           VARCHAR (60)  DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [CreatedTimestamp]  DATETIME      DEFAULT (getdate()) NOT NULL,
    [LockedBy]          VARCHAR (60)  NULL,
    CONSTRAINT [PK_BF_Users] PRIMARY KEY CLUSTERED ([SID] ASC)
);


GO
CREATE trigger [trigger_BF_Users]
on [dbo].[BF_Users]
after update
as
begin
update a
set ModifiedBy = [dbo].[fn_SIDToString](suser_sid()),
    ModifiedTimestamp = getdate(),
	a.Serial = b.Serial + 1
from BF_Users as a
join inserted as b 
on a.SID = b.SID; 
end
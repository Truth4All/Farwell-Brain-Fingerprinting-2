﻿CREATE TABLE [dbo].[BF_Catalog] (
    [GUID]              UNIQUEIDENTIFIER DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [Serial]            INT              DEFAULT ((0)) NOT NULL,
    [Sync]              BIT              DEFAULT ((0)) NOT NULL,
    [IsActive]          BIT              DEFAULT ((1)) NOT NULL,
    [IsDeleted]         BIT              DEFAULT ((0)) NOT NULL,
    [IsLocked]          BIT              DEFAULT ((0)) NOT NULL,
    [JurisdictionID]    NVARCHAR (50)    NULL,
    [CaseName]          NVARCHAR (100)   NULL,
    [CaseSummary]       NVARCHAR (100)   NULL,
    [ModifiedBy]        VARCHAR (60)     NULL,
    [ModifiedTimestamp] DATETIME         NOT NULL DEFAULT (getdate()),
    [OwnedBy]           VARCHAR (60)     NULL,
	[GID]               UNIQUEIDENTIFIER NULL,
    [CreatedTimestamp]  DATETIME         NOT NULL DEFAULT (getdate()),
    [LockedBy]          VARCHAR (60)     NULL,
    CONSTRAINT [PK_BF_Catalog] PRIMARY KEY CLUSTERED ([GUID] ASC)
);


GO

CREATE trigger [dbo].[trigger_BF_Catalog]
on [dbo].[BF_Catalog]
after update
as
begin
update a
set ModifiedTimestamp = getdate(),
	a.Serial = b.Serial
from BF_Catalog as a
join inserted as b 
on a.GUID = b.GUID; 
end

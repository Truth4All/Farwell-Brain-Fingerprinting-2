﻿CREATE TABLE [dbo].[BF_Licenses] (
    [GUID]              UNIQUEIDENTIFIER DEFAULT (newid()) ROWGUIDCOL NOT NULL,
    [Serial]            INT              DEFAULT ((0)) NOT NULL,
    [Sync]              BIT              DEFAULT ((0)) NOT NULL,
    [IsActive]          BIT              DEFAULT ((1)) NOT NULL,
    [IsDeleted]         BIT              DEFAULT ((0)) NOT NULL,
    [IsLocked]          BIT              DEFAULT ((0)) NOT NULL,
    [ProductID]         INT              NOT NULL,
	[ProductName]       VARCHAR (255)    NULL,
    [LicenseCode]       VARCHAR (255)    NOT NULL,
    [ActivationCode]    VARCHAR (255)    NULL,
    [LicenseExpiration] DATETIME         NULL,
    [OriginalCount]     INT              NULL,
    [LicenseCount]      INT              NULL,
    [ModifiedBy]        VARCHAR (60)     DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [ModifiedTimestamp] DATETIME         DEFAULT (getdate()) NOT NULL,
    [OwnedBy]           VARCHAR (60)     DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [CreatedTimestamp]  DATETIME         DEFAULT (getdate()) NOT NULL,
    [LockedBy]          VARCHAR (60)     NULL,
    CONSTRAINT [PK_BF_Licenses] PRIMARY KEY CLUSTERED ([GUID] ASC)
);


GO
CREATE trigger [dbo].[trigger_BF_Licenses]
on [dbo].[BF_Licenses]
after update
as
begin
update a
set ModifiedBy = [dbo].[fn_SIDToString](suser_sid()),
    ModifiedTimestamp = getdate(),
	a.Serial = b.Serial + 1
from BF_Licenses as a
join inserted as b 
on a.GUID = b.GUID; 
end
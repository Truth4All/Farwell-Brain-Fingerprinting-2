﻿CREATE TABLE [dbo].[BF_Machines] (
    [GUID]              UNIQUEIDENTIFIER CONSTRAINT [D_dbo_BF_Machines_1] DEFAULT (newid()) NOT NULL,
    [Serial]            INT              CONSTRAINT [D_dbo_BF_Machines_2] DEFAULT ((0)) NOT NULL,
    [Sync]              BIT              CONSTRAINT [D_dbo_BF_Machines_3] DEFAULT ((0)) NOT NULL,
    [IsActive]          BIT              DEFAULT ((1)) NOT NULL,
    [IsDeleted]         BIT              DEFAULT ((0)) NOT NULL,
    [IsLocked]          BIT              DEFAULT ((0)) NOT NULL,
    [MachineName]       NCHAR (100)      NULL,
    [MachineIP]         NCHAR (100)      NULL,
    [UserSID]           VARCHAR (60)     NULL,
	[UserName]          VARCHAR (60)     NULL,
    [OnlineStatus]      NCHAR (10)       NULL,
    [LicenseStatus]     NCHAR (10)       NULL,
    [ModifiedBy]        VARCHAR (60)     DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [ModifiedTimestamp] DATETIME         DEFAULT (getdate()) NOT NULL,
    [OwnedBy]           VARCHAR (60)     DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [CreatedTimestamp]  DATETIME         DEFAULT (getdate()) NOT NULL,
    [LockedBy]          VARCHAR (60)     NULL,
    PRIMARY KEY CLUSTERED ([GUID] ASC)
);


GO

CREATE trigger [dbo].[trigger_BF_Machines]
on [dbo].[BF_Machines]
after update
as
begin
update a
set ModifiedBy = [dbo].[fn_SIDToString](suser_sid()),
    ModifiedTimestamp = getdate(),
	a.Serial = b.Serial + 1
from BF_Machines as a
join inserted as b 
on a.GUID = b.GUID; 
end

﻿CREATE TABLE [dbo].[BF_Registry] (
    [ID]                INT            IDENTITY (1, 1) NOT NULL,
    [Serial]            INT            DEFAULT ((0)) NOT NULL,
    [Sync]              BIT            DEFAULT ((0)) NOT NULL,
    [IsActive]          BIT            DEFAULT ((1)) NOT NULL,
    [IsDeleted]         BIT            DEFAULT ((0)) NOT NULL,
    [IsLocked]          BIT            DEFAULT ((0)) NOT NULL,
    [KeyClassGUID]      NVARCHAR (255) NOT NULL,
    [KeyValue]          NVARCHAR (255) NULL,
    [ModifiedBy]        VARCHAR (60)   DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [ModifiedTimestamp] DATETIME       DEFAULT (getdate()) NOT NULL,
    [OwnedBy]           VARCHAR (60)   DEFAULT ([dbo].[fn_SIDToString](suser_sid())) NOT NULL,
    [CreatedTimestamp]  DATETIME       DEFAULT (getdate()) NOT NULL,
    [LockedBy]          VARCHAR (60)   NULL,
    CONSTRAINT [PK_BF_Registry] PRIMARY KEY CLUSTERED ([ID] ASC)
);


GO
CREATE trigger [dbo].[trigger_BF_Registry]
on [dbo].[BF_Registry]
after update
as
begin
update a
set ModifiedBy = [dbo].[fn_SIDToString](suser_sid()),
    ModifiedTimestamp = getdate(),
	a.Serial = b.Serial + 1
from BF_Registry as a
join inserted as b 
on a.ID = b.ID; 
end
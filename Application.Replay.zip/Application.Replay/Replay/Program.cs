﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO.Ports;
using System.Security.Principal;

namespace Brainwave.Replay
{
    static class Program
    {
        public static string PassedGUID;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", string.Format(@"{0}config\Brainwave.config", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles))));

            if (args.Length == 0)
            {
                MessageBox.Show("Need command argument for this program");
                Application.Exit();
            }
            else
            {
                PassedGUID = args[0];

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                Configuration conf;
                conf = new Configuration();
                Application.Run(new frmDisplayCapture(conf));
            }
        }
    }
}

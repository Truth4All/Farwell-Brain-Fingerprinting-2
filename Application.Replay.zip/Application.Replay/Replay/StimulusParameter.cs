﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Brainwave.Replay
{
    public class StimulusParameter
    {
        public static DataTable stimulusTable; // Table to hold the randomized-stimulus
        public static DataTable ReplayTable;

        public static void GetStimuliDataFromXML(XmlDocument InputDocument)
        {
            string StimulusModality = InputDocument.SelectSingleNode("/BrainWave_Test/Test-Tests/Test/StimulusModality").InnerText;
            ReplayTable = new DataTable();

            ReplayTable.Columns.Add("ID", typeof(int)); //<Sequence>
            ReplayTable.Columns.Add("GroupGUID");       //<GroupGUID>
            ReplayTable.Columns.Add("Modality");        // conf.StimulusModality
            ReplayTable.Columns.Add("Category");        //<Category>
            ReplayTable.Columns.Add("Fact");            //<Stimulus>
            ReplayTable.Columns.Add("Media");           //<Media>
            ReplayTable.Columns.Add("Trial_Valid");     //<Trial_Valid>
            ReplayTable.Columns.Add("EEG_Valid");       //<EEG_Valid>
            ReplayTable.Columns.Add("EOG_Valid");       //<EOG_Valid>
            ReplayTable.Columns.Add("ResponseType");    //<ResponseType>
            ReplayTable.Columns.Add("ReactionTime");    //<ReactionTime>
            ReplayTable.Columns.Add("CaptureTime");     //<CaptureTime>
            ReplayTable.Columns.Add("EOGData", typeof(float[]));         //<EOGData>
            ReplayTable.Columns.Add("ERPData", typeof(float[]));         //<ERPData>


            XmlNodeList TrialList = InputDocument.SelectNodes("/BrainWave_Test/Test-Tests/Test/Trials/Trial");
            foreach (XmlNode Trial in TrialList)
            {
                DataRow row;
                row = ReplayTable.NewRow();
                
                row["ID"]           = Convert.ToInt32(Trial.SelectSingleNode("Sequence").InnerText);      //<Sequence>
                row["GroupGUID"]    = Trial.SelectSingleNode("GroupGUID").InnerText;                      //<GroupGUID>
                row["Modality"]     = InputDocument.SelectSingleNode("/BrainWave_Test/Test-Tests/Test/StimulusModality").InnerText;  // conf.StimulusModality
                row["Category"]     = Trial.SelectSingleNode("Category").InnerText;                       //<Category>
                row["Fact"]         = Trial.SelectSingleNode("Stimulus").InnerText;                       //<Stimulus
                if (string.Equals(StimulusModality, "image", StringComparison.OrdinalIgnoreCase))
                {
                    row["Media"]        = Trial.SelectSingleNode("Media").InnerText;                          //<Media>
                }
                row["Trial_Valid"]  = Trial.SelectSingleNode("Trial_Valid").InnerText;                    //<Trial_Valid>
                row["EEG_Valid"]    = Trial.SelectSingleNode("EEG_Valid").InnerText;                      //<EEG_Valid>
                row["EOG_Valid"]    = Trial.SelectSingleNode("EOG_Valid").InnerText;                      //<EOG_Valid>
                row["ResponseType"] = Trial.SelectSingleNode("ResponseType").InnerText;                   //<ResponseType>
                row["ReactionTime"] = Trial.SelectSingleNode("ReactionTime").InnerText;                   //<ReactionTime>
                row["CaptureTime"]  = Trial.SelectSingleNode("CaptureTime").InnerText;                    //<CaptureTime>

                float[] EOGData = Array.ConvertAll(Trial.SelectSingleNode("EOGData").InnerText.Split(','), float.Parse);
                float[] ERPData = Array.ConvertAll(Trial.SelectSingleNode("ERPData").InnerText.Split(','), float.Parse);
                row["EOGData"] = EOGData;
                row["ERPData"] = ERPData;

                ReplayTable.Rows.Add(row);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Drawing.Drawing2D;
using System.Diagnostics;

namespace Brainwave.Replay
{
    public partial class frmDisplayCapture : Form
    {
        // Declare Bluetooth-related variables and set the initial value
        Configuration conf = new Configuration();
        int TotalRecords;
      
        private int[] GainSet = { 1, 2, 3, 4, 6, 8, 12 };
        private float[] Vmax;
        private float[] Vmin;

        // Declare relevant variables
        public static int Gain;

        //private int DataLost;
        public static bool bolSaveData = false;

        //ERP
        //Process scene;
        public static StimuliReqResp sRR;
        public static StimuliReqResp previousSRR;
        public static StimuliReqResp replaySRR;
        public static bool PreDataState ;
        public static bool PostDataState = false;
        public static int PreDataIndex = 0;
        public static int PostDataIndex = 0;
        public static float[,] tempPreData;
        public static float[] currentData;
        public static float[,] currentTrialData;
        public float currentEOG;
        public float currentERP;

        public static StimulusAnalysis Target;
        public static StimulusAnalysis Probe;
        public static StimulusAnalysis Irrelevant;
        public static StimulusAnalysis Total;
        public int preDataLength;
        public int postDataLength;
        public static int DataLength;

        float[,] EEGData;
        public static DataTable dtERPAnalysis;
        public static DataTable dtERPRange ;

        Stopwatch sw = new Stopwatch();
        public static post_test_comments ptc;

        // Time comparison
        private int dataRcvpoint;
        private int dataRcvTime;

        public Thread btThread;
        public static Stream sr;

        //txt
        public static string Comments;

        //Labels
        private string Label001;
        private string Label002;
        private string Label003;
        private string Label004;
        private string Label005;
        private string NeedLicenses;

        // Counters and statuses
        public int intShownStimuli      = 0; // incremented everytime a stimulus is shown
        public int intShownTargets      = 0; //
        public int intShownProbes       = 0; //
        public int intShownIrrelevants  = 0; //

        // Stimulus
        public string ShownMediaType    = "";
        public byte[] ShownMedia;
        public string ShownMediaB64;
        public string ShownCategory     = "";
        public string ShownFact         = "";
        public string ShownGroup        = "";


        // Flags and conditions
        public bool StartStimulus;          // True when operator ask for stimulus display
        public bool PauseState = false;     // State information for the puase button

        private int[] ReactionClick = new int[3] { 0, 0, 0 };//[0]:Target [1]:Probe [2]:Irrelevant

        private Thread btThread_ERPDraw;
        System.Timers.Timer StimulusTimer;

        Brainwave.Replay.ERPWaveControl _ERPWave;
        public bool _startStimulus;


        public frmDisplayCapture(Configuration conf)
        {
            _ERPWave = ERPWave;
            
            InitializeComponent();

            //Set the parameters for Initialization
            this.conf = conf;
            TotalRecords = StimulusParameter.ReplayTable.Rows.Count;

            // Language override
            if (conf.Language != "en-US"){
                this.Text                   = conf.GetLanguageString("ba3ed4ba-8eef-45dd-955f-c3caebfe0f50"); // "Brain Fingerprinting"
                this.label2.Text            = conf.GetLanguageString("04905a0d-fe79-4f4c-ae19-82ce8d0b008b"); // "Connecting:"
               
                this.groupBox2.Text         = conf.GetLanguageString("6ed14358-0bac-45dc-a074-8b6fb14d6351"); // "ERP Waveform"
                this.groupBox4.Text         = conf.GetLanguageString("4f7d5cc9-522a-40c5-9c93-a0f1de33d54b"); // "Stimulus Info"
                this.label17.Text           = conf.GetLanguageString("eff48fe6-efed-4b1d-b360-0df5d6b3bbe0"); // "Reaction Time: "
                this.label16.Text           = conf.GetLanguageString("337bc603-08d7-4d7d-b465-e18de4dda01d"); // "Stimulus : "
                this.label15.Text           = conf.GetLanguageString("c4f83f8a-7c48-430a-b0fd-506832392832"); // "Stimulus Type : "
                this.gbxWaveform.Text       = conf.GetLanguageString("b71bac67-3fe1-4094-b487-5444ad70cb1a"); // "EEG Waveform"
               
                this.groupBox6.Text         = conf.GetLanguageString("3cc40bbc-1a11-4b8b-91ae-4a90669ddc68"); // "Comments during test"
                this.GroupBoxLocation.Text  = conf.GetLanguageString("496751fc-d3f5-4e38-ae6f-452719fb49ee"); // "Location / Machine"
                this.btnExit.Text           = conf.GetLanguageString("9c2346f1-f36b-4ee6-bf7c-6a5526ad116e"); // "Exit"
                this.btnStartStimulus.Text  = conf.GetLanguageString("e12b1b37-c3ee-487e-b670-369d9edb41bc"); // "Start Stimulus" -> "start"
                this.Label001               = conf.GetLanguageString("486741af-5530-4d84-a457-1e06cd4c2d41"); // "PostData Error: "
                this.Label002               = conf.GetLanguageString("3510aa2a-d5a6-4ca2-9461-87c86a769429"); // "Error: "
                this.Label003               = conf.GetLanguageString("0ab8e484-8037-4d23-9279-69002c05c6b8"); // "Experiment Complete. Stop record. "
                this.Label004               = conf.GetLanguageString("5ac0f5fe-0443-4f28-878d-6189cade2878"); // "Saving"
                this.Label005               = conf.GetLanguageString("fba06d41-d310-4a80-b21c-8c5415af7927"); // "Not Saved"
                NeedLicenses                = conf.GetLanguageString("A30A6146-0B0A-4414-8E88-48049DF98277"); // "You need additional Test Licenses in order to execute this test"
            }
            else
            {
                this.Label001               = "PostData Error: ";
                this.Label002               = "Error: ";
                this.Label003               = "Experiment Complete. Stop record. ";
                this.Label004               = "Saving";
                this.Label005               = "Not Saved";
                NeedLicenses                = "You need additional Test Licenses in order to execute this test";
            }

            currentData = new float[conf.Channels];   // New array for holding the capture data

            Gain = conf.PGAGain;
            
            dataRcvTime = 0;
            sr = null;

            Vmax = new float[conf.Channels];          // will be used to store the minimum and maximun detected data
            Vmin = new float[conf.Channels];
            for (int i = 0; i < conf.Channels; i++)   // Inititiaze the min and max detection
            {
                Vmax[i] = 0.0f;
                Vmin[i] = 0.0f;
            }
        }

        private void frmCapture_Load(object sender, EventArgs e)
        {
            //thread
            Form.CheckForIllegalCrossThreadCalls = false;
        }

        private void Parameter_initial()
        {
            // Fill the first row of ERP progress table disply with the required number of target/probes
            dtERPAnalysis.Rows[0]["Target"]     = conf.TargetsRequired;                 // 12
            dtERPAnalysis.Rows[0]["Probe"]      = conf.ProbesRequired;                  // 12
            dtERPAnalysis.Rows[0]["Irrelevant"] = conf.IrrelevantsRequired.ToString();  // 36

            // Duration of the DataLenght
            DataLength = conf.BufferLenght(conf.CaptureDuration, conf.SamplingFrequency);

            // PreData (1000 mS)
            preDataLength                       = conf.BufferLenght(conf.Fixation,conf.SamplingFrequency);
            tempPreData                         = new float[conf.Channels, preDataLength];

            // PostData (1800 mS)
            postDataLength                      = conf.BufferLenght(conf.ERPBaseline, conf.SamplingFrequency);
            
            EEGData = new float[conf.Channels, preDataLength + postDataLength];

            EEGwave.setting(conf.Channels, conf.SamplingFrequency, conf.Resolution, Gain, conf.DisplayTime, false);
            ERPWave.setting(conf.Channels, conf.SamplingFrequency, conf.Resolution, Gain, DataLength);
        }

        private void ReceiveSignalAndDraw_()
        {
            EEGwave.Reset();
            DataRow PresentRecord = StimulusParameter.ReplayTable.Rows[intShownStimuli];
            float[] EOGData                     = (float[])PresentRecord["EOGData"];
            float[] ERPData                     = (float[])PresentRecord["ERPData"];
     
            // copy two individual arrays into 2-D array
            for (int i = 0; i < EOGData.Length; i++)
            {
                UpdateDataRcvTime(); // every read packet (one sample on both channels) updates dataRcvpoint
                currentData[1]                  = EOGData[i] / 1000000;
                currentData[0]                  = ERPData[i] / 1000000; 

                //draw raw data
                EEGwave.Draw(currentData);
            }

        }

        private void UpdateDataRcvTime() // The number of seconds after the display format
        {
            dataRcvpoint++;

            if (dataRcvpoint == conf.SamplingFrequency)
            {
                dataRcvTime++;

                string time = (dataRcvTime / 3600).ToString("00") + ":" + ((dataRcvTime / 60) % 60).ToString("00") + ":" + (dataRcvTime % 60).ToString("00");
                btRcvTimeLbl.Text = "" + " ( " + time + " ) ";
                dataRcvpoint = 0;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void setTableInfo()
        {
            // ERP Analysis Table
            dtERPAnalysis = new DataTable();
            DataColumn column;

            // Create new DataColumn, set DataType,   
            column = new DataColumn("-----", typeof(string));
            dtERPAnalysis.Columns.Add(column);

            column = new DataColumn("Target", typeof(int));
            dtERPAnalysis.Columns.Add(column);

            column = new DataColumn("Probe", typeof(int));
            dtERPAnalysis.Columns.Add(column);

            column = new DataColumn("Irrelevant", typeof(int));
            dtERPAnalysis.Columns.Add(column);

            column = new DataColumn("Total", typeof(int));
            dtERPAnalysis.Columns.Add(column);

            //Req.
            DataRow dr = dtERPAnalysis.NewRow();
            dr["-----"]         = "Req.";
            dr["Target"]        = 0;
            dr["Probe"]         = 0;
            dr["Irrelevant"]    = 0;
            dr["Total"]         = 0;
            dtERPAnalysis.Rows.Add(dr);

            //Trials
            dr = dtERPAnalysis.NewRow();
            dr["-----"]         = "Trials.";
            dr["Target"]        = 0;
            dr["Probe"]         = 0;
            dr["Irrelevant"]    = 0;
            dr["Total"]         = 0;
            dtERPAnalysis.Rows.Add(dr);

            //Good
            dr = dtERPAnalysis.NewRow();
            dr["-----"]         = "Good";
            dr["Target"]        = 0;
            dr["Probe"]         = 0;
            dr["Irrelevant"]    = 0;
            dr["Total"]         = 0;
            dtERPAnalysis.Rows.Add(dr);

            //RT
            dr = dtERPAnalysis.NewRow();
            dr["-----"]         = "RT.";
            dr["Target"]        = 0;
            dr["Probe"]         = 0;
            dr["Irrelevant"]    = 0;
            dr["Total"]         = 0;
            dtERPAnalysis.Rows.Add(dr);

            //Acc.
            dr = dtERPAnalysis.NewRow();
            dr["-----"]         = "Acc.";
            dr["Target"]        = 0;
            dr["Probe"]         = 0;
            dr["Irrelevant"]    = 0;
            dr["Total"]         = 0;
            dtERPAnalysis.Rows.Add(dr);

            dgERPAnalysis.DataSource = dtERPAnalysis;
            dgERPAnalysis.Columns["-----"].Width        = 50;
            dgERPAnalysis.Columns["Target"].Width       = 60;
            dgERPAnalysis.Columns["Probe"].Width        = 60;
            dgERPAnalysis.Columns["Irrelevant"].Width   = 60;
            dgERPAnalysis.Columns["Total"].Width        = 60;


            // ERP Range Table (one column for each channel)

            dtERPRange = new DataTable();
            // Create new DataColumn, set DataType

            if (conf.Channels > 2)
            {
                column = new DataColumn("-----", typeof(string));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("Fz", typeof(float));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("Cz", typeof(float));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("Pz", typeof(float));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("EOG", typeof(float));
                dtERPRange.Columns.Add(column);

                //Data Range
                dr = dtERPRange.NewRow();
                dr["-----"] = "Range.";
                dr["Fz"]    = 0;
                dr["Cz"]    = 0;
                dr["Pz"]    = 0;
                dr["EOG"]   = 0;
                dtERPRange.Rows.Add(dr);

            }
            else
            {
                column = new DataColumn("-----", typeof(string));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("Pz", typeof(float));
                dtERPRange.Columns.Add(column);
                column = new DataColumn("EOG", typeof(float));
                dtERPRange.Columns.Add(column);

                //Data Range
                dr = dtERPRange.NewRow();
                dr["-----"] = "Range.";
                dr["Pz"]    = 0;
                dr["EOG"]   = 0;
                dtERPRange.Rows.Add(dr);

            }
  
        }

        private void CreateAnalysisArrays()
        {
            setTableInfo();
            Parameter_initial();

            Target                                  = new StimulusAnalysis();
            Probe                                   = new StimulusAnalysis();
            Irrelevant                              = new StimulusAnalysis();
            Total                                   = new StimulusAnalysis();

            Target.rawData                          = new float[conf.Channels, DataLength];
            Probe.rawData                           = new float[conf.Channels, DataLength];
            Irrelevant.rawData                      = new float[conf.Channels, DataLength];
        }

        private void btnStartStimulus_Click(object sender, EventArgs e)
        {
            // The "Start Stimulus" button was clicked

            // Show the comments & Location
            txtComments.Text                        = conf.Comments.ToString();
            txtLocation.Text                        = conf.Location.ToString();
            txtMachine.Text                         = conf.MachineName.ToString();

            StartStimulus                           = true; // set the StartStimulus to true - then waiting for next StimulusTimer event
            ShowStimulusSetup();
            CreateAnalysisArrays();
            btnStartStimulus.Enabled                = false;

            frmDisplayCapture.Target.rawData        = new float[conf.Channels, frmDisplayCapture.DataLength];
            frmDisplayCapture.Probe.rawData         = new float[conf.Channels, frmDisplayCapture.DataLength];
            frmDisplayCapture.Irrelevant.rawData    = new float[conf.Channels, frmDisplayCapture.DataLength];
        }

        private void stimulus_Load(object sender, EventArgs e)
        {
            frmDisplayCapture.Target.rawData        = new float[conf.Channels, frmDisplayCapture.DataLength];
            frmDisplayCapture.Probe.rawData         = new float[conf.Channels, frmDisplayCapture.DataLength];
            frmDisplayCapture.Irrelevant.rawData    = new float[conf.Channels, frmDisplayCapture.DataLength];
        }

        public static Image ByteArrayToImagebyMemoryStream(byte[] imageByte)
        {
            MemoryStream ms = new MemoryStream(imageByte);
            Image image = Image.FromStream(ms);
            return image;
        }

        public void ShowStimulusSetup()
        {
            //Excuted one after "Stimulus Screen" button is clicked
            // Get the 3 second timer ready
            StimulusTimer                       = new System.Timers.Timer(conf.ERPInterval);
            StimulusTimer.Elapsed               += new System.Timers.ElapsedEventHandler(StimulusTimer_Tick);
            StimulusTimer.AutoReset             = true; // Setting is performed once (false) or have been executed (true)
            StimulusTimer.Enabled               = true; // Check for System.Timers.Timer.Elapsed event
            StimulusTimer.SynchronizingObject   = this;
        }

        private void StimulusTimer_Tick(object source, System.Timers.ElapsedEventArgs e) //(object sender, EventArgs e)
        {
            // 3000 mS have past - time to create a new cycle
            if (StartStimulus)
            {
                // Search Bluetooth Thread
                btThread = new Thread(new ThreadStart(this.ReceiveSignalAndDraw_));
                btThread.IsBackground = true;
                btThread.Start();

                frmDisplayCapture.PreDataState  = true;
                // Set a buffer for headset
                frmDisplayCapture.tempPreData   = new float[conf.Channels, conf.SamplingFrequency * conf.Fixation / 1000];
                frmDisplayCapture.PreDataIndex  = 0;

                // Time to display the stimulus
                getStimulus();

                // Save previous data structure array, and initialize a new one
                frmDisplayCapture.previousSRR = frmDisplayCapture.sRR;
                frmDisplayCapture.sRR = new StimuliReqResp();

                // Initiialze the PreData, PostData, and Data storage
                frmDisplayCapture.sRR.Data = new float[conf.Channels, conf.BufferLenght(conf.CaptureDuration, conf.SamplingFrequency)];

                // Initialize the structure states
                frmDisplayCapture.PreDataState = false;
                frmDisplayCapture.PostDataIndex = 0;
                frmDisplayCapture.PostDataState = true;

                // Detection of buffer alignment
                copyCurrentforAnalysis();

                showStimulus();

                // Increment the stats counters ("Trials")(bad and good) based on the previous capture
                if (frmDisplayCapture.previousSRR != null)
                {
                    countAvgResponseTime();
                    ERPAnalysis(); // Check for valid capture -> send to analysis
                }

                intShownStimuli++;
                checkEndRule();

            }
        }

        private void ERPAnalysis()
        {
            if (frmDisplayCapture.previousSRR.Trial_Valid == "pass")
            {
                if (frmDisplayCapture.previousSRR.StimulusType == "target")//target
                {
                    for (int i = 0; i < conf.Channels; i++) // for both channels
                    {
                        for (int j = 0; j < frmDisplayCapture.previousSRR.Data.GetLength(1); j++)
                        {
                            if (frmDisplayCapture.Target.goodTrial == 0)
                            {
                                // first good target trial; just copy the data
                                frmDisplayCapture.Target.rawData[i, j] = frmDisplayCapture.previousSRR.Data[i, j];
                            }
                            else
                            {
                                // average the target data
                                frmDisplayCapture.Target.rawData[i, j] = ((frmDisplayCapture.Target.rawData[i, j] * frmDisplayCapture.Target.goodTrial) + frmDisplayCapture.previousSRR.Data[i, j]) / (frmDisplayCapture.Target.goodTrial + 1);
                            }
                        }
                    }
                    frmDisplayCapture.Target.goodTrial++;
                    //good
                    frmDisplayCapture.dtERPAnalysis.Rows[2]["Target"] = frmDisplayCapture.Target.goodTrial;
                    frmDisplayCapture.dtERPAnalysis.Rows[3]["Target"] = frmDisplayCapture.previousSRR.reactionTime;
                }
                else if (frmDisplayCapture.previousSRR.StimulusType == "probe") //probe
                {
                    for (int i = 0; i < conf.Channels; i++)
                    {
                        for (int j = 0; j < frmDisplayCapture.previousSRR.Data.GetLength(1); j++)
                        {
                            if (frmDisplayCapture.Probe.goodTrial == 0)
                            {
                                frmDisplayCapture.Probe.rawData[i, j] = frmDisplayCapture.previousSRR.Data[i, j];
                            }
                            else
                            {
                                frmDisplayCapture.Probe.rawData[i, j] = ((frmDisplayCapture.Probe.rawData[i, j] * frmDisplayCapture.Probe.goodTrial) + frmDisplayCapture.previousSRR.Data[i, j]) / (frmDisplayCapture.Probe.goodTrial + 1);
                            }
                        }
                    }
                    frmDisplayCapture.Probe.goodTrial++;
                    //good
                    frmDisplayCapture.dtERPAnalysis.Rows[2]["Probe"] = frmDisplayCapture.Probe.goodTrial;
                    frmDisplayCapture.dtERPAnalysis.Rows[3]["Probe"] = frmDisplayCapture.previousSRR.reactionTime;
                }
                else if (frmDisplayCapture.previousSRR.StimulusType == "irrelevant") //irrelevant
                {
                    for (int i = 0; i < conf.Channels; i++)
                    {
                        for (int j = 0; j < frmDisplayCapture.previousSRR.Data.GetLength(1); j++)
                        {
                            if (frmDisplayCapture.Irrelevant.goodTrial == 0)
                            {
                                frmDisplayCapture.Irrelevant.rawData[i, j] = frmDisplayCapture.previousSRR.Data[i, j];
                            }
                            else
                            {
                                frmDisplayCapture.Irrelevant.rawData[i, j] = ((frmDisplayCapture.Irrelevant.rawData[i, j] * frmDisplayCapture.Irrelevant.goodTrial) + frmDisplayCapture.previousSRR.Data[i, j]) / (frmDisplayCapture.Irrelevant.goodTrial + 1);
                            }
                        }
                    }
                    frmDisplayCapture.Irrelevant.goodTrial++;
                    //good
                    frmDisplayCapture.dtERPAnalysis.Rows[2]["Irrelevant"] = frmDisplayCapture.Irrelevant.goodTrial;
                    frmDisplayCapture.dtERPAnalysis.Rows[3]["Irrelevant"] = frmDisplayCapture.previousSRR.reactionTime;
                }// End of averaging
            }

            // Taly the good trials
            frmDisplayCapture.dtERPAnalysis.Rows[2]["Total"] = frmDisplayCapture.Target.goodTrial + frmDisplayCapture.Probe.goodTrial + frmDisplayCapture.Irrelevant.goodTrial;

            if (true)  //Thierry: debug
            {
                ERPWave.setERPData(frmDisplayCapture.Target.rawData, frmDisplayCapture.Probe.rawData, frmDisplayCapture.Irrelevant.rawData);
                btThread_ERPDraw                = new Thread(new ThreadStart(ERPWave.ERPDraw));
                btThread_ERPDraw.IsBackground   = true;
                btThread_ERPDraw.Start();
            }
        }

        // Get the next stimulus and stimulus info from the StimulusTable datatable
        private void getStimulus()
        {
            if (conf.StimulusModality.Contains("text"))
            {
                txtStimulus.Text = StimulusParameter.ReplayTable.Rows[intShownStimuli]["Fact"].ToString();
            }
            else
            {
                txtStimulus.Text    = "[" + StimulusParameter.ReplayTable.Rows[intShownStimuli]["ID"].ToString() + "] " + StimulusParameter.ReplayTable.Rows[intShownStimuli]["Fact"].ToString();
                ShownMediaB64       = StimulusParameter.ReplayTable.Rows[intShownStimuli]["Media"].ToString();
                ShownMedia          = Convert.FromBase64String(ShownMediaB64);        
            }
            txtStimulusType.Text    = StimulusParameter.ReplayTable.Rows[intShownStimuli]["Category"].ToString();
            txtReactionTime.Text    = StimulusParameter.ReplayTable.Rows[intShownStimuli]["ReactionTime"].ToString();

            updateTrialCounts(txtStimulusType.Text);
        }

        // Start display the stimulus (text or image for now)
        private void showStimulus()
        {
            if (conf.StimulusModality.Contains("text"))
            {
                //Text
                DisplayStimulus.Visible             = false;
                lblShowStimuli.Visible              = true;
                lblShowStimuli.Text                 = StimulusParameter.ReplayTable.Rows[intShownStimuli]["Fact"].ToString();
            }
            else
            {
                //Picture
                DisplayStimulus.Visible             = true;
                lblShowStimuli.Visible              = false;
                DisplayStimulus.BackgroundImage     = ByteArrayToImagebyMemoryStream(ShownMedia);
                DisplayStimulus.Visible             = true;
            }

            // Change the boder color according to validity of trial
            string validity = StimulusParameter.ReplayTable.Rows[intShownStimuli]["Trial_Valid"].ToString();
            if (validity.Contains("pass"))
            {
                this.panel2.BackColor               = System.Drawing.Color.Lime;
            }
            else if(validity.Contains("fail"))
            {
                this.panel2.BackColor               = System.Drawing.Color.Red;
            }
            else
            {
                this.panel2.BackColor               = System.Drawing.SystemColors.ControlDark;
            }
        }

        private void checkEndRule()
        {
            if (intShownStimuli == StimulusParameter.ReplayTable.Rows.Count)
            {
                StartStimulus = false;

            }
        }

        // Detection of buffer alignment
        private void copyCurrentforAnalysis()
        {
            // also copy tempPreData in sRR.PreData
            if (frmDisplayCapture.sRR != null)
            {
                //DataRow PresentRecord = StimulusParameter.ReplayTable.Rows[CurrentRecord];
                DataRow PresentRecord = StimulusParameter.ReplayTable.Rows[intShownStimuli];

                frmDisplayCapture.sRR.Trial_Valid   = PresentRecord["Trial_Valid"].ToString();
                frmDisplayCapture.sRR.EEG_Valid     = PresentRecord["EEG_Valid"].ToString();
                frmDisplayCapture.sRR.EOG_Valid     = PresentRecord["EOG_Valid"].ToString();
                frmDisplayCapture.sRR.StimulusType  = PresentRecord["Category"].ToString();
                frmDisplayCapture.sRR.clickType     = PresentRecord["ResponseType"].ToString();
                frmDisplayCapture.sRR.reactionTime  = Convert.ToDouble( PresentRecord["ReactionTime"].ToString());

                float[] EOGData = (float[])PresentRecord["EOGData"];
                float[] ERPData = (float[])PresentRecord["ERPData"];

                // from replay table to sRR
                frmDisplayCapture.sRR.Data = new float[conf.Channels, (conf.CaptureDuration * conf.SamplingFrequency) / 1000];
                for (int i = 0; i < EOGData.Length; i++)
                {
                    frmDisplayCapture.sRR.Data[1, i] = EOGData[i] / 1000000;
                    frmDisplayCapture.sRR.Data[0, i] = ERPData[i] / 1000000;
                }
            }
        }

        private void updateTrialCounts(string category)
        {
            if (category == "probe")
            {
                intShownProbes++;
                frmDisplayCapture.Probe.trialNumber++;
            }
            else if (category == "target")
            {
                intShownTargets++;
                frmDisplayCapture.Target.trialNumber++;
            }
            else
            {
                intShownIrrelevants++;
                frmDisplayCapture.Irrelevant.trialNumber++;
            }

            frmDisplayCapture.dtERPAnalysis.Rows[1]["Target"]       = intShownTargets;
            frmDisplayCapture.dtERPAnalysis.Rows[1]["Probe"]        = intShownProbes;
            frmDisplayCapture.dtERPAnalysis.Rows[1]["Irrelevant"]   = intShownIrrelevants;
            frmDisplayCapture.dtERPAnalysis.Rows[1]["Total"]        = intShownTargets + intShownProbes + intShownIrrelevants;
        }

        private void countAvgResponseTime()
        {
            int ReactionClickIndex = 0;
            try
            {
                if (frmDisplayCapture.previousSRR.StimulusType != "none" && frmDisplayCapture.previousSRR.clickType != "none")
                {
                    if (frmDisplayCapture.previousSRR.reactionTime > 100 && frmDisplayCapture.previousSRR.reactionTime <= conf.AnswerWindow)
                    {
                        if (frmDisplayCapture.previousSRR.reactionTime == -1)
                            frmDisplayCapture.previousSRR.reactionTime = 0; //reaction time

                        if (frmDisplayCapture.previousSRR.StimulusType == "target")
                        {
                            ReactionClickIndex = 0;
                        }
                        else if (frmDisplayCapture.previousSRR.StimulusType == "probe")
                        {
                            ReactionClickIndex = 1;
                        }
                        else
                        {
                            ReactionClickIndex = 2;
                        }
                        ReactionClick[ReactionClickIndex]++;

                        if (frmDisplayCapture.previousSRR.StimulusType == "target")//target 
                        {
                            if ((frmDisplayCapture.previousSRR.clickType == "right") || (frmDisplayCapture.previousSRR.clickType == "left"))
                            {
                                frmDisplayCapture.Target.ReactionTime = ((frmDisplayCapture.Target.ReactionTime * (ReactionClick[0] - 1)) + (frmDisplayCapture.previousSRR.reactionTime)) / (ReactionClick[0]);

                                if (frmDisplayCapture.previousSRR.clickType == "left")//left button
                                {
                                    frmDisplayCapture.Target.correctClick++;
                                }
                                frmDisplayCapture.dtERPAnalysis.Rows[3]["Target"] = frmDisplayCapture.Target.ReactionTime;
                            }
                        }
                        else if (frmDisplayCapture.previousSRR.StimulusType == "probe")//probe
                        {
                            if ((frmDisplayCapture.previousSRR.clickType == "right") || (frmDisplayCapture.previousSRR.clickType == "left"))
                            {
                                frmDisplayCapture.Probe.ReactionTime = ((frmDisplayCapture.Probe.ReactionTime * (ReactionClick[1] - 1)) + (frmDisplayCapture.previousSRR.reactionTime)) / (ReactionClick[1]);

                                if (frmDisplayCapture.previousSRR.clickType == "right")//right button
                                {
                                    frmDisplayCapture.Probe.correctClick++;
                                }
                                frmDisplayCapture.dtERPAnalysis.Rows[3]["Probe"] = frmDisplayCapture.Probe.ReactionTime;
                            }
                        }
                        else if (frmDisplayCapture.previousSRR.StimulusType == "irrelevant")//irrelevant
                        {
                            if ((frmDisplayCapture.previousSRR.clickType == "right") || (frmDisplayCapture.previousSRR.clickType == "left"))
                            {
                                frmDisplayCapture.Irrelevant.ReactionTime = ((frmDisplayCapture.Irrelevant.ReactionTime * (ReactionClick[2] - 1)) + (frmDisplayCapture.previousSRR.reactionTime)) / (ReactionClick[2]);

                                if (frmDisplayCapture.previousSRR.clickType == "right")//right button
                                {
                                    frmDisplayCapture.Irrelevant.correctClick++;
                                }
                                frmDisplayCapture.dtERPAnalysis.Rows[3]["Irrelevant"] = frmDisplayCapture.Irrelevant.ReactionTime;
                            }
                        }
                    }
                }

                //Acc %.
                if (frmDisplayCapture.Target.correctClick > 0)
                {
                    frmDisplayCapture.Target.Accuracy = ((float)frmDisplayCapture.Target.correctClick / (float)frmDisplayCapture.Target.trialNumber) * 100;
                    frmDisplayCapture.dtERPAnalysis.Rows[4]["Target"] = frmDisplayCapture.Target.Accuracy;
                }
                if (frmDisplayCapture.Probe.correctClick > 0)
                {
                    frmDisplayCapture.Probe.Accuracy = ((float)frmDisplayCapture.Probe.correctClick / (float)frmDisplayCapture.Probe.trialNumber) * 100;
                    frmDisplayCapture.dtERPAnalysis.Rows[4]["Probe"] = frmDisplayCapture.Probe.Accuracy;
                }
                if (frmDisplayCapture.Irrelevant.correctClick > 0)
                {
                    frmDisplayCapture.Irrelevant.Accuracy = ((float)frmDisplayCapture.Irrelevant.correctClick / (float)frmDisplayCapture.Irrelevant.trialNumber) * 100;
                    frmDisplayCapture.dtERPAnalysis.Rows[4]["Irrelevant"] = frmDisplayCapture.Irrelevant.Accuracy;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this.Label004 + ex.Message.ToString());
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (PauseState == false)
            {
                StimulusTimer.Stop();
                StimulusTimer.Enabled = false;
                PauseState = true;
                this.btnPause.Text = "Continue";
            }
            else
            {
                StimulusTimer.Enabled = true;
                StimulusTimer.Start();
                PauseState = false;
                this.btnPause.Text = "Pause";
            }
        }
    }
}

﻿namespace Brainwave.Replay
{
    partial class frmDisplayCapture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDisplayCapture));
            this.label2 = new System.Windows.Forms.Label();
            this.btRcvTimeLbl = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtReactionTime = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtStimulus = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtStimulusType = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dgERPAnalysis = new System.Windows.Forms.DataGridView();
            this.gbxWaveform = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnStartStimulus = new System.Windows.Forms.Button();
            this.DisplayStimulus = new System.Windows.Forms.PictureBox();
            this.lblShowStimuli = new System.Windows.Forms.Label();
            this.GroupBoxLocation = new System.Windows.Forms.GroupBox();
            this.txtMachine = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnPause = new System.Windows.Forms.Button();
            this.ERPWave = new Brainwave.Replay.ERPWaveControl();
            this.EEGwave = new Brainwave.Replay.WaveControl();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgERPAnalysis)).BeginInit();
            this.gbxWaveform.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DisplayStimulus)).BeginInit();
            this.GroupBoxLocation.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(816, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = " Connecting:";
            // 
            // btRcvTimeLbl
            // 
            this.btRcvTimeLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btRcvTimeLbl.AutoSize = true;
            this.btRcvTimeLbl.BackColor = System.Drawing.Color.Transparent;
            this.btRcvTimeLbl.ForeColor = System.Drawing.Color.Black;
            this.btRcvTimeLbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btRcvTimeLbl.Location = new System.Drawing.Point(819, 33);
            this.btRcvTimeLbl.Name = "btRcvTimeLbl";
            this.btRcvTimeLbl.Size = new System.Drawing.Size(61, 13);
            this.btRcvTimeLbl.TabIndex = 12;
            this.btRcvTimeLbl.Text = "( 00:00:00 )";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.ERPWave);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 9F);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(5, 296);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(798, 278);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ERP Waveform";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.txtReactionTime);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.txtStimulus);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.txtStimulusType);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(813, 306);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(296, 106);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Stimulus Info";
            // 
            // txtReactionTime
            // 
            this.txtReactionTime.Enabled = false;
            this.txtReactionTime.Location = new System.Drawing.Point(112, 74);
            this.txtReactionTime.Name = "txtReactionTime";
            this.txtReactionTime.Size = new System.Drawing.Size(178, 20);
            this.txtReactionTime.TabIndex = 5;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(25, 77);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(82, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Reaction Time: ";
            // 
            // txtStimulus
            // 
            this.txtStimulus.Enabled = false;
            this.txtStimulus.Location = new System.Drawing.Point(112, 46);
            this.txtStimulus.Name = "txtStimulus";
            this.txtStimulus.Size = new System.Drawing.Size(178, 20);
            this.txtStimulus.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(25, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Stimulus : ";
            // 
            // txtStimulusType
            // 
            this.txtStimulusType.Enabled = false;
            this.txtStimulusType.Location = new System.Drawing.Point(112, 16);
            this.txtStimulusType.Name = "txtStimulusType";
            this.txtStimulusType.Size = new System.Drawing.Size(178, 20);
            this.txtStimulusType.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(25, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Stimulus Type : ";
            // 
            // dgERPAnalysis
            // 
            this.dgERPAnalysis.AllowUserToAddRows = false;
            this.dgERPAnalysis.AllowUserToDeleteRows = false;
            this.dgERPAnalysis.AllowUserToResizeColumns = false;
            this.dgERPAnalysis.AllowUserToResizeRows = false;
            this.dgERPAnalysis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dgERPAnalysis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgERPAnalysis.Location = new System.Drawing.Point(813, 418);
            this.dgERPAnalysis.MultiSelect = false;
            this.dgERPAnalysis.Name = "dgERPAnalysis";
            this.dgERPAnalysis.ReadOnly = true;
            this.dgERPAnalysis.RowHeadersVisible = false;
            this.dgERPAnalysis.RowTemplate.Height = 24;
            this.dgERPAnalysis.Size = new System.Drawing.Size(296, 150);
            this.dgERPAnalysis.TabIndex = 27;
            // 
            // gbxWaveform
            // 
            this.gbxWaveform.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxWaveform.BackColor = System.Drawing.Color.Transparent;
            this.gbxWaveform.Controls.Add(this.EEGwave);
            this.gbxWaveform.Font = new System.Drawing.Font("Arial", 9F);
            this.gbxWaveform.ForeColor = System.Drawing.Color.White;
            this.gbxWaveform.Location = new System.Drawing.Point(5, 2);
            this.gbxWaveform.Name = "gbxWaveform";
            this.gbxWaveform.Size = new System.Drawing.Size(798, 294);
            this.gbxWaveform.TabIndex = 28;
            this.gbxWaveform.TabStop = false;
            this.gbxWaveform.Text = "EEG Waveform";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.txtComments);
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(5, 579);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(798, 82);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Comments during test";
            // 
            // txtComments
            // 
            this.txtComments.Location = new System.Drawing.Point(6, 16);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(781, 57);
            this.txtComments.TabIndex = 11;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.SystemColors.Control;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnExit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnExit.Location = new System.Drawing.Point(1005, 71);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(104, 25);
            this.btnExit.TabIndex = 29;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnStartStimulus
            // 
            this.btnStartStimulus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStartStimulus.BackColor = System.Drawing.SystemColors.Control;
            this.btnStartStimulus.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnStartStimulus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnStartStimulus.Location = new System.Drawing.Point(1005, 11);
            this.btnStartStimulus.Name = "btnStartStimulus";
            this.btnStartStimulus.Size = new System.Drawing.Size(104, 25);
            this.btnStartStimulus.TabIndex = 38;
            this.btnStartStimulus.Text = "Start";
            this.btnStartStimulus.UseVisualStyleBackColor = true;
            this.btnStartStimulus.Click += new System.EventHandler(this.btnStartStimulus_Click);
            // 
            // DisplayStimulus
            // 
            this.DisplayStimulus.BackColor = System.Drawing.Color.Blue;
            this.DisplayStimulus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DisplayStimulus.Location = new System.Drawing.Point(6, 11);
            this.DisplayStimulus.Name = "DisplayStimulus";
            this.DisplayStimulus.Size = new System.Drawing.Size(284, 175);
            this.DisplayStimulus.TabIndex = 39;
            this.DisplayStimulus.TabStop = false;
            // 
            // lblShowStimuli
            // 
            this.lblShowStimuli.BackColor = System.Drawing.Color.Blue;
            this.lblShowStimuli.ForeColor = System.Drawing.Color.White;
            this.lblShowStimuli.Location = new System.Drawing.Point(6, 11);
            this.lblShowStimuli.Margin = new System.Windows.Forms.Padding(0);
            this.lblShowStimuli.Name = "lblShowStimuli";
            this.lblShowStimuli.Size = new System.Drawing.Size(284, 175);
            this.lblShowStimuli.TabIndex = 40;
            this.lblShowStimuli.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GroupBoxLocation
            // 
            this.GroupBoxLocation.Controls.Add(this.txtMachine);
            this.GroupBoxLocation.Controls.Add(this.txtLocation);
            this.GroupBoxLocation.ForeColor = System.Drawing.Color.White;
            this.GroupBoxLocation.Location = new System.Drawing.Point(813, 579);
            this.GroupBoxLocation.Name = "GroupBoxLocation";
            this.GroupBoxLocation.Size = new System.Drawing.Size(296, 82);
            this.GroupBoxLocation.TabIndex = 41;
            this.GroupBoxLocation.TabStop = false;
            this.GroupBoxLocation.Text = "Location / Machine";
            // 
            // txtMachine
            // 
            this.txtMachine.Location = new System.Drawing.Point(6, 53);
            this.txtMachine.Name = "txtMachine";
            this.txtMachine.Size = new System.Drawing.Size(284, 20);
            this.txtMachine.TabIndex = 43;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(6, 19);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(284, 20);
            this.txtLocation.TabIndex = 42;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel2.Controls.Add(this.lblShowStimuli);
            this.panel2.Controls.Add(this.DisplayStimulus);
            this.panel2.Location = new System.Drawing.Point(813, 104);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(296, 196);
            this.panel2.TabIndex = 42;
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(1005, 42);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(104, 23);
            this.btnPause.TabIndex = 43;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // ERPWave
            // 
            this.ERPWave.BackColor = System.Drawing.Color.Black;
            this.ERPWave.Location = new System.Drawing.Point(7, 20);
            this.ERPWave.Name = "ERPWave";
            this.ERPWave.Size = new System.Drawing.Size(780, 252);
            this.ERPWave.TabIndex = 0;
            // 
            // EEGwave
            // 
            this.EEGwave.BackColor = System.Drawing.Color.Black;
            this.EEGwave.Location = new System.Drawing.Point(6, 20);
            this.EEGwave.Name = "EEGwave";
            this.EEGwave.Size = new System.Drawing.Size(781, 268);
            this.EEGwave.TabIndex = 0;
            // 
            // frmDisplayCapture
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1117, 721);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.GroupBoxLocation);
            this.Controls.Add(this.btnStartStimulus);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgERPAnalysis);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btRcvTimeLbl);
            this.Controls.Add(this.gbxWaveform);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1133, 760);
            this.MinimumSize = new System.Drawing.Size(1133, 760);
            this.Name = "frmDisplayCapture";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Brain Fingerprinting";
            this.Load += new System.EventHandler(this.frmCapture_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgERPAnalysis)).EndInit();
            this.gbxWaveform.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DisplayStimulus)).EndInit();
            this.GroupBoxLocation.ResumeLayout(false);
            this.GroupBoxLocation.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label btRcvTimeLbl;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtReactionTime;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtStimulus;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dgERPAnalysis;
        private System.Windows.Forms.GroupBox gbxWaveform;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtStimulusType;
        private System.Windows.Forms.Button btnStartStimulus;
        private ERPWaveControl ERPWave;
        private WaveControl EEGwave;
        private System.Windows.Forms.PictureBox DisplayStimulus;
        private System.Windows.Forms.Label lblShowStimuli;
        private System.Windows.Forms.GroupBox GroupBoxLocation;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.TextBox txtMachine;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnPause;


    }
}
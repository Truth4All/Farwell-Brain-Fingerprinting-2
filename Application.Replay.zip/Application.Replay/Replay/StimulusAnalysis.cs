﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Brainwave.Replay
{
    public class StimulusAnalysis
    {
        public int RequiredTrial;
        public int trialNumber;             // 1-1000
        public int goodTrial;
        public double ReactionTime;
        public float Accuracy;              // 0-100

        public float[,] rawData;

        public int correctClick;            // Correct response times
    }

    public class StimuliReqResp
    {
        public int Sequence;                    // 1-1000

        public string StimulusSet;              // Set_GUID
        public string StimulusGroup;            // Group_GUID
        public string StimulusItem;             // 0=Target, 1=Probe, 2-9=Irrelevant A-H Thierry: moved to textual representation
        public string Trial_Valid;              // Indicator if the trial capture was successfull
        public string EEG_Valid;                // Indicator if the trial EEG capture was successfull
        public string EOG_Valid;                // Indicator if the trial EOG capture was successfull

        public string StimulusType = "none";    // 0 = Target, 1 = Probe, 2 = Irrelevant -1 is none 
        public string StimulusText;             // Stimulus text from DB
        public string StimulusMediaType;        // MIME-type for stimulus
        public byte[] StimulusMedia;            // Content of the stimulus

        public double[] ERPRange;
        public string clickType = "none";
        public double reactionTime = -1;        // If no response or double click then make this 0

        public float[,] PreData;                // 
        public float[,] PostData;               //
        public float[,] Data;                   // Data is in Volts


    }
}

﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System;


namespace Brainwave.Replay
{
    public class ERPWaveControl : System.Windows.Forms.UserControl
    {
        public float test;
        public float test2; 
        
        private System.Windows.Forms.Panel RangePanel;
        private System.Windows.Forms.Panel palWaveform;
        private float floatActual_uV_1;

        private float[] currentData, previousData;
        private float[] floatArrayAverage, floatArraySum;
        private int m_Channel, m_SampleRate, m_Resolution, m_Gain;

        private float width;
        private float floatDrawY = 1.5f;//2.4f;
        private float floatMathPow = (float)Math.Pow(2, 23) - 1;
        public int ERPType = 0; //ERPType  0:Fz 1:Cz 2:Pz 3:EOG//default:Pz
        int _DataLength;

        float[,] _TargetData;
        float[,] _ProbeData;
        float[,] _IrrelevantData;

        float[,] _TargetDraw;
        float[,] _ProbeDraw;
        float[,] _IrrelevantDraw;

        // Set initial value of drawings related variables
        private Graphics g, r;
        private Pen[] DrawPen;
        private float[] floatX1, floatY1, floatX2, floatY2;  
        private GraphicsPath myPath_1 = new GraphicsPath();
        private GraphicsPath myPath_2 = new GraphicsPath();
        private Color[] ColorSet = { Color.Red, Color.Green, Color.Blue, Color.Yellow, Color.White };

        //Draw a dotted line
        private Pen pen2 = new Pen(Color.Gray, 1);
        public System.Windows.Forms.TrackBar trackbar_HightBar;
        private System.Windows.Forms.Label lbl_Height;
        private Pen pen3 = new Pen(Color.Gray, 1);

        //Average
        private float targetAverage, targetSum;
        private float probeAverage, probeSum;
        private float irrelevantAverage, irrelevantSum;

        int startDrawPoint;

        public ERPWaveControl()
        {            
            InitializeComponent();

            //Draw a dotted line            
            pen2.DashStyle = DashStyle.Custom;
            pen2.DashPattern = new float[] { 1f, 1f };
            pen3.DashStyle = DashStyle.Custom;
            pen3.DashPattern = new float[] { 1f, 5f };
        }

        public void setting(int inChannel, int inSampleRate, int inResolution, int inGain, int DataLength)
        {
            m_Channel = inChannel;
            m_SampleRate = inSampleRate;
            m_Resolution = inResolution;
            m_Gain = inGain;
            _DataLength = DataLength;

            _TargetDraw = new float[m_Channel + 1, _DataLength];
            _ProbeDraw = new float[m_Channel + 1, _DataLength];
            _IrrelevantDraw = new float[m_Channel + 1, _DataLength];

            _TargetData = new float[m_Channel + 1, _DataLength];
            _ProbeData = new float[m_Channel + 1, _DataLength];
            _IrrelevantData = new float[m_Channel + 1, _DataLength];

            currentData = new float[m_Channel];
            previousData = new float[m_Channel];

            floatArrayAverage = new float[m_Channel];
            floatArraySum = new float[m_Channel];

            //Draw
            g = this.palWaveform.CreateGraphics();
            r = this.RangePanel.CreateGraphics();
            floatX1 = new float[m_Channel];
            floatY1 = new float[m_Channel];
            floatX2 = new float[m_Channel];
            floatY2 = new float[m_Channel];
            DrawPen = new Pen[m_Channel + 1];

            //Event to be drawn before calculating the starting point
            startDrawPoint = (int)Math.Ceiling((double)(750 * m_SampleRate) / 1000);

            //Panel Width and height
            width = this.palWaveform.Width;

            trackbar_HightBar.Value = 7;
            lbl_Height.Text = (2.5f * (Math.Pow(2, trackbar_HightBar.Value - 1))).ToString();

            //Set voltage value to be displayed
            floatActual_uV_1 = 100.00f * m_Gain;

        }

        public void setERPData(float[,] TargetData, float[,] ProbeData, float[,] IrrelevantData)
        {            
            _TargetData = TargetData;
            _ProbeData = ProbeData;
            _IrrelevantData = IrrelevantData;
        }

        public void ERPDraw()
        {
            g.Clear(palWaveform.BackColor);
            r.Clear(RangePanel.BackColor);

            for (int i = 0; i < m_Channel + 1; i++)
            {
                DrawPen[i] = new Pen(ColorSet[i % ColorSet.Length], 1.6f);
            }

            //Calculated in advance
            int erpExceptData = (int)Math.Ceiling((double)((3050) * m_SampleRate) / 1000);// DEBUG: (why 3050????) (data length - 750)

            int j = ERPType;    //0:Pz  1:EOG  //0:EOG 1:Fz 2:Cz 3:Pz //default:Cz

            //Dotted EEG voltage value and voltage value

            g.DrawLine(pen3, 0, palWaveform.Height / 2 - ((palWaveform.Height / 10) * -1), width, palWaveform.Height / 2 - ((palWaveform.Height / 10) * -1));
            g.DrawLine(pen3, 0, palWaveform.Height / 2 - (palWaveform.Height / 10), width, palWaveform.Height / 2 - (palWaveform.Height / 10));

            r.DrawString(" " + (Convert.ToDouble(lbl_Height.Text.ToString()) / 10).ToString("0.00").ToString() + " uV  \n" +
                                ((Convert.ToDouble(lbl_Height.Text.ToString()) / 10) * -1).ToString("0.00").ToString() + " uV",
                                new Font("Arial", 9, FontStyle.Bold),
                                DrawPen[0].Brush, 65,
                                (palWaveform.Height) / 2 - 12);
            r.DrawString("ERP", new Font("Arial", 9, FontStyle.Bold), DrawPen[0].Brush, 28, (palWaveform.Height / 2 - 12));

            for (int i = startDrawPoint; i < _DataLength - 1; i++)
            {
                // target
                {
                    //Obtain the average offset compensation as a way
                    if (i == _DataLength - 2)
                        targetAverage = targetSum / m_SampleRate;

                    //Offset compensation voltage value
                    if (i == startDrawPoint + 1)
                    {
                        targetSum = 0;
                    }

                    if (i >= startDrawPoint && i < m_SampleRate + startDrawPoint)
                    {
                        targetSum = targetSum + _TargetData[j, i];
                    }

                    if (i > startDrawPoint)
                    {
                        _TargetDraw[j, i] = _TargetData[j, i] - targetAverage;
                    }

                    if (_TargetDraw[j, i] > floatDrawY)
                    {
                        _TargetDraw[j, i] = floatDrawY;
                    }
                    else if (_TargetDraw[j, i] < (floatDrawY * (-1)))
                    {
                        _TargetDraw[j, i] = (floatDrawY * (-1));
                    }
                    else
                    {
                        _TargetDraw[j, i] = palWaveform.Height / 2 - (_TargetDraw[j, i] * palWaveform.Height / floatDrawY);
                    }

                    if (i > startDrawPoint + 1)
                    {
                        floatX1[j] = (i - 1 - startDrawPoint) * width / erpExceptData;
                        floatY1[j] = _TargetDraw[j, i - 1];
                        floatX2[j] = (i - startDrawPoint) * width / erpExceptData;
                        floatY2[j] = _TargetDraw[j, i];

                        Point[] PointArray =                                
                            {
                                new Point(Convert.ToInt32(Math.Round(floatX1[j],0)),Convert.ToInt32(Math.Round(floatY1[j],0))),
                                new Point(Convert.ToInt32(Math.Round(floatX2[j],0)),Convert.ToInt32(Math.Round(floatY2[j],0))),
                            };

                        myPath_1.AddLines(PointArray);
                        g.DrawPath(DrawPen[0], myPath_1);
                        myPath_1.Reset();
                    }
                }

                //Irrelevant
                {
                    //Obtain the average offset compensation as a way
                    if (i == _DataLength-2)
                        irrelevantAverage = irrelevantSum / m_SampleRate;

                    //Offset compensation voltage value
                    if (i == startDrawPoint+1)
                    {
                        irrelevantSum = 0;
                    }

                    if (i >= startDrawPoint && i < m_SampleRate + startDrawPoint)                        
                    {
                        irrelevantSum = irrelevantSum + _IrrelevantData[j, i];
                    }

                    if (i > startDrawPoint)
                    {
                        _IrrelevantDraw[j, i] = _IrrelevantData[j, i] - irrelevantAverage;
                    }

                    if (_IrrelevantDraw[j, i] > floatDrawY)
                    {
                        _IrrelevantDraw[j, i] = floatDrawY;
                    }
                    else if (_IrrelevantDraw[j, i] < (floatDrawY * (-1)))
                    {
                        _IrrelevantDraw[j, i] = (floatDrawY * (-1));
                    }
                    else
                    {
                        _IrrelevantDraw[j, i] = palWaveform.Height / 2 - (_IrrelevantDraw[j, i] * palWaveform.Height / floatDrawY);
                    }

                    if (i > startDrawPoint+1)
                    {
                        floatX1[j] = (i - 1 - startDrawPoint) * width / erpExceptData;
                        floatY1[j] = _IrrelevantDraw[j, i - 1];
                        floatX2[j] = (i-startDrawPoint) * width / erpExceptData;
                        floatY2[j] = _IrrelevantDraw[j, i];

                        Point[] PointArray =                                
                            {
                                new Point(Convert.ToInt32(Math.Round(floatX1[j],0)),Convert.ToInt32(Math.Round(floatY1[j],0))),
                                new Point(Convert.ToInt32(Math.Round(floatX2[j],0)),Convert.ToInt32(Math.Round(floatY2[j],0))),
                            };

                        myPath_1.AddLines(PointArray);
                        g.DrawPath(DrawPen[1], myPath_1);
                        myPath_1.Reset();
                    }
                }

                //Probe
                {
                    //Obtain the average offset compensation as a way
                    if (i == _DataLength - 2)
                        probeAverage = probeSum / m_SampleRate;

                    //Offset compensation voltage value
                    if (i == startDrawPoint + 1)
                    {
                        probeSum = 0;
                    }

                    if (i >= startDrawPoint && i < m_SampleRate + startDrawPoint)           
                    {
                        probeSum = probeSum + _ProbeData[j, i];
                    }

                    if (i > startDrawPoint)
                    {
                        _ProbeDraw[j, i] = _ProbeData[j, i] - probeAverage;
                    }

                    if (_ProbeDraw[j, i] > floatDrawY)
                    {
                        _ProbeDraw[j, i] = floatDrawY;
                    }
                    else if (_ProbeDraw[j, i] < (floatDrawY * (-1)))
                    {
                        _ProbeDraw[j, i] = (floatDrawY * (-1));
                    }
                    else
                    {
                        _ProbeDraw[j, i] = palWaveform.Height / 2 - (_ProbeDraw[j, i] * palWaveform.Height / floatDrawY);
                    }

                    if (i > startDrawPoint+1)
                    {
                        floatX1[j] = (i - 1 - startDrawPoint) * width / erpExceptData;
                        floatY1[j] = _ProbeDraw[j, i - 1];
                        floatX2[j] = (i-startDrawPoint) * width / erpExceptData;
                        floatY2[j] = _ProbeDraw[j, i];

                        Point[] PointArray =                                
                            {
                                new Point(Convert.ToInt32(Math.Round(floatX1[j],0)),Convert.ToInt32(Math.Round(floatY1[j],0))),
                                new Point(Convert.ToInt32(Math.Round(floatX2[j],0)),Convert.ToInt32(Math.Round(floatY2[j],0))),
                            };

                        myPath_1.AddLines(PointArray);
                        g.DrawPath(DrawPen[2], myPath_1);
                        myPath_1.Reset();
                    }
                }
            }
        }

        private void InitializeComponent()
        {
            this.RangePanel = new System.Windows.Forms.Panel();
            this.palWaveform = new System.Windows.Forms.Panel();
            this.trackbar_HightBar = new System.Windows.Forms.TrackBar();
            this.lbl_Height = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackbar_HightBar)).BeginInit();
            this.SuspendLayout();
            // 
            // RangePanel
            // 
            this.RangePanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.RangePanel.BackColor = System.Drawing.Color.Black;
            this.RangePanel.Location = new System.Drawing.Point(56, 7);
            this.RangePanel.Name = "RangePanel";
            this.RangePanel.Size = new System.Drawing.Size(132, 620);
            this.RangePanel.TabIndex = 12;
            // 
            // palWaveform
            // 
            this.palWaveform.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.palWaveform.AutoSize = true;
            this.palWaveform.BackColor = System.Drawing.Color.Black;
            this.palWaveform.Location = new System.Drawing.Point(186, 7);
            this.palWaveform.Name = "palWaveform";
            this.palWaveform.Size = new System.Drawing.Size(731, 620);
            this.palWaveform.TabIndex = 11;
            // 
            // trackbar_HightBar
            // 
            this.trackbar_HightBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.trackbar_HightBar.AutoSize = false;
            this.trackbar_HightBar.BackColor = System.Drawing.Color.Black;
            this.trackbar_HightBar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.trackbar_HightBar.LargeChange = 1;
            this.trackbar_HightBar.Location = new System.Drawing.Point(5, 8);
            this.trackbar_HightBar.Minimum = 1;
            this.trackbar_HightBar.Name = "trackbar_HightBar";
            this.trackbar_HightBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackbar_HightBar.Size = new System.Drawing.Size(45, 620);
            this.trackbar_HightBar.TabIndex = 22;
            this.trackbar_HightBar.Value = 1;
            this.trackbar_HightBar.ValueChanged += new System.EventHandler(this.trackbar_HightBar_ValueChanged);
            // 
            // lbl_Height
            // 
            this.lbl_Height.AutoSize = true;
            this.lbl_Height.BackColor = System.Drawing.Color.Black;
            this.lbl_Height.ForeColor = System.Drawing.Color.White;
            this.lbl_Height.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Height.Location = new System.Drawing.Point(39, 280);
            this.lbl_Height.Name = "lbl_Height";
            this.lbl_Height.Size = new System.Drawing.Size(11, 12);
            this.lbl_Height.TabIndex = 24;
            this.lbl_Height.Text = "0";
            // 
            // ERPWaveControl
            // 
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.palWaveform);
            this.Controls.Add(this.lbl_Height);
            this.Controls.Add(this.trackbar_HightBar);
            this.Controls.Add(this.RangePanel);
            this.Name = "ERPWaveControl";
            this.Size = new System.Drawing.Size(924, 634);
            ((System.ComponentModel.ISupportInitialize)(this.trackbar_HightBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void trackbar_HightBar_ValueChanged(object sender, EventArgs e)
        {
            lbl_Height.Text = (1.25f * (Math.Pow(2, trackbar_HightBar.Value - 1))).ToString();
            floatDrawY = (float)(Convert.ToDouble(lbl_Height.Text.ToString()) * 2 * 0.000001f);
        }
    }
}
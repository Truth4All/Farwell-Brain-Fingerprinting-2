﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BrainFingerprinting Replay")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Brain Fingerprinting, LLC")]
[assembly: AssemblyProduct("BrainFingerprinting")]
[assembly: AssemblyCopyright("Copyright © 2017, Brain Fingerprinting, LLC")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("847AAE4B-3B5A-4188-A7DD-8896854902BE")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

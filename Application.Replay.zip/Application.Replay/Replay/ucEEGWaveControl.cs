﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System;


namespace Brainwave.Replay
{
    public class WaveControl : System.Windows.Forms.UserControl
    {
        private System.Windows.Forms.Panel RangePanel;
        private System.Windows.Forms.Panel palWaveform;

        private float[] currentData, previousData;
        private float[] floatArrayAverage, floatArraySum;
        private int m_Channel, m_SampleRate, m_Resolution, m_Gain, m_ShowSecond;
        private int pointCount = 0;
        private bool m_rcvComported;

        private float height, width;
        private int intExceptData;
        private float floatDrawY =1.5f;// 2.4f;
        private bool refresh = false;
        private float floatMathPow = (float)Math.Pow(2, 23) - 1;

        // Set initial value of drawings related variables
        private Graphics g, r;
        private Pen[] DrawPen;
        private String[] ChannelNameSet;
        private float[] floatX1, floatY1, floatX2, floatY2;  
        private GraphicsPath myPath_1 = new GraphicsPath();
        private GraphicsPath myPath_2 = new GraphicsPath();
        private Color[] ColorSet = { Color.Red, Color.White, Color.Orange, Color.GreenYellow };

        public System.Windows.Forms.TrackBar trackbar_HightBar;
        private System.Windows.Forms.Label lbl_Height;

        //Dotted lines pen definition
        private Pen pen2 = new Pen(Color.Gray, 1);
        private Pen pen3 = new Pen(Color.Gray, 1);

        public WaveControl()
        {
            InitializeComponent();

            //Dotted line scale reference line pattern
            pen2.DashStyle = DashStyle.Custom;
            pen2.DashPattern = new float[] { 1f, 1f };
            pen3.DashStyle = DashStyle.Custom;
            pen3.DashPattern = new float[] { 1f, 5f };
        }
        public void setting(int inChannel, int inSampleRate, int inResolution, int inGain, int inDisplayTime, bool rcvComported)
        {
            m_Channel = inChannel;
            m_SampleRate = inSampleRate;
            m_Resolution = inResolution;
            m_Gain = inGain;
            m_ShowSecond = (inDisplayTime / 1000); //Data to show (default 4000 mS)
            m_rcvComported = rcvComported;

            //ChannelName defaults
            ChannelNameSet = new String[128];
            ChannelNameSet[0] = "Pz";
            ChannelNameSet[1] = "EOG";
            ChannelNameSet[2] = "CH 2";
            ChannelNameSet[3] = "CH 3";

            currentData = new float[m_Channel];
            previousData = new float[m_Channel];

            floatArrayAverage = new float[m_Channel];
            floatArraySum = new float[m_Channel];

            //Draw
            g = this.palWaveform.CreateGraphics();
            r = this.RangePanel.CreateGraphics();
            floatX1 = new float[m_Channel];
            floatY1 = new float[m_Channel];
            floatX2 = new float[m_Channel];
            floatY2 = new float[m_Channel];

            // EEG pen definition
            DrawPen = new Pen[m_Channel];
            // each pen have their own color
            for (int i = 0; i < m_Channel; i++)
            {
                DrawPen[i] = new Pen(ColorSet[i % ColorSet.Length], 1);
            }

            //Width in point for the showned duration
            intExceptData = m_SampleRate * m_ShowSecond;

            //Panel Width and height for each channel - the height is allocated for each channel
            width = this.palWaveform.Width;            
            height = (float)(this.palWaveform.Height) / (m_Channel);

            trackbar_HightBar.Value = 7;
            lbl_Height.Text = (2.5f * (Math.Pow(2, trackbar_HightBar.Value - 1))).ToString();
        }

        public void Draw(float[] currentData)
        {            
            pointCount++;


            
            for (int j = 0; j < m_Channel; j++)
            {
                // Offset Calculation
                if (j + 1 < m_Channel)
                {
                    //Obtain the average offset compensation as a way
                    if(pointCount==m_SampleRate * m_ShowSecond)
                        floatArrayAverage[j] = floatArraySum[j] / m_SampleRate;

                    //Offset compensation voltage value
                    if (pointCount % m_SampleRate == 0)
                    {
                        floatArraySum[j] = 0;
                    }

                    if (pointCount >= 0 && pointCount < m_SampleRate)
                    {
                        floatArraySum[j] = floatArraySum[j] + currentData[j];
                    }

                    if (pointCount > 0)
                    {
                        currentData[j] = currentData[j] - floatArrayAverage[j];
                    }
                }

                currentData[j] = height / 2 - (currentData[j] * height / floatDrawY);

                //Set the coordinate values
                floatX1[j] = (pointCount - 1) * width / intExceptData;
                floatY1[j] = previousData[j] + (height * j);
                floatX2[j] = pointCount * width / intExceptData;
                floatY2[j] = currentData[j] + (height * j);

                Point[] PointArray =                               
                                    {new Point(Convert.ToInt32(Math.Round(floatX1[j],0)),Convert.ToInt32(Math.Round(floatY1[j],0))),
                                     new Point(Convert.ToInt32(Math.Round(floatX2[j],0)),Convert.ToInt32(Math.Round(floatY2[j],0))),};

                myPath_1.AddLines(PointArray);
                g.DrawPath(DrawPen[j], myPath_1);
                myPath_1.Reset();

                previousData[j] = currentData[j];
                
                //previousData[j] does not exist for the first data point //Thierry: does not make sense with the previous statement??????
                if (pointCount == 1)
                    previousData[j] = currentData[j];


                //Dotted EEG voltage value (100 uV ~ -100 uV)
                if (pointCount == 1 || refresh)
                {
                    // draw the scale lines
                    g.DrawLine(pen3, 0, height - ((height - (height * 5 / 8)) / 2) + (height * j), width, height - ((height - (height * 5 / 8)) / 2) + (height * j));
                    g.DrawLine(pen3, 0, ((height - (height * 5 / 8)) / 2) + (height * j), width, ((height - (height * 5 / 8)) / 2) + (height * j));

                    // draw the scale values DrawString(String, Font, Brush, x location, y location)
                    // no effort is made to align scale values with scale lines
                    r.DrawString(" " + (Convert.ToDouble(lbl_Height.Text.ToString()) * 5 / 8).ToString("0.00").ToString() + " uV  \n\n\n\n" 
                                     + ((Convert.ToDouble(lbl_Height.Text.ToString()) * 5 / 8) * -1).ToString("0.00").ToString() + " uV", 
                                     new Font("Arial", 9, FontStyle.Bold), DrawPen[j].Brush, 
                                     65, 
                                     (height * j) + (height / 4) );

                    // draw the channel names
                    if (j < 4)
                        r.DrawString(ChannelNameSet[j], new Font("Arial", 9, FontStyle.Bold), DrawPen[j].Brush, 28, (height * j) + height / 2 - 6);
                    else
                        r.DrawString("Event", new Font("Arial", 9, FontStyle.Bold), DrawPen[j].Brush, 28, (height * j) + height / 2 - 6);
                }

                //Draw a dotted line (ShowSecond)
                if (j == 0 && pointCount % m_SampleRate == 0)
                {
                    g.DrawLine(pen2, pointCount * width / (m_SampleRate * m_ShowSecond), 0, pointCount * width / (m_SampleRate * m_ShowSecond), palWaveform.Height);
                }
            }

            if ((pointCount == (m_SampleRate * m_ShowSecond))||refresh)
            {
                pointCount = 0;
                g.Clear(palWaveform.BackColor);
                r.Clear(RangePanel.BackColor);
                refresh = false;
            }
        }

        public void Reset()
        {
            pointCount = 0;
            g.Clear(palWaveform.BackColor);
            r.Clear(RangePanel.BackColor);
            refresh = false;
        }

        // Detect the changes to the display gain (trackbar on the left)
        private void trackbar_HightBar_ValueChanged(object sender, EventArgs e)
        {
            lbl_Height.Text = (2.5f * (Math.Pow(2, trackbar_HightBar.Value - 1))).ToString();
            floatDrawY = (float)(Convert.ToDouble(lbl_Height.Text.ToString()) * 2 * 0.000001f);
            refresh = true;
        }

        private void InitializeComponent()
        {
            this.RangePanel = new System.Windows.Forms.Panel();
            this.palWaveform = new System.Windows.Forms.Panel();
            this.trackbar_HightBar = new System.Windows.Forms.TrackBar();
            this.lbl_Height = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackbar_HightBar)).BeginInit();
            this.SuspendLayout();
            // 
            // RangePanel
            // 
            this.RangePanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.RangePanel.BackColor = System.Drawing.Color.Black;
            this.RangePanel.Location = new System.Drawing.Point(56, 7);
            this.RangePanel.Name = "RangePanel";
            this.RangePanel.Size = new System.Drawing.Size(132, 423);
            this.RangePanel.TabIndex = 12;
            // 
            // palWaveform
            // 
            this.palWaveform.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.palWaveform.AutoSize = true;
            this.palWaveform.BackColor = System.Drawing.Color.Black;
            this.palWaveform.Location = new System.Drawing.Point(187, 7);
            this.palWaveform.Name = "palWaveform";
            this.palWaveform.Size = new System.Drawing.Size(632, 423);
            this.palWaveform.TabIndex = 11;
            // 
            // trackbar_HightBar (display gain)
            // 
            this.trackbar_HightBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.trackbar_HightBar.AutoSize = false;
            this.trackbar_HightBar.BackColor = System.Drawing.Color.Black;
            this.trackbar_HightBar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.trackbar_HightBar.LargeChange = 1;
            this.trackbar_HightBar.Location = new System.Drawing.Point(5, 8);
            this.trackbar_HightBar.Minimum = 1;
            this.trackbar_HightBar.Name = "trackbar_HightBar";
            this.trackbar_HightBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackbar_HightBar.Size = new System.Drawing.Size(45, 423);
            this.trackbar_HightBar.TabIndex = 22;
            this.trackbar_HightBar.Value = 1;
            this.trackbar_HightBar.ValueChanged += new System.EventHandler(this.trackbar_HightBar_ValueChanged);
            // 
            // lbl_Height
            // 
            this.lbl_Height.AutoSize = true;
            this.lbl_Height.BackColor = System.Drawing.Color.Black;
            this.lbl_Height.ForeColor = System.Drawing.Color.White;
            this.lbl_Height.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Height.Location = new System.Drawing.Point(39, 280);
            this.lbl_Height.Name = "lbl_Height";
            this.lbl_Height.Size = new System.Drawing.Size(11, 12);
            this.lbl_Height.TabIndex = 24;
            this.lbl_Height.Text = "0";
            // 
            // WaveControl
            // 
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.lbl_Height);
            this.Controls.Add(this.palWaveform);
            this.Controls.Add(this.trackbar_HightBar);
            this.Controls.Add(this.RangePanel);
            this.Name = "WaveControl";
            this.Size = new System.Drawing.Size(826, 437);
            ((System.ComponentModel.ISupportInitialize)(this.trackbar_HightBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
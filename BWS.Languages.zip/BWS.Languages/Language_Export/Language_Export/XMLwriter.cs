﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;
using System.Xml.Linq;

namespace Language_Export
{

    public partial class Main : Form
    {

        public void writeXML(string OutputFileName)
        {
            // Document Declaration
            XmlDocument LanguageFile = new XmlDocument();
            XmlDeclaration HeaderNode = LanguageFile.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement root = LanguageFile.DocumentElement;
            LanguageFile.InsertBefore(HeaderNode, root);

            //<BrainWave_Language>
            XmlNode RootNode = LanguageFile.CreateElement("BrainWave_Language");
            LanguageFile.AppendChild(RootNode);

            //<BF_Languages>
            XmlNode LanguagesNodes = LanguageFile.CreateElement("BF_Languages");
            RootNode.AppendChild(LanguagesNodes);

            //<Row> (SOURCE)
            XmlNode Row = LanguageFile.CreateElement("Row");
            LanguagesNodes.AppendChild(Row);

            //<GUID>
            XmlNode GUID = LanguageFile.CreateElement("GUID");
            Row.AppendChild(GUID);
            GUID.InnerText = S_Selected_Language[0]["GUID"].ToString();

			//<LCID>
            XmlNode LCID = LanguageFile.CreateElement("LCID");
            Row.AppendChild(LCID);
            LCID.InnerText = S_Selected_Language[0]["LCID"].ToString().Trim();

			//<Language>
            XmlNode Language = LanguageFile.CreateElement("Language");
            Row.AppendChild(Language);
            Language.InnerText = S_Selected_Language[0]["Language"].ToString().Trim();

			//<NativeLanguageName_LA>
            XmlNode NativeLanguageName_LA = LanguageFile.CreateElement("NativeLanguageName_LA");
            Row.AppendChild(NativeLanguageName_LA);
            NativeLanguageName_LA.InnerText = S_Selected_Language[0]["NativeLanguageName_LA"].ToString();

			//<Country>
            XmlNode Country = LanguageFile.CreateElement("Country");
            Row.AppendChild(Country);
            Country.InnerText = S_Selected_Language[0]["Country"].ToString().Trim();

			//<NativeCountryName_LA>
            XmlNode NativeCountryName_LA = LanguageFile.CreateElement("NativeCountryName_LA");
            Row.AppendChild(NativeCountryName_LA);
            NativeCountryName_LA.InnerText = S_Selected_Language[0]["NativeCountryName_LA"].ToString();

			//<Direction>
            XmlNode Direction = LanguageFile.CreateElement("Direction");
            Row.AppendChild(Direction);
            Direction.InnerText = S_Selected_Language[0]["Direction"].ToString().Trim();

            //<Row> (TRANSLATE)
            XmlNode Row2 = LanguageFile.CreateElement("Row");
            LanguagesNodes.AppendChild(Row2);

            //<GUID>
            XmlNode GUID2 = LanguageFile.CreateElement("GUID");
            Row2.AppendChild(GUID2);
            GUID2.InnerText = T_Selected_Language[0]["GUID"].ToString();

            //<LCID>
            XmlNode LCID2 = LanguageFile.CreateElement("LCID");
            Row2.AppendChild(LCID2);
            LCID2.InnerText = T_Selected_Language[0]["LCID"].ToString().Trim();

            //<Language>
            XmlNode Language2 = LanguageFile.CreateElement("Language");
            Row2.AppendChild(Language2);
            Language2.InnerText = T_Selected_Language[0]["Language"].ToString().Trim();

            //<NativeLanguageName_LA>
            XmlNode NativeLanguageName_LA2 = LanguageFile.CreateElement("NativeLanguageName_LA");
            Row2.AppendChild(NativeLanguageName_LA2);
            NativeLanguageName_LA2.InnerText = T_Selected_Language[0]["NativeLanguageName_LA"].ToString();

            //<Country>
            XmlNode Country2 = LanguageFile.CreateElement("Country");
            Row2.AppendChild(Country2);
            Country2.InnerText = T_Selected_Language[0]["Country"].ToString().Trim();

            //<NativeCountryName_LA>
            XmlNode NativeCountryName_LA2 = LanguageFile.CreateElement("NativeCountryName_LA");
            Row2.AppendChild(NativeCountryName_LA2);
            NativeCountryName_LA2.InnerText = T_Selected_Language[0]["NativeCountryName_LA"].ToString();

            //<Direction>
            XmlNode Direction2 = LanguageFile.CreateElement("Direction");
            Row2.AppendChild(Direction2);
            Direction2.InnerText = T_Selected_Language[0]["Direction"].ToString().Trim();

            //<BF_Language_Assets>
            XmlNode LanguagesAssetsNodes = LanguageFile.CreateElement("BF_Language_Assets");
            RootNode.AppendChild(LanguagesAssetsNodes);

            for (int i = 0; i < Language_Assets.Rows.Count; i++)
            {
                //<Row>
                XmlNode Row3 = LanguageFile.CreateElement("Row");
                LanguagesAssetsNodes.AppendChild(Row3);

                //<GUID>
                XmlNode GUID3 = LanguageFile.CreateElement("GUID");
                Row3.AppendChild(GUID3);
                GUID3.InnerText = Language_Assets.Rows[i]["GUID"].ToString();

                //<IsActive>
                XmlNode IsActive = LanguageFile.CreateElement("IsActive");
                Row3.AppendChild(IsActive);
                IsActive.InnerText = Language_Assets.Rows[i]["IsActive"].ToString();

                //<IsDeleted>
                XmlNode IsDeleted = LanguageFile.CreateElement("IsDeleted");
                Row3.AppendChild(IsDeleted);
                IsDeleted.InnerText = Language_Assets.Rows[i]["IsDeleted"].ToString();

                //<LCID>
                XmlNode LCID3 = LanguageFile.CreateElement("LCID");
                Row3.AppendChild(LCID3);
                LCID3.InnerText = Language_Assets.Rows[i]["LCID"].ToString().Trim();

                //<Scope>
                XmlNode Scope = LanguageFile.CreateElement("Scope");
                Row3.AppendChild(Scope);
                Scope.InnerText = Language_Assets.Rows[i]["Scope"].ToString().Trim();

                //<Usage>
                XmlNode Usage = LanguageFile.CreateElement("Usage");
                Row3.AppendChild(Usage);
                Usage.InnerText = Language_Assets.Rows[i]["Usage"].ToString().Trim();

                //<Textual>
                XmlNode Textual = LanguageFile.CreateElement("Textual");
                Row3.AppendChild(Textual);
                Textual.InnerText = Language_Assets.Rows[i]["Textual"].ToString().Trim();
            }

            // Write the XML file out
            LanguageFile.Save(OutputFileName);
        }
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Language_Export
{
    public partial class Main : Form
    {
        // Server connection (default value)
        SqlConnection connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;AttachDbFilename=C:\\ProgramData\\Brainwave\\database\\BrainwaveDB.mdf;Initial Catalog=BrainwaveDB;Integrated Security=True;Pooling=True");

        static DataTable S_Languages;
        static DataTable T_Languages;
        static DataTable Language_Assets;
        static DataRow[] S_Selected_Language;
        static DataRow[] T_Selected_Language;

        string S_Language;
        string S_LCID;
        string S_Direction;
        string T_Language;
        string T_LCID;
        string T_Direction;

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            loadComboBoxes();

            cbx_Server.Items.Add("localDB");
            cbx_Server.Items.Add("GWAPP14 Server");
            cbx_Server.Items.Add("Local Server");
            cbx_Server.SelectedItem = "localDB";
        }

        private void cbx_Server_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbx_Server.SelectedItem.ToString())
            {
                case "localDB":
                    connection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;AttachDbFilename=C:\\ProgramData\\Brainwave\\database\\BrainwaveDB.mdf;Initial Catalog=BrainwaveDB;Integrated Security=True;Pooling=True");
                    loadComboBoxes();
                    break;
                case "GWAPP14 Server":
                    connection = new SqlConnection("Data Source=192.168.5.120;Initial Catalog=Brainwave2;Integrated Security=True");
                    loadComboBoxes();
                    break;
                case "Local Server":
                    connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Brainwave2;Integrated Security=True");
                    loadComboBoxes();
                    break;
                default:
                    connection = new SqlConnection("Data Source=192.168.5.120;Initial Catalog=Brainwave2;Integrated Security=True");
                    loadComboBoxes();
                    break;
            }
        }

        private void cbx_Source_Language_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                S_Selected_Language = S_Languages.Select(String.Format("GUID = '{0}'", cbx_Source_Language.SelectedValue.ToString()));
                S_Language = S_Selected_Language[0]["Language"].ToString();
                textBox1.Text = S_Selected_Language[0]["LCID"].ToString();
                textBox5.Text = S_Selected_Language[0]["Direction"].ToString();
                textBox2.Text = getLanguageAssetCount(S_Selected_Language[0]["LCID"].ToString(), connection).ToString();
            }
            catch { }
        }

        private void cbx_Translated_Language_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                T_Selected_Language = T_Languages.Select(String.Format("GUID = '{0}'", cbx_Translated_Language.SelectedValue.ToString()));
                T_Language = T_Selected_Language[0]["Language"].ToString();
                textBox3.Text = T_Selected_Language[0]["LCID"].ToString();
                textBox6.Text = T_Selected_Language[0]["Direction"].ToString();
                textBox4.Text = getLanguageAssetCount(T_Selected_Language[0]["LCID"].ToString(), connection).ToString();
            }
            catch { }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.DefaultExt = ".xml";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Language_Assets = getLanguageAsset(textBox1.Text, textBox3.Text, connection);
                writeXML(saveFileDialog1.FileName);
              
            }

            this.Close();
        }
    }
}

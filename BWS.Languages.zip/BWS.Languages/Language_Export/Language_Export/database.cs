﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;
using System.Xml.Linq;

namespace Language_Export
{

    public partial class Main
    {
        public void loadComboBoxes()
        {
            // Get the languages from the DB
            S_Languages = getTable("BF_Languages", connection);
            S_Languages.Columns.Add("Description", typeof(string), "Language + '  (' + LCID + ')'");
            T_Languages = getTable("BF_Languages", connection);
            T_Languages.Columns.Add("Description", typeof(string), "Language + '  (' + LCID + ')'");

            // Sort the DataTables
            DataView dv = S_Languages.DefaultView;
            dv.Sort = "LCID";
            S_Languages = dv.ToTable();

            DataView dvt = T_Languages.DefaultView;
            dvt.Sort = "LCID";
            T_Languages = dvt.ToTable();

            // Bind the source selector
            cbx_Source_Language.DataSource = S_Languages;
            cbx_Source_Language.DisplayMember = "Description";
            cbx_Source_Language.ValueMember = "GUID";

            // Bind the translated selector
            cbx_Translated_Language.DataSource = T_Languages;
            cbx_Translated_Language.DisplayMember = "Description";
            cbx_Translated_Language.ValueMember = "GUID";
        }
       
        public DataTable getTable(string table, SqlConnection connection)
        {
            string query = "SELECT * FROM " +table;

            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            return dt;
        }

        public int getLanguageAssetCount(string LCID, SqlConnection connection)
        {
            int count = 0;
            connection.Open();
           
            using (SqlCommand cmd = new SqlCommand(String.Format("SELECT COUNT(*) FROM BF_Language_Assets WHERE LCID = '{0}' AND Usage='Factory'", LCID)))
            {
                cmd.Connection = connection;
                count = (int)cmd.ExecuteScalar();
            }
            
            connection.Close();
            return count;
        }

        public DataTable getLanguageAsset(string LCID1, string LCID2, SqlConnection connection)
        {
            string query = String.Format("SELECT * FROM BF_Language_Assets WHERE LCID IN('{0}','{1}') AND Usage='Factory'", LCID1, LCID2);

            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            return dt;
        }

    }
}

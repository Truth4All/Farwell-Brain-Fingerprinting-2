﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace LanguageTranslation
{
    public partial class Translate : Form
    {
        public static DataSet FromLanguage;
        public static DataSet ToLanguage;

        public string WorkingDirectory;
        public int CurrentIndex;

        public Translate()
        {
            InitializeComponent();
            ReadLanguageFile();
            ReadDestination();
        }

        private void begin_Click(object sender, EventArgs e)
        {
            insertIfNotExist(); // Save the last translation
            CurrentIndex = 0; // Index back to zero
            RefreshFields(); // Dispaly the new input and any translation if exist
        }

        private void Back_Click(object sender, EventArgs e)
        {
            insertIfNotExist();
            indexBackward();
            RefreshFields();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            insertIfNotExist();
            indexForward();
            RefreshFields();
        }

        private void End_Click(object sender, EventArgs e)
        {
            insertIfNotExist();
            lastIndex();
            RefreshFields();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            insertIfNotExist();
            ToLanguage.WriteXml(WorkingDirectory + @"\BF_Language_translated.xml");
            Application.Exit();
        }

        private void ReadLanguageFile()
        {
            FromLanguage = new DataSet();
            string filePath = SelectTextFile(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)); // Start in "My Documents"
            WorkingDirectory = Path.GetDirectoryName(filePath); // Reset the "Working Directory to the selection of the input file.
            FromLanguage.ReadXml(filePath);
        }

        private void ReadDestination()
        {
            // read the result translation if it exist, or create a new dataset if it does not exist.
            if(File.Exists(WorkingDirectory + @"\BF_Language_translated.xml"))
            {
                ToLanguage = new DataSet("BF_Language_Assets");
                ToLanguage.ReadXml(WorkingDirectory + @"\BF_Language_translated.xml");
            }
            else
            {
                ToLanguage = new DataSet("BF_Language_Assets");
                DataTable dt_Language_Asset = ToLanguage.Tables.Add("Language_Asset");
                DataColumn dc_GUID          = dt_Language_Asset.Columns.Add("GUID");
                DataColumn dc_LCID          = dt_Language_Asset.Columns.Add("LCID");
                DataColumn dc_Scope         = dt_Language_Asset.Columns.Add("Scope");
                DataColumn dc_Textual       = dt_Language_Asset.Columns.Add("Textual");
            }
        }

        private string SelectTextFile(string initialDirectory)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Language files (*.xml)|*.xml"; // only xml files
            dialog.InitialDirectory = initialDirectory;
            dialog.Title = "Select a language file";
            return (dialog.ShowDialog() == DialogResult.OK) ? dialog.FileName : null;
        }

        private void RefreshFields()
        {
            Original_TB.Text = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["Textual"].ToString();
            GetTranslatedIfExist(FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["GUID"].ToString());
            GUID_LB.Text = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["GUID"].ToString();
        }

        private void GetTranslatedIfExist(string GUID)
        {
            DataRow found = ToLanguage.Tables["Language_Asset"].Select(String.Format("GUID = '{0}'", GUID)).FirstOrDefault();
            if (found != null)
            {
                Translation_TB.Text = found["Textual"].ToString();
            }
            else
            {
                Translation_TB.Text = "";
            }
        }

        private void insertIfNotExist()
        {
            if( Translation_TB.Text.Trim() != "")
            {
                string GUID    = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["GUID"].ToString().Trim();
                DataRow found  = ToLanguage.Tables["Language_Asset"].Select(String.Format("GUID = '{0}'",GUID)).FirstOrDefault();
                if (found != null)
                {
                    found["GUID"]       = GUID;
                    found["LCID"]       = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["LCID"].ToString().Trim();
                    found["Scope"]      = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["Scope"].ToString().Trim();
                    found["Textual"]    = Translation_TB.Text.Trim();
                }
                else
                {
                    DataRow dr_add      = ToLanguage.Tables["Language_Asset"].NewRow();
                    dr_add["GUID"]      = GUID;
                    dr_add["LCID"]      = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["LCID"].ToString().Trim();
                    dr_add["Scope"]     = FromLanguage.Tables["Language_Asset"].Rows[CurrentIndex]["Scope"].ToString().Trim();
                    dr_add["Textual"]   = Translation_TB.Text.Trim();
                    ToLanguage.Tables["Language_Asset"].Rows.Add(dr_add);
                }
            }
        }

        private void indexForward()
        {
            // Go forward but not more than the last index
            CurrentIndex++;
            if(CurrentIndex >= FromLanguage.Tables["Language_Asset"].Rows.Count)
            {
                CurrentIndex = FromLanguage.Tables["Language_Asset"].Rows.Count - 1;
            }
        }

        private void indexBackward()
        {
            // Go backward but not less than zero
            CurrentIndex--;
            if (CurrentIndex < 0)
            {
                CurrentIndex = 0;
            }
        }

        private void lastIndex()
        {
            // The last insex is the count minus 1
            CurrentIndex = FromLanguage.Tables["Language_Asset"].Rows.Count - 1;
        }
    }
}

﻿namespace LanguageTranslation
{
    partial class Translate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Original_TB = new System.Windows.Forms.TextBox();
            this.Translation_TB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.begin = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.End = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.GUID_LB = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Original_TB
            // 
            this.Original_TB.Location = new System.Drawing.Point(15, 25);
            this.Original_TB.Multiline = true;
            this.Original_TB.Name = "Original_TB";
            this.Original_TB.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Original_TB.Size = new System.Drawing.Size(357, 357);
            this.Original_TB.TabIndex = 0;
            // 
            // Translation_TB
            // 
            this.Translation_TB.Location = new System.Drawing.Point(459, 25);
            this.Translation_TB.Multiline = true;
            this.Translation_TB.Name = "Translation_TB";
            this.Translation_TB.Size = new System.Drawing.Size(357, 357);
            this.Translation_TB.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Original";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(456, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Translation";
            // 
            // begin
            // 
            this.begin.Location = new System.Drawing.Point(15, 388);
            this.begin.Name = "begin";
            this.begin.Size = new System.Drawing.Size(115, 23);
            this.begin.TabIndex = 5;
            this.begin.Text = "Beginning <<";
            this.begin.UseVisualStyleBackColor = true;
            this.begin.Click += new System.EventHandler(this.begin_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(257, 388);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(115, 23);
            this.Back.TabIndex = 7;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(459, 388);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(115, 23);
            this.Next.TabIndex = 8;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // End
            // 
            this.End.Location = new System.Drawing.Point(701, 388);
            this.End.Name = "End";
            this.End.Size = new System.Drawing.Size(115, 23);
            this.End.TabIndex = 10;
            this.End.Text = ">> End";
            this.End.UseVisualStyleBackColor = true;
            this.End.Click += new System.EventHandler(this.End_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(701, 423);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(115, 23);
            this.Save.TabIndex = 11;
            this.Save.Text = "Save and Exit";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // GUID_LB
            // 
            this.GUID_LB.AutoSize = true;
            this.GUID_LB.Location = new System.Drawing.Point(71, 8);
            this.GUID_LB.Name = "GUID_LB";
            this.GUID_LB.Size = new System.Drawing.Size(0, 13);
            this.GUID_LB.TabIndex = 13;
            // 
            // Translate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 458);
            this.Controls.Add(this.GUID_LB);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.End);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.begin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Translation_TB);
            this.Controls.Add(this.Original_TB);
            this.Name = "Translate";
            this.Text = "Brainwave Translate Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Original_TB;
        private System.Windows.Forms.TextBox Translation_TB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button begin;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button End;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label GUID_LB;
    }
}


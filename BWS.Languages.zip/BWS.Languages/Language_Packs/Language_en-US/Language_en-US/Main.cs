﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Brainwave.Language
{
    public partial class Language_Installer : Form
    {
        public string connectionString;

        public Language_Installer()
        {
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", string.Format(@"{0}Brainwave.config", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles))));
            connectionString = (ConfigurationManager.ConnectionStrings["DefaultDBConnection"]).ToString();

            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void btn_Install_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string sqlScript = Brainwave.Language.Properties.Resources.BF_Language_Assets_en_US_data;
            string[] commands = sqlScript.Split(new string[] { "GO\r\n", "GO ", "GO\t" }, StringSplitOptions.RemoveEmptyEntries);
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                // Progress Bar Tracking
                int total = commands.Length;
                int count = 0;
                foreach (string individualScript in commands)
                {
                    command.CommandText = individualScript;
                    try
                    {
                        command.ExecuteNonQuery();
                        count++;
                    }
                    catch { }
                    ProgressStatus(count, total);
                }
            }
            conn.Close();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            ProgressStatus(0, 100);
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string sqlScript = Brainwave.Language.Properties.Resources.BF_Language_Assets_en_US_remove;
            string[] commands = sqlScript.Split(new string[] { "GO\r\n", "GO ", "GO\t" }, StringSplitOptions.RemoveEmptyEntries);
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                foreach (string individualScript in commands)
                {
                    command.CommandText = individualScript;
                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch { }
                }
            }
            conn.Close();
        }

        private void ProgressStatus(int count, int FullScale)
        {
            progressBar1.BeginInvoke(
                new Action(() =>
                    {
                        progressBar1.Value = 100 * (count / FullScale);
                    }
                )
            );
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Language_Import_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                System.Console.WriteLine("Please enter a filename argument.");
                return;
            }
            else
            {
                Import language = new Import();
                string result = language.import( Convert.ToString(args[0]));
                System.Console.WriteLine(result);
                return;
            }
            
 
        }
    }
}

﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Language_Import_Form
{
    public partial class Main : Form
    {
        public string ImputFilenamePath;

        // Select local SQL server
        public SqlConnection myConnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;AttachDbFilename=C:\\ProgramData\\Brainwave\\database\\BrainwaveDB.mdf;Initial Catalog=BrainwaveDB;Integrated Security=True;Pooling=True");

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            cbx_Server.Items.Add("localDB");
            cbx_Server.Items.Add("GWAPP14 Server");
            cbx_Server.Items.Add("Local Server");
            cbx_Server.SelectedItem = "localDB";
        }

        private void cbx_Server_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbx_Server.SelectedItem.ToString())
            {
                case "localDB":
                    myConnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;AttachDbFilename=C:\\ProgramData\\Brainwave\\database\\BrainwaveDB.mdf;Initial Catalog=BrainwaveDB;Integrated Security=True;Pooling=True");
                    break;

                case "GWAPP14 Server":
                    myConnection = new SqlConnection("Data Source=192.168.5.120;Initial Catalog=Brainwave2;Integrated Security=True");
                    break;

                case "Local Server":
                    myConnection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Brainwave2;Integrated Security=True");
                    break;

                default:
                    myConnection = new SqlConnection("Data Source=192.168.5.120;Initial Catalog=Brainwave2;Integrated Security=True");
                    break;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Select_Click(object sender, EventArgs e)
        {
            // Create an instance of the open file dialog box.
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Set filter options and filter index.
            openFileDialog1.Filter = "XML Files (.xml)|*.xml|All Files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Multiselect = false;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ImputFilePath.Text = openFileDialog1.FileName;
                    ImputFilenamePath = Path.ChangeExtension(openFileDialog1.FileName, ".xml");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }

        }

        private void Import_Click(object sender, EventArgs e)
        {

            Result.Text = import(ImputFilenamePath);

        }






    }
}

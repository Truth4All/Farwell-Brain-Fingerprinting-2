﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;
using System.Xml.Linq;

namespace Language_Import_Form
{
    public partial class Main : Form
    {

        public string import(string imputFile)
        {
            // Process Counters
            int SubmittedCount  = 0;
            int InsertedCount   = 0;
            int UpdatedCount    = 0;
            int Language_Count  = 0;

            // Read the XML fiel into internal structure
            XmlDocument doc = new XmlDocument();
            doc.Load(imputFile);
            XmlNode root = doc.DocumentElement;

            // Language Asset Items
            XmlNodeList rowNodes;
            rowNodes                = root.SelectNodes("BF_Language_Assets/Row");
            int numberOfRowNodes    = rowNodes.Count;

            for (int i = 0; i < numberOfRowNodes; i++)
            {
                XmlNode row         = rowNodes[i];

                string GUID         = row.SelectSingleNode("GUID").InnerText;
                string LCID         = row.SelectSingleNode("LCID").InnerText;
                string Scope        = row.SelectSingleNode("Scope").InnerText;
                string Usage        = row.SelectSingleNode("Usage").InnerText;
                string Textual      = row.SelectSingleNode("Textual").InnerText;

                if (RecordExist(GUID, LCID, Scope, Usage))
                {
                    UpdateRecord(GUID, LCID, Scope, Usage, Textual);
                    UpdatedCount++;
                }
                else{
                    InsertRecord(GUID, LCID, Scope, Usage, Textual);
                    InsertedCount++;
                }
                SubmittedCount++;
            }


            XmlNode Lrow = root.SelectSingleNode("BF_Languages/Row");
            string LGUID = Lrow.SelectSingleNode("GUID").InnerText;
            string LLCID = Lrow.SelectSingleNode("LCID").InnerText;
            string Language = Lrow.SelectSingleNode("Language").InnerText;
            string NativeLanguageName_LA = Lrow.SelectSingleNode("NativeLanguageName_LA").InnerText;
            string Country = Lrow.SelectSingleNode("Country").InnerText;
            string NativeCountryName_LA = Lrow.SelectSingleNode("NativeCountryName_LA").InnerText;
            InsertLanguage(LGUID, LLCID, Language, NativeLanguageName_LA, Country, NativeCountryName_LA);
            Language_Count++;

            string message;
            message = String.Format("Inserted {0} elements in BF_Language_Assets table \n", InsertedCount);
            message += String.Format("Updated {0} elements in BF_Language_Assets table \n", UpdatedCount);
            message += String.Format("Inserted {0} elements in BF_Languages table\n", Language_Count);
            return message;
        }

        bool RecordExist(string GUID, string LCID, string Scope, string Usage)
        {
            bool status;
            int recordCount = 0;
            myConnection.Open();

            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM BF_Language_Assets WHERE GUID=@GUID AND LCID=@LCID AND Scope=@Scope AND Usage=@Usage"))
            {
                cmd.Connection = myConnection;
                cmd.Parameters.AddWithValue("@GUID", GUID);
                cmd.Parameters.AddWithValue("@LCID", LCID);
                cmd.Parameters.AddWithValue("@Scope", Scope);
                cmd.Parameters.AddWithValue("@Usage", Usage);
                recordCount = (int)cmd.ExecuteScalar();
            }
            myConnection.Close();
            if (recordCount == 0) { status = false; } else { status = true; }
            return status;
        }

        void InsertRecord(string GUID, string LCID, string Scope, string Usage, string Textual)
        {
            myConnection.Open();

            using (SqlCommand cmd = new SqlCommand("INSERT INTO BF_Language_Assets ([GUID],[LCID],[Scope],[Usage],[Textual])VALUES(@GUID,@LCID,@Scope,@Usage,@Textual)"))
            {
                cmd.Connection = myConnection;
                cmd.Parameters.AddWithValue("@GUID", GUID);
                cmd.Parameters.AddWithValue("@LCID", LCID);
                cmd.Parameters.AddWithValue("@Scope", Scope);
                cmd.Parameters.AddWithValue("@Usage", Usage);
                cmd.Parameters.AddWithValue("@Textual", Textual);
                int rowsInserted = cmd.ExecuteNonQuery();
            }
            myConnection.Close();
        }

        void UpdateRecord(string GUID, string LCID, string Scope, string Usage, string Textual)
        {
            myConnection.Open();

            using (SqlCommand cmd = new SqlCommand("UPDATE BF_Language_Assets SET [Textual]=@Textual WHERE GUID=@GUID AND LCID=@LCID AND Scope=@Scope AND Usage=@Usage"))
            {
                cmd.Connection = myConnection;
                cmd.Parameters.AddWithValue("@GUID",                    GUID);
                cmd.Parameters.AddWithValue("@LCID",                    LCID);
                cmd.Parameters.AddWithValue("@Scope",                   Scope);
                cmd.Parameters.AddWithValue("@Usage",                   Usage);
                cmd.Parameters.AddWithValue("@Textual",                 Textual);
                int rowsUpdated = cmd.ExecuteNonQuery();
            }
            myConnection.Close();
        }

        void InsertLanguage(string LGUID, string LLCID, string Language, string NativeLanguageName_LA, string Country, string NativeCountryName_LA)
        {
            myConnection.Open();

            using (SqlCommand cmd = new SqlCommand("IF NOT EXISTS " +
                                        "(SELECT 1 FROM BF_Languages WHERE " +
                                        "[GUID] = @GUID AND [LCID] = @LCID AND [Language] = @Language ) " +
                                        "BEGIN INSERT INTO BF_Languages " +
                                        "([GUID],[LCID],[Language],[NativeLanguageName_LA],[Country],[NativeCountryName_LA])VALUES(@GUID,@LCID,@Language,@NativeLanguageName_LA,@Country,@NativeCountryName_LA) END"))
            {
                cmd.Connection = myConnection;
                cmd.Parameters.AddWithValue("GUID",                     LGUID);
                cmd.Parameters.AddWithValue("LCID",                     LLCID);
                cmd.Parameters.AddWithValue("Language",                 Language);
                cmd.Parameters.AddWithValue("NativeLanguageName_LA",    NativeLanguageName_LA);
                cmd.Parameters.AddWithValue("Country",                  Country);
                cmd.Parameters.AddWithValue("NativeCountryName_LA",     NativeCountryName_LA);
                int rowsUpdated = cmd.ExecuteNonQuery();
            }
            myConnection.Close();
        }
    }
}

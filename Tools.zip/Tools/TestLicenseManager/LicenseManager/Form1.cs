﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LicenseManager
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            ComboBoxValues();
        }

        private void ComboBoxValues()
        {
            var dict = new Dictionary<int, string>();
            dict.Add(1001, "Application License");
            dict.Add(1002, "User License");
            dict.Add(1003, "Test License");

            cb_licenseType.DataSource = new BindingSource(dict, null);
            cb_licenseType.DisplayMember = "Value";
            cb_licenseType.ValueMember = "Key";
        }

        // Truncate license table
        private void button1_Click(object sender, EventArgs e)
        {
            BrainwaveServer bs = new BrainwaveServer();
            string connectionString = bs.ConnectionString;

            SqlConnection spContentConn = new SqlConnection(connectionString);
            string sqlQuery = "TRUNCATE TABLE BF_Licenses";
            try
            {
                spContentConn.Open();
                SqlCommand sqlCmd = new SqlCommand(sqlQuery, spContentConn);
                sqlCmd.CommandTimeout = 0;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.ExecuteNonQuery();
                spContentConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BrainwaveServer bs = new BrainwaveServer();
            string connectionString = bs.ConnectionString;

            Guid g0 = Guid.NewGuid();
            Guid g1 = Guid.NewGuid();

            try
            {
                var sqlParams = new SqlParameter[10];
                sqlParams[0] = new SqlParameter("@IsActive", SqlDbType.Bit) { Value = true };
                sqlParams[1] = new SqlParameter("@IsDeleted", SqlDbType.Bit) { Value = false };
                sqlParams[2] = new SqlParameter("@ProductID", SqlDbType.Int) { Value = cb_licenseType.SelectedValue };
                sqlParams[3] = new SqlParameter("@ProductName", SqlDbType.VarChar, 255) { Value = cb_licenseType.Text };
                sqlParams[4] = new SqlParameter("@LicenseCode", SqlDbType.VarChar, 255) { Value = g0.ToString() };
                sqlParams[5] = new SqlParameter("@LicenseExpiration", SqlDbType.DateTime) { Value = Convert.ToDateTime(expirationDate.Value.ToString("yyyy-MM-dd")) };
                sqlParams[6] = new SqlParameter("@OriginalCount", SqlDbType.Int) { Value = Int32.Parse(tbx_Count.Text) };
                sqlParams[7] = new SqlParameter("@LicenseCount", SqlDbType.Int) { Value = Int32.Parse(tbx_Count.Text) };
                sqlParams[8] = new SqlParameter("@ActivationCode", SqlDbType.Int) { Value = g1.ToString() };
                sqlParams[9] = new SqlParameter("@MachineID", SqlDbType.VarChar, 255) { Value = "TestMachine" };
                SqlHelper.ExecuteNonQuery(connectionString, "AddLicenseInfo", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace LicenseManager
{
    public class BrainwaveServer
    {
        public string ConfigDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\";

        public Configuration CustomConfig;

        public string ConnectionString
        {
            get
            {
                string configFilePath = string.Format(@"{0}Brainwave.config", ConfigDirectory);

                ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
                configFileMap.ExeConfigFilename = configFilePath;
                CustomConfig = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);

                return CustomConfig.ConnectionStrings.ConnectionStrings["BrainwaveDBConnectionString"].ToString();
            }
        }


    }
}

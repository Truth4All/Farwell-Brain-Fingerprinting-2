﻿using System;
using System.Collections;
using System.DirectoryServices.AccountManagement;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SecurityCheck
{
    // Display security information for the current user

    public partial class Security_Check : Form
    {
        public Security_Check()
        {
            InitializeComponent();
        }

        // Collect and display security information at form load
        private void Form1_Load_1(object sender, EventArgs e)
        {
            // Version
            lblIsAdmin.Text = String.Format("Version: {0}", Application.ProductVersion); lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += Environment.NewLine;

            // Domain Detection (via System.Environment class)
            lblIsAdmin.Text += "Domain: " + Environment.UserDomainName.ToString(); lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += "Machine: " + Environment.MachineName.ToString(); lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += "User Name: " + Environment.UserName.ToString(); lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += "OS: " + Environment.OSVersion.ToString(); lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += Environment.NewLine;

            // PrincipalContext
            PrincipalContext ctx;
            if (IsInDomain())
            {
                ctx = new PrincipalContext(ContextType.Domain);
                lblIsAdmin.Text += "We are in a domain-connected machine"; lblIsAdmin.Text += Environment.NewLine;
            }
            else
            {
                ctx = new PrincipalContext(ContextType.Machine);
                lblIsAdmin.Text += "We are a stand-alone machine"; lblIsAdmin.Text += Environment.NewLine;
            }
            lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += Environment.NewLine;

            // UserPrincipal
            UserPrincipal user = UserPrincipal.FindByIdentity(ctx, Environment.UserName.ToString());

            // SID (domain and no-domain)
            lblIsAdmin.Text += "SID: " + user.Sid.ToString(); lblIsAdmin.Text += Environment.NewLine;

            // login name (domain and no-domain)
            lblIsAdmin.Text += "MSAM: " + user.SamAccountName.ToString(); lblIsAdmin.Text += Environment.NewLine;

            // Last Name (may be NULL)
            if (user.Surname != null){lblIsAdmin.Text += "Lastname: " + user.Surname.ToString(); lblIsAdmin.Text += Environment.NewLine;}
            else{lblIsAdmin.Text += "Lastname: NULL"; lblIsAdmin.Text += Environment.NewLine;}

            // email?? (NULL in non-domain, email on domain)
            if (user.UserPrincipalName != null){lblIsAdmin.Text += "UserPrincipalName: " + user.UserPrincipalName.ToString(); lblIsAdmin.Text += Environment.NewLine;}
            else{lblIsAdmin.Text += "UserPrincipalName: NULL"; lblIsAdmin.Text += Environment.NewLine;}

            // Full name (Login in non-domain, Full name on domain)
            lblIsAdmin.Text += "Name: " + user.Name.ToString(); lblIsAdmin.Text += Environment.NewLine;

            // Need to check if null !! (may be NULL)
            if (user.MiddleName != null){lblIsAdmin.Text += user.MiddleName.ToString(); lblIsAdmin.Text += Environment.NewLine;}
            else{lblIsAdmin.Text += "MiddleName: NULL"; lblIsAdmin.Text += Environment.NewLine;}

            // Firstname (NULL on non-domain)
            if (user.GivenName != null){lblIsAdmin.Text += "Firstname: " + user.GivenName.ToString(); lblIsAdmin.Text += Environment.NewLine;}
            else{lblIsAdmin.Text += "Firstname: NULL"; lblIsAdmin.Text += Environment.NewLine;}

            // Full name (Description on non-domain, full name on domain)
            lblIsAdmin.Text += "Display Name: " + user.DisplayName.ToString(); lblIsAdmin.Text += Environment.NewLine;

            lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += Environment.NewLine;

            // GroupPrincipal
            // Another way of detecting domain-attached  UserDomainName == MachineName
            PrincipalContext pc = new PrincipalContext((Environment.UserDomainName == Environment.MachineName ? ContextType.Machine : ContextType.Domain), Environment.UserDomainName);

            GroupPrincipal gp = GroupPrincipal.FindByIdentity(pc, "BF_Managers");
            UserPrincipal up = UserPrincipal.FindByIdentity(pc, Environment.UserName);

            if (gp != null) // the group may not exist in Active directory
            {
                if (up.IsMemberOf(gp))
                {
                    lblIsAdmin.Text += "We are part of BF_Managers"; lblIsAdmin.Text += Environment.NewLine;
                }
                else
                {
                    lblIsAdmin.Text += "We are nor part of BF_Managers"; lblIsAdmin.Text += Environment.NewLine;
                }
            }
            else
            {
                lblIsAdmin.Text += "No Brainwave groups were setup in AD"; lblIsAdmin.Text += Environment.NewLine;
            }

            // Check Brainwave Monitor Service
            lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += "SID: " + "S-1-5-18" + " (Account used by Brainwave Monitor Service)"; lblIsAdmin.Text += Environment.NewLine;
            lblIsAdmin.Text += "Brainwave Server Address: " + Microsoft.Win32.Registry.GetValue(@"HKEY_USERS\S-1-5-18\Software\Brainwave\", "BrainwaveServer", "Not found yet");

            // Fill the comboBox
            PrincipalContext AD = new PrincipalContext(ContextType.Domain, Environment.UserDomainName);
            UserPrincipal u = new UserPrincipal(AD);
            PrincipalSearcher search = new PrincipalSearcher(u);

            foreach (UserPrincipal result in search.FindAll())
            {
                if (result.DisplayName != null)
                {
                    comboBox1.Items.Add(result.DisplayName);
                }
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public static bool IsInDomain()
        {
            Win32.NetJoinStatus status = Win32.NetJoinStatus.NetSetupUnknownStatus;
            IntPtr pDomain = IntPtr.Zero;
            int result = Win32.NetGetJoinInformation(null, out pDomain, out status);
            if (pDomain != IntPtr.Zero)
            {
                Win32.NetApiBufferFree(pDomain);
            }
            if (result == Win32.ErrorSuccess)
            {
                return status == Win32.NetJoinStatus.NetSetupDomainName;
            }
            else
            {
                throw new Exception("Domain Info Get Failed");
            }
        }
    }


    internal class Win32
    {
        public const int ErrorSuccess = 0;

        [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int NetGetJoinInformation(string server, out IntPtr domain, out NetJoinStatus status);

        [DllImport("Netapi32.dll")]
        public static extern int NetApiBufferFree(IntPtr Buffer);

        public enum NetJoinStatus
        {
            NetSetupUnknownStatus = 0,
            NetSetupUnjoined,
            NetSetupWorkgroupName,
            NetSetupDomainName
        }
    }

}
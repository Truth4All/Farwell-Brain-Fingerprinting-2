USE BrainwaveDB

TRUNCATE TABLE [BF_Analyses]
GO
TRUNCATE TABLE [BF_Cases]
GO
TRUNCATE TABLE [BF_Facts]
GO
TRUNCATE TABLE [BF_Groups]
GO
TRUNCATE TABLE [BF_InlineStorage]
GO
TRUNCATE TABLE [BF_Licenses]
GO
TRUNCATE TABLE [BF_Machines]
GO
TRUNCATE TABLE [BF_Protocols]
GO
TRUNCATE TABLE [BF_Reports]
GO
TRUNCATE TABLE [BF_Sets]
GO
TRUNCATE TABLE [BF_Subjects]
GO
TRUNCATE TABLE [BF_Tags]
GO
TRUNCATE TABLE [BF_Tests]
GO
TRUNCATE TABLE [BF_TestSetups]
GO
TRUNCATE TABLE [BF_UserRegistry]
GO
TRUNCATE TABLE [BF_Users]
GO
TRUNCATE TABLE [BF_Xref_Connections]
GO
DELETE FROM [BF_Language_Assets] WHERE Usage = 'Runtime'
GO
DELETE FROM [BF_Language_Assets] WHERE Usage = 'Factory' AND LCID != 'en-US'
GO
UPDATE [dbo].[BF_Languages] SET [IsTranslated] = 0
GO
UPDATE [dbo].[BF_Languages] SET [IsTranslated] = 1 WHERE LCID = 'en-US'
GO
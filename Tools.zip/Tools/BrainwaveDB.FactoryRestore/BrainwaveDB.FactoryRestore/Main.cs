﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace BrainwaveDB.FactoryRestore
{
    public partial class Main : Form
    {
        public string connectionString;

        public Main()
        {
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", string.Format(@"{0}Brainwave.config", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles))));
            connectionString = (ConfigurationManager.ConnectionStrings["DefaultDBConnection"]).ToString();

            InitializeComponent();
        }

        private void btn_restore_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string sqlScript = BrainwaveDB.FactoryRestore.Properties.Resources.BrainwaveDB_Factory_Reset;
            string[] commands = sqlScript.Split(new string[] { "GO\r\n", "GO ", "GO\t" }, StringSplitOptions.RemoveEmptyEntries);
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                // Progress Bar Tracking
                int total = commands.Length;
                int count = 0;
                foreach (string individualScript in commands)
                {
                    command.CommandText = individualScript;
                    try
                    {
                        command.ExecuteNonQuery();
                        count++;
                    }
                    catch { }
                    ProgressStatus(count, total);
                }
            }
            conn.Close();
        }

        private void ProgressStatus(int count, int FullScale)
        {
            progressBar1.BeginInvoke(
                new Action(() =>
                {
                    progressBar1.Value = 100 * (count / FullScale);
                }
                )
            );
        }
    }
}

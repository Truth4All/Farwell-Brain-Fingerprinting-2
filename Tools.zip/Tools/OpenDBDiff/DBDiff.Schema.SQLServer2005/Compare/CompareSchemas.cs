namespace DBDiff.Schema.SQLServer.Generates.Compare
{
    internal class CompareSchemas:CompareBase<Model.Schema>
    {

    }
}

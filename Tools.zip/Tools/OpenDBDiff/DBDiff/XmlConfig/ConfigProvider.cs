namespace DBDiff.XmlConfig
{
    public class ConfigProvider
    {
        public string Library { get; set; }

        public string Key { get; set; }

        public string Description { get; set; }
    }
}

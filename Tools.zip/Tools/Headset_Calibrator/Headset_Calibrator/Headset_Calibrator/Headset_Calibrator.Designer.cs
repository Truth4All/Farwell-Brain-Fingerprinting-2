﻿namespace Headset_Calibrator
{
    partial class Headset_Calibrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.MAC_Address = new System.Windows.Forms.TextBox();
            this.device_list = new System.Windows.Forms.ComboBox();
            this.bt_search = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.HeadsetStatus = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_Gain = new System.Windows.Forms.ComboBox();
            this.cal_ch2 = new System.Windows.Forms.TextBox();
            this.cal_ch1 = new System.Windows.Forms.TextBox();
            this.check_Notch = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_Calibrate = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.storedOffsetCh2 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.storedOffsetCh1 = new System.Windows.Forms.TextBox();
            this.bt_Store = new System.Windows.Forms.Button();
            this.bt_Read = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.MAC_Address);
            this.groupBox1.Controls.Add(this.device_list);
            this.groupBox1.Controls.Add(this.bt_search);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(591, 84);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Headset Selection";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(261, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Device MAC Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Device Name";
            // 
            // MAC_Address
            // 
            this.MAC_Address.Location = new System.Drawing.Point(264, 45);
            this.MAC_Address.Name = "MAC_Address";
            this.MAC_Address.Size = new System.Drawing.Size(140, 20);
            this.MAC_Address.TabIndex = 2;
            this.MAC_Address.TextChanged += new System.EventHandler(this.MAC_Address_TextChanged);
            // 
            // device_list
            // 
            this.device_list.FormattingEnabled = true;
            this.device_list.Location = new System.Drawing.Point(16, 45);
            this.device_list.Name = "device_list";
            this.device_list.Size = new System.Drawing.Size(235, 21);
            this.device_list.TabIndex = 1;
            this.device_list.SelectedIndexChanged += new System.EventHandler(this.device_list_SelectedIndexChanged);
            // 
            // bt_search
            // 
            this.bt_search.Location = new System.Drawing.Point(446, 42);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(119, 23);
            this.bt_search.TabIndex = 0;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = true;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.HeadsetStatus);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cb_Gain);
            this.groupBox2.Controls.Add(this.cal_ch2);
            this.groupBox2.Controls.Add(this.cal_ch1);
            this.groupBox2.Controls.Add(this.check_Notch);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.bt_Calibrate);
            this.groupBox2.Location = new System.Drawing.Point(12, 102);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(591, 90);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Calibration";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(131, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Measured";
            // 
            // HeadsetStatus
            // 
            this.HeadsetStatus.AutoSize = true;
            this.HeadsetStatus.Location = new System.Drawing.Point(16, 87);
            this.HeadsetStatus.Name = "HeadsetStatus";
            this.HeadsetStatus.Size = new System.Drawing.Size(0, 13);
            this.HeadsetStatus.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(443, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Gain";
            // 
            // cb_Gain
            // 
            this.cb_Gain.FormattingEnabled = true;
            this.cb_Gain.Location = new System.Drawing.Point(491, 19);
            this.cb_Gain.Name = "cb_Gain";
            this.cb_Gain.Size = new System.Drawing.Size(74, 21);
            this.cb_Gain.TabIndex = 5;
            // 
            // cal_ch2
            // 
            this.cal_ch2.Location = new System.Drawing.Point(215, 45);
            this.cal_ch2.Name = "cal_ch2";
            this.cal_ch2.Size = new System.Drawing.Size(100, 20);
            this.cal_ch2.TabIndex = 4;
            // 
            // cal_ch1
            // 
            this.cal_ch1.Location = new System.Drawing.Point(16, 45);
            this.cal_ch1.Name = "cal_ch1";
            this.cal_ch1.Size = new System.Drawing.Size(100, 20);
            this.cal_ch1.TabIndex = 3;
            // 
            // check_Notch
            // 
            this.check_Notch.AutoSize = true;
            this.check_Notch.Checked = true;
            this.check_Notch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_Notch.Location = new System.Drawing.Point(347, 21);
            this.check_Notch.Name = "check_Notch";
            this.check_Notch.Size = new System.Drawing.Size(80, 17);
            this.check_Notch.TabIndex = 2;
            this.check_Notch.Text = "Notch Filter";
            this.check_Notch.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Attach calibration harness before proceeding to calibration";
            // 
            // bt_Calibrate
            // 
            this.bt_Calibrate.Location = new System.Drawing.Point(446, 58);
            this.bt_Calibrate.Name = "bt_Calibrate";
            this.bt_Calibrate.Size = new System.Drawing.Size(119, 23);
            this.bt_Calibrate.TabIndex = 0;
            this.bt_Calibrate.Text = "Calibrate";
            this.bt_Calibrate.UseVisualStyleBackColor = true;
            this.bt_Calibrate.Click += new System.EventHandler(this.bt_Calibrate_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.bt_Store);
            this.groupBox3.Controls.Add(this.bt_Read);
            this.groupBox3.Location = new System.Drawing.Point(12, 198);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(590, 84);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Headset Data";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(131, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Stored";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.storedOffsetCh2);
            this.groupBox5.Location = new System.Drawing.Point(209, 19);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(117, 52);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Channel 2 (Pz)";
            // 
            // storedOffsetCh2
            // 
            this.storedOffsetCh2.Location = new System.Drawing.Point(6, 20);
            this.storedOffsetCh2.Name = "storedOffsetCh2";
            this.storedOffsetCh2.Size = new System.Drawing.Size(100, 20);
            this.storedOffsetCh2.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.storedOffsetCh1);
            this.groupBox4.Location = new System.Drawing.Point(9, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(118, 52);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Channel 1 (EOG)";
            // 
            // storedOffsetCh1
            // 
            this.storedOffsetCh1.Location = new System.Drawing.Point(7, 20);
            this.storedOffsetCh1.Name = "storedOffsetCh1";
            this.storedOffsetCh1.Size = new System.Drawing.Size(100, 20);
            this.storedOffsetCh1.TabIndex = 0;
            // 
            // bt_Store
            // 
            this.bt_Store.Location = new System.Drawing.Point(446, 19);
            this.bt_Store.Name = "bt_Store";
            this.bt_Store.Size = new System.Drawing.Size(119, 23);
            this.bt_Store.TabIndex = 1;
            this.bt_Store.Text = "Store Offset";
            this.bt_Store.UseVisualStyleBackColor = true;
            this.bt_Store.Click += new System.EventHandler(this.bt_Store_Click);
            // 
            // bt_Read
            // 
            this.bt_Read.Location = new System.Drawing.Point(446, 48);
            this.bt_Read.Name = "bt_Read";
            this.bt_Read.Size = new System.Drawing.Size(119, 23);
            this.bt_Read.TabIndex = 0;
            this.bt_Read.Text = "Read Stored Offset";
            this.bt_Read.UseVisualStyleBackColor = true;
            this.bt_Read.Click += new System.EventHandler(this.bt_Read_Click);
            // 
            // Headset_Calibrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 295);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Headset_Calibrator";
            this.Text = "Headset Calibrator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button bt_Calibrate;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button bt_Store;
        private System.Windows.Forms.Button bt_Read;
        private System.Windows.Forms.ComboBox device_list;
        private System.Windows.Forms.TextBox cal_ch2;
        private System.Windows.Forms.TextBox cal_ch1;
        private System.Windows.Forms.CheckBox check_Notch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox storedOffsetCh2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox storedOffsetCh1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_Gain;
        private System.Windows.Forms.TextBox MAC_Address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label HeadsetStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}


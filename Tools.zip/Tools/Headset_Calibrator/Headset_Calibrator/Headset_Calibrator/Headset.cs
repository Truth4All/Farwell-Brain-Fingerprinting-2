﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using InTheHand.Net.Sockets;
using InTheHand.Net;
using InTheHand.Net.Bluetooth;

namespace Headset_Calibrator
{
    public class Headset
    {
        public class DataBlock
        {
            //Read
            private int[] ChannelSet = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 0, 0, 0, 0, 0 };
            private int[] ResolutionSet = { 24, 16 };
            private int[] GainSet = { 1, 2, 3, 4, 6, 8, 12 };
            private int[] intArrayLeadOnOff = { 1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128 };
            private float floatMathPow = (float)Math.Pow(2, 23) - 1;

            private int[] m_Header;
            private float[] m_Data;             //Calculated EEG values
            private int[,] m_RawData, _tempRaw; //Downloaded EEG values
            private int[] m_LeadOn;             //Lead on/off
            private int[] m_EventCode;          //Event Code
 
            int intMin = 0;
            int intMax = 15;
            int intGetCounter;
            int intGetDataLose = 0;
            int intLostByte = 0;

            public float this[int pos]
            {
                get { return m_Data[pos]; }
            }

            public int ReadHeaderAndCheckCounter(Stream sr, int m_Channel)
            {
                m_Header = new int[2];
                //read header
                for (int i = 0; i < 2; i++)
                {
                    m_Header[i] = sr.ReadByte();
                }

                //check counter
                intGetCounter = m_Header[0] - 240;
                
                // When the value is not accessible to 0-15, the second code Channel is incorrect, then re-evaluated
                if ((intMin > intGetCounter || intMax < intGetCounter) && (ChannelSet[m_Header[1] % 16] != m_Channel))
                {
                    while ((intMin > intGetCounter || intMax < intGetCounter) && (ChannelSet[m_Header[1] % 16] != m_Channel))
                    {
                        m_Header[0] = m_Header[1];
                        m_Header[1] = sr.ReadByte();
                        intGetCounter = m_Header[0] - 240;
                        intLostByte++;
                    }
                    intGetDataLose++;//DataLost: Number of occurences
                }
                return intGetDataLose;
            }

            public void readData(Stream sr, int m_Channel, int m_SampleRate, int m_Resolution, int m_PreAmpGain, float m_RefVoltage)
            {
                m_Data = new float[m_Channel];
                m_RawData = new int[m_Channel, m_Resolution / 8];            
                _tempRaw = new int[m_Channel, m_Resolution / 8];
                m_LeadOn = new int[(m_Channel > 16 ? (m_Channel / 8) : 2)];
                m_EventCode = new int[2] { 0, 0 };

                int temp;
                for (int j = 0; j < m_Channel; j++)
                {
                    //Resolution: 16 or 24
                    for (int x = 0; x < m_Resolution / 8; x++)
                    {
                        m_RawData[j, x] = sr.ReadByte();
                        _tempRaw[j, x] = m_RawData[j, x];
                    }

                    if (m_RawData[j, 0] >= 128)
                    {
                        _tempRaw[j, 0] = m_RawData[j, 0] - 256;//signed
                    }

                    //24-bit, 16-bit, or 12-bit
                    if (m_Resolution == 24)
                    {
                        temp = _tempRaw[j, 0] * 65536 + _tempRaw[j, 1] * 256 + _tempRaw[j, 2];
                    }
                    else
                    {
                        temp = _tempRaw[j, 0] * 65536 + _tempRaw[j, 1] * 256;
                    }


                    m_Data[j] = (m_RefVoltage * (float)temp) / floatMathPow;
                    m_Data[j] = m_Data[j] / m_PreAmpGain;
                }

                //EventCode
                for (int x = 0; x < 2; x++)
                {
                    m_EventCode[x] = sr.ReadByte();
                }
            }
        }

        private int m_Channel, m_SampleRate, m_Resolution, m_Gain, m_PreAmpGain;
        private float m_RefVoltage;
        public int datalost;

        //Bluetooth Connection
        private BluetoothClient btClient = null;
        private BluetoothEndPoint btEndPoint = null;

        public Headset(int inChannel, int inSampleRate, int inResolution, int inGain, int inPreAmpGain, float inRefVoltage)
        {
            m_Channel    = inChannel;
            m_SampleRate = inSampleRate;
            m_Resolution = inResolution;
            m_Gain       = inGain;
            m_PreAmpGain = inPreAmpGain;
            m_RefVoltage = inRefVoltage;
            m_Data       = new DataBlock();
        }

        public Stream connectBT(string address) // Connect to Bluetooth
        {
            BluetoothAddress address2 = BluetoothAddress.Parse(address);

            try
            {
                btClient = new BluetoothClient();
                BluetoothSecurity.PairRequest(address2, "0000"); // Set the password
                btEndPoint = new BluetoothEndPoint(address2, BluetoothService.SerialPort);
                btClient.Connect(btEndPoint);
                return btClient.GetStream();
            }
            catch
            {
                btClient = null;
                return null;
            }
        }

        public void Close(Stream sr)
        {
            sr.Close();
        }

        public void read(Stream sr)
        {
            m_Data.ReadHeaderAndCheckCounter(sr, m_Channel);
            m_Data.readData(sr, m_Channel, m_SampleRate, m_Resolution, m_PreAmpGain, m_RefVoltage);            
        }

        private DataBlock m_Data;
        public DataBlock Data
        {
            get { return m_Data; }
        }

        private byte SetCommand1()//Set 3-byte command
        {
            int R, X;

            if (m_Resolution == 24)
                R = 0;
            else
                R = 1;

            X = (int)Math.Log(m_SampleRate, 2);

            return (byte)((R << 4) + X);
        }

        private byte SetCommand2()//Set 4-byte command
        {
            int G, Y;

            if (m_Gain == 6) // Correction for the non-contiguous gain parameters
                G = 0;
            else if (m_Gain == 8)
                G = 5;
            else if (m_Gain == 12)
                G = 6;
            else
                G = m_Gain;

             Y = (int)Math.Log(m_Channel, 2);

            return (byte)((G << 4) + Y);
        }

        public void Start(Stream sr)
        {
            if (sr != null)
            {
                byte[] startCmd = { 0xFE, 0x07, SetCommand1(), SetCommand2(), 0xFF };
                sr.Write(startCmd, 0, 5);
            }
        }

        public void Stop(Stream sr)
        {
            if (sr != null)
            {
                byte[] endCmd = { 0xFE, 0x00, SetCommand1(), SetCommand2(), 0xFF };
                sr.Write(endCmd, 0, 5);
                sr.Flush();
                sr.Close();
            }
        }

        public void Flush(Stream sr)
        {
            sr.Flush();
        }

        public void Restart(Stream sr)
        {
            byte[] NotchCmd = { 0xFE, 0x07, SetCommand1(), SetCommand2(), 0xFF };
            sr.Write(NotchCmd, 0, 5);
            sr.Flush();
        }

        public void ChangeGain(Stream sr)//Change the Gain
        {
            byte[] gainCmd = { 0xFE, 0x02, SetCommand1(), SetCommand2(), 0xFF };
            sr.Write(gainCmd, 0, 5);
            sr.Flush();
        }

        public void ChangeNotch(Stream sr, bool NotchState)//Notch Filter ON/OFF
        {
            if (NotchState == true)//ON
            {
                byte[] NotchCmd = { 0xFE, 0x05, SetCommand1(), SetCommand2(), 0xFF };
                sr.Write(NotchCmd, 0, 5);
                sr.Flush();
            }
            else //OFF
            {
                byte[] NotchCmd = { 0xFE, 0x04, SetCommand1(), SetCommand2(), 0xFF };
                sr.Write(NotchCmd, 0, 5);
                sr.Flush();
            }
        }

        public void uploadEvent(Stream sr, int eventcode)
        {
            int x = (eventcode / 256);
            int y = (eventcode - (x * 256));
            byte _byte1 = Convert.ToByte(x);
            byte _byte2 = Convert.ToByte(y);
            byte[] uploadEvent = { 0xFE, 0x10, _byte1, _byte2, 0xFF };
            sr.Write(uploadEvent, 0, 5);
        }

        public int Gain
        {
            set { m_Gain = value; }
            get { return m_Gain; }
        }

        public void storeChannelOffset(Stream sr, int m_Channel, float offset)
        {
            if (sr != null)
            {
                int m_ChannelCode = 17 + m_Channel; // 0x11 + byteof(channel); 0 being the first channel
                byte _byte1 = Convert.ToByte(m_ChannelCode);
                byte[] _byteOffset = digitize((offset * m_PreAmpGain), m_RefVoltage);
                byte[] uploadEvent = { 0xFE, _byte1, _byteOffset[0], _byteOffset[1], _byteOffset[2], 0xFF };
                sr.Write(uploadEvent, 0, 6);
                sr.Flush();
            }
        }

        public float readChannelOffset(Stream sr, int m_Channel, int PreAmpGain)
        {
            float floatMathPow = (float)Math.Pow(2, 23) - 1;
            int[] message;
            message = new int[6];
            int temp;
            float offset;
            offset = 0;

            if (sr != null)
            {
                sr.Flush();

                // Command for an offset read
                int m_ChannelCode = 145 + m_Channel; // 0x91 + byteof(channel); 0 being the first channel
                byte _byte1 = Convert.ToByte(m_ChannelCode);
                byte[] uploadEvent = { 0xFE, _byte1, 0x00, 0x00, 0x00, 0xFF };
                sr.Write(uploadEvent, 0, 6);

                System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

                //read returned value
                for (int i = 0; i < 6; i++)
                {
                    message[i] = sr.ReadByte();
                }
                sr.Flush();

                if (message[2] >= 128) // Taking care of the sign
                {
                    message[2] = message[2] - 256;
                }
                temp = message[2] * 65536 + message[3] * 256 + message[4];
                float offset1 = (m_RefVoltage * (float)temp) / floatMathPow;
                offset = offset1 / PreAmpGain;  // offset at the front of the device
            }
            return offset;
        }

        public byte[] digitize(float input, float reference)
        {
            float floatMathPow = (float)Math.Pow(2, 23) - 1;
            byte[] convertedValue;
            byte[] output;

            output = new byte[3];

            double input_double = (double)(input / (reference / floatMathPow));

            double absolute_input = Math.Abs(input_double);

            int int_input = (int)absolute_input;

            convertedValue = BitConverter.GetBytes(int_input);

            if (input < 0)
            {
                output[0] = (byte)(~convertedValue[2] | 0x80); //MSB
                output[1] = (byte)~convertedValue[1];
                output[2] = (byte)~convertedValue[0]; // LSB
            }
            else
            {
                output[0] = (byte)convertedValue[2];
                output[1] = (byte)convertedValue[1];
                output[2] = (byte)convertedValue[0]; // LSB
            }
            return output;
        }
    }
}

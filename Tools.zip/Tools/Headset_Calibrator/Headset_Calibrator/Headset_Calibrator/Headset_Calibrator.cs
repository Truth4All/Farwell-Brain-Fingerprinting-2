﻿using System;
using System.IO;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Headset_Calibrator
{
    public partial class Headset_Calibrator : Form
    {
        BackgroundWorker bg;
        private int[] GainSet = { 1, 2, 3, 4, 6, 8, 12 };
        public static int Gain;
        public string SelectedMACAddress;

        private float[] currentData;
        private float[] averageData;
        

        int Channel;
        int SamplingRate;
        int Resolution;
        int PreAmpGain;          // Front-end EEG amplifier gain:1365
        float RefVoltage;  

        public static Headset ms;
        public static Stream sr;
        private int dataRcvpoint;

        public Headset_Calibrator()
        {
            InitializeComponent();

            Channel = 2;
            SamplingRate = 512;
            Resolution = 24;
            PreAmpGain = 1365;
            RefVoltage = 2.4f;

            bg = new BackgroundWorker();
            bg.DoWork += new DoWorkEventHandler(bg_DoWork);
            bg.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bg_RunWorkerCompleted);

            cb_Gain.Text = "1";

            //GainComboBox
            for (int i = 0; i < 7; i++)
            {
                cb_Gain.Items.Add(GainSet[i]);
            }

            bt_Calibrate.Enabled = false;
            bt_Read.Enabled = false;
            bt_Store.Enabled = false;
        }

        void bg_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            device_list.DataSource = (List<Device>)e.Result;
            bt_search.Enabled = true;
        }

        void bg_DoWork(object sender, DoWorkEventArgs e)
        {
            List<Device> devices = new List<Device>();
            InTheHand.Net.Sockets.BluetoothClient bc = new InTheHand.Net.Sockets.BluetoothClient();
            InTheHand.Net.Sockets.BluetoothDeviceInfo[] array = bc.DiscoverDevices();
            int count = array.Length;
            for (int i = 0; i < count; i++)
            {
                if (array[i].DeviceName.Contains("BF"))
                {
                    Device device = new Device(array[i]);
                    device.DeviceName = device.DeviceName + " ( " + device.DeviceMAC + " )";
                    devices.Add(device);
                }
            }
            e.Result = devices;
        }

        private void device_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (device_list.SelectedItem != null)
            {
                Device device = (Device)device_list.SelectedItem;
                MAC_Address.Text = device.DeviceMAC.ToString();

                bt_Calibrate.Enabled = true;
                bt_Read.Enabled = true;
            }
           
        }

        private void bt_search_Click(object sender, EventArgs e)
        {
            if (!bg.IsBusy)
            {
                bt_search.Enabled = false;
                bg.RunWorkerAsync();
            }
        }

        private void MAC_Address_TextChanged(object sender, EventArgs e)
        {
            SelectedMACAddress = MAC_Address.Text;
        }

        private void SetGain()
        {
            ms.Gain = Convert.ToInt32(cb_Gain.Text);
            ms.ChangeGain(sr);
        }

        private void ReceiveSignal_()
        {
            currentData = new float[Channel];
            averageData = new float[Channel];
            dataRcvpoint    = 0;
            int SampleCount = 4096;

            if (sr != null)
            {
                ms.Stop(sr);
            }

            ms = new Headset(Channel, SamplingRate, Resolution, Gain, PreAmpGain, RefVoltage);
            sr = ms.connectBT(SelectedMACAddress);
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)
           
            if (sr != null)
            {
                ms.ChangeNotch(sr, check_Notch.Checked);
                System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)
                SetGain();
                System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)
            }

            ms.Start(sr);
            while ((sr != null) && (dataRcvpoint <= SampleCount))
            {
                ms.read(sr);
                try
                {
                    for (int j = 0; j < Channel; j++)
                    {
                        currentData[j] = ms.Data[j]; // compensated for pre-Amp and digitizer
                        averageData[j] = averageData[j] + currentData[j];
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

                dataRcvpoint++;
            }

            for (int j = 0; j < Channel; j++)
            {
                averageData[j] = averageData[j] / SampleCount;
                
            }
        }

        private void bt_Calibrate_Click(object sender, EventArgs e)
        {
            NumberFormatInfo style = new CultureInfo("en-US", false).NumberFormat;
            style.NumberDecimalDigits = 9;

            bt_Calibrate.Enabled = false;

            ReceiveSignal_();

            bt_Calibrate.Enabled = true;

            cal_ch1.Text = averageData[0].ToString("N",style);
            cal_ch2.Text = averageData[1].ToString("N",style);

            bt_Store.Enabled = true;
        }

        private void bt_Read_Click(object sender, EventArgs e)
        {
            NumberFormatInfo style = new CultureInfo("en-US", false).NumberFormat;
            style.NumberDecimalDigits = 9;

            bt_Read.Enabled = false;

            if (sr != null)
            {
                ms.Stop(sr);
            }
            ms = new Headset(Channel, SamplingRate, Resolution, Gain, PreAmpGain, RefVoltage);
            sr = ms.connectBT(SelectedMACAddress);
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

            storedOffsetCh1.Text = ms.readChannelOffset(sr, 0, PreAmpGain).ToString("N", style);
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

            storedOffsetCh2.Text = ms.readChannelOffset(sr, 1, PreAmpGain).ToString("N", style);
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

            bt_Read.Enabled = true;
        }

        private void bt_Store_Click(object sender, EventArgs e)
        {
            bt_Read.Enabled = false;
            bt_Store.Enabled = false;

            if (sr != null)
            {
                ms.Stop(sr);
            }

            ms = new Headset(Channel, SamplingRate, Resolution, Gain, PreAmpGain, RefVoltage);
            sr = ms.connectBT(SelectedMACAddress);
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

            ms.storeChannelOffset(sr, 0, float.Parse(cal_ch1.Text));
            System.Threading.Thread.Sleep(100); //will sleep the current thread (in mS)

            ms.storeChannelOffset(sr, 1, float.Parse(cal_ch2.Text));

            bt_Read.Enabled = true;
            bt_Store.Enabled = true;
        }

    }
}

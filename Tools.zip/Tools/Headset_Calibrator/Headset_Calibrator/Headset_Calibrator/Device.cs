﻿using InTheHand.Net.Sockets;

namespace Headset_Calibrator
{
    public class Device
    {
        public string DeviceName { get; set; }
        public string DeviceMAC { get; set; }

        public Device(BluetoothDeviceInfo device_info)
        {
            this.DeviceName = device_info.DeviceName;
            this.DeviceMAC = device_info.DeviceAddress.ToString();
        }

        public override string ToString()
        {
            return this.DeviceName;
        }
    }
}



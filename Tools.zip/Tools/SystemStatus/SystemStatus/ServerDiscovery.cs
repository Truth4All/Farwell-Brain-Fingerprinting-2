﻿using BWS.WebServices;
using System;
using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.IO;
using System.Runtime.Serialization;


namespace SystemStatus
{
    public static class ServerDiscovery
    {
        static string CertificateFile = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\BrainwaveServerSecurity.pfx";
        static string CertificatePassword = "c3xQT6Z2";

        public static string IsBrainwaveServerOnline()
        {
            string BrainwaveServer;
            try
            {

                BrainwaveServer = Registry.GetRegistryValue("BrainwaveServer").ToString();
            }
            catch
            {
                return "No";
            }

            ChannelFactory<ISynchro> channelFactory = null;
            EndpointAddress ep = null;
            ISynchro serviceObject = null;

            // Open Channel
            X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
            string ServerPath = BrainwaveServer + @"/Synchro/";
            ep = new EndpointAddress(ServerPath);

            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            tcpb.MaxReceivedMessageSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferPoolSize = int.MaxValue; // should consider reducing that
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.CloseTimeout = TimeSpan.FromSeconds(20); // default: 10 seconds
            tcpb.OpenTimeout = TimeSpan.FromMinutes(1);  // default: 1 minute
            tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
            tcpb.SendTimeout = TimeSpan.FromMinutes(10); // default: 1 minute

            channelFactory = new ChannelFactory<ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);
            try
            {
                string IPAddress = serviceObject.GetServerIP();
                return "Yes";
            }
            catch (Exception e)
            {
                return "No";
            }
        }

        /// <summary>
        /// Start a background task for searching the Brainwave Server via WS-DISCOVERY
        /// </summary>
        /// <returns></returns>
        //public static void GetBrainwaveServer()
        //{
        //    if (Internet.GetInternetConnectionStatus())
        //    {
        //        // Is the server online ? true, nothing to do
        //        if (IsBrainwaveServerOnline())
        //        {
        //            return;
        //        }
        //        else
        //        {
        //            ServerSearchAlert alert;
        //            alert = new ServerSearchAlert();
        //            alert.Start();
        //            return;
        //        }
        //    }
        //}

        public static string FindBrainwaveServerAddress()
        {
            Uri _discoveredAddress;
            // Create the DiscoveryClient
            DiscoveryClient discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
            // Find Syncho endpoints
            FindCriteria FCriteria = new FindCriteria(typeof(ISynchro));
            //FCriteria.MaxResults = 1;
            //FCriteria.ScopeMatchBy.Equals("BWS.WebServices.Synchro");
            FindResponse findResponse = discoveryClient.Find(FCriteria);
            discoveryClient.Close();
            if (findResponse.Endpoints.Count > 0)
            {
                _discoveredAddress = findResponse.Endpoints[0].Address.Uri;
                string _brainwaveServer = _discoveredAddress.GetLeftPart(UriPartial.Authority).ToString();
                return _brainwaveServer;
            }
            else
            {
                return "Not Found";
            }
        }
    }
}

namespace BWS.WebServices
{
    [XmlSerializerFormat]
    [ServiceContract]
    public interface ISynchro
    {

        /// <summary>
        /// Return the Brainwave Server Name
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        string GetServerHostName();

        /// <summary>
        /// Return the Brainwabe Server IP address
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        string GetServerIP();

        /// <summary>
        /// User/machine license management
        /// </summary>
        /// <param name="machine">machine host name</param>
        /// <param name="machineIP">machine IPv4 address</param>
        /// <param name="userSID">Windows User security SID</param>
        /// <returns>Returns a LicenseMetaData object the sucess or failure of acquiring a license.</returns>
        [OperationContract]
        LicenseMetaData GetUserLicense(string machine, string machineIP, string userSID);

        /// <summary>
        /// Used to maintain the allocation of a user license when a client machine is using the Brainwave application
        /// </summary>
        /// <param name="machine"></param>
        /// <param name="machineIP"></param>
        /// <param name="userSID"></param>
        /// <returns>return true is successful at maintaining the license.</returns>
        [OperationContract]
        bool TickleUserLicense(string machine, string machineIP, string userSID);

        /// <summary>
        /// Immediate release of the machine license.
        /// </summary>
        /// <param name="machine">machine host name</param>
        /// <returns>return true if successful at release the user license</returns>
        [OperationContract]
        bool ReleaseUserLicense(string machine);

        /// <summary>
        /// Return a count of valid test license of the Brainwave Server
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="machine"></param>
        /// <returns></returns>
        [OperationContract]
        int GetTestLicense(string userName, string machine);

        /// <summary>
        /// Brainwave Capture debit license method
        /// </summary>
        /// <param name="UserSID"></param>
        /// <param name="machine"></param>
        [OperationContract]
        bool DebitTestLicense(string userName, string machine, int count);

        /// <summary>
        /// Return the XML file containing the catalog of all Case Folios
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        Stream GetCatalogFile(string UserSID, string machine);

        /// <summary>
        /// Return the XML file of a case Folio
        /// </summary>
        /// <param name="CaseGUID"></param>
        /// <param name="UserSID"></param>
        /// <param name="machine"></param>
        /// <returns>FolioData</returns>
        [OperationContract]
        FolioMetaData GetFolioMetaData(string CaseGUID, string UserSID, string machine);

        /// <summary>
        /// Return the XML file of a case Folio
        /// </summary>
        /// <param name="CaseGUID">GUID of the requested Case Folio</param>
        /// <returns>Stream</returns>
        [OperationContract]
        Stream GetCaseFolio(string CaseGUID, string UserSID, string machine);

        /// <summary>
        /// Saves an uploaded Case Folio back to the server.
        /// </summary>
        /// <param name="CaseInfo">a Case GUID and the Folio stream</param>
        [OperationContract]
        void SaveCaseFolio(CaseMetaData CaseInfo);

    }


    [MessageContract]
    public class CaseMetaData
    {
        [MessageHeader(MustUnderstand = true)]
        public int Serial { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string CaseGUID { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string JurisdictionID { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string CaseName { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string CaseSummary { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string UserSID { get; set; }
        [MessageHeader(MustUnderstand = true)]
        public string MachineName { get; set; }
        [MessageBodyMember(Order = 1)]
        public Stream CaseStream { get; set; }
    }

    public class LicenseMetaData
    {
        public string UserSID { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public string Capabilities { get; set; }
        public string SupervisorSID { get; set; }
        public LicenseCode Status { get; set; }
        public int TestLicenseCount { get; set; }
    }

    public enum LicenseCode
    {
        S200, // User License Issued
        S201, // User License Released
        S202, // License Activation Required

        S401, // Your are not a Brainwave User
        S402, // Not enough user licenses
        S403, // Application License expired
        S404, // User License Expired
        S405, // Test Licenses Expired
        S406, // Test Licenses Depleted
        S407, // Network User License was not acquired prior leaving the network
        S408, // The computer clock was tampered with // ValidDateTimeError
        S409, // You must be a Brainwave Manager in order to activate a license  //ActivationByManagerOnlyMsg

        S500, // Request failed
        S501, // Cannot reach the license server
        S510, // User License tampered with

        S600, // License Key Activation Success
        S601, // AppKeyActivateSuccessMsg
        S602, // UserKeyActivateSuccessMsg
        S603, // TestKeyActivateSuccessMsg
        S604, // AppKeySaveMsg
        S605, // UserKeySaveMsg
        S606, // TestKeySaveMsg

        S610, // Invalid License Key
        S611, // AppKeyActivateFirstMsg
        S612, // LicensActivationProblemMsg
        S613, // ApplicationActivationErrorMsg
        S614, // UserActivationErrorMsg
        S615, // TestActivationErrorMsg
        S616, // InvalidActivationKeyMsg
        S617, // InvalidHardwareMsg
        S618, // LicenseExpiryMsg

        S999, // UnknownErrorMsg
    }

    public class FolioMetaData
    {
        [MessageHeader(MustUnderstand = true)]
        public int Serial { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsLocked { get; set; }
        public string CaseName { get; set; }
        public string CaseSummary { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedTimestamp { get; set; }
        public string OwnedBy { get; set; }
        public DateTime CreatedTimestamp { get; set; }
        public string LockedBy { get; set; }
        public string GID { get; set; }
        public string GroupName { get; set; }
        public string Access { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceModel;
using System.Runtime.InteropServices;

namespace SystemStatus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (Registry.IsRegistryKeyExist("BrainwaveServer")) { tbx_ServerURL.Text = Registry.GetRegistryValue("BrainwaveServer").ToString(); }
            if (Registry.IsRegistryKeyExist("BrainwaveServerIP")) { tbx_ServerIP.Text = Registry.GetRegistryValue("BrainwaveServerIP").ToString(); }
            if (Registry.IsRegistryKeyExist("Domain")) { tbx_Domain.Text = Registry.GetRegistryValue("Domain").ToString(); }
            if (Registry.IsRegistryKeyExist("DomainAttached")) { tbx_Attached.Text = Registry.GetRegistryValue("DomainAttached").ToString(); }
            if (Registry.IsRegistryKeyExist("HeadSetMAC")) { tbx_Headset.Text = Registry.GetRegistryValue("HeadSetMAC").ToString(); }
            if (Registry.IsRegistryKeyExist("Internet")) { tbx_Internet.Text = Registry.GetRegistryValue("Internet").ToString(); }
            if (Registry.IsRegistryKeyExist("RunTimeSecurity")) { tbx_RunTimeSecurity.Text = Registry.GetRegistryValue("RunTimeSecurity").ToString(); }
            if (Registry.IsRegistryKeyExist("UserCapabilities")) { tbx_UserCapabilities.Text = Registry.GetRegistryValue("UserCapabilities").ToString(); }
            if (Registry.IsRegistryKeyExist("UserRole")) { tbx_UserRole.Text = Registry.GetRegistryValue("UserRole").ToString(); }

            tbx_Username.Text = Environment.UserName.ToString();
            tbx_Intranet.Text = GetIntranet();
            tbx_ServerReach.Text = PingAddress(tbx_ServerIP.Text);
            tbx_LocalIP.Text = GetLocalIP();
            tbx_MyDomain.Text = myDomain();
            tbx_DomainStatus.Text = IsAttachedToDomain();

            // This takes time
            tbx_IsServerOnline.Text = ServerDiscovery.IsBrainwaveServerOnline();
            tbx_Discovery.Text = ". . . Searching . . .";
            tbx_Discovery.Text = ServerDiscovery.FindBrainwaveServerAddress().ToString();

        }

        private string GetIntranet()
        {
            if (System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                return "Connected";
            }
            else
            {
                return "Not Connected";
            }
        }

        private string PingAddress(string address)
        {
            Ping ping = new Ping();
            PingReply pingresult;
            try
            {
                pingresult = ping.Send(address);
            }
            catch
            {
                return "Cannot Reach Server";
            }
            if (pingresult.Status.ToString() == "Success")
            {
                return "Ping-able";
            }
            else
            {
                return "Cannot Reach Server";
            }

        }

        static string GetLocalIP()
        {
            var localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            return localIpAddress.ToString();
        }

        public static string myDomain()
        {
            return Environment.UserDomainName.ToString();
        }

        public static string IsAttachedToDomain()
        {
            Win32.NetJoinStatus status = Win32.NetJoinStatus.NetSetupUnknownStatus;
            IntPtr pDomain = IntPtr.Zero;
            int result = Win32.NetGetJoinInformation(null, out pDomain, out status);
            if (pDomain != IntPtr.Zero)
            {
                Win32.NetApiBufferFree(pDomain);
            }
            if (result == Win32.ErrorSuccess)
            {
                //return status == Win32.NetJoinStatus.NetSetupDomainName;
                return "Connected a Domain";
            }
            else
            {
                //throw new Exception("Domain Info Get Failed");
                return "Domain Info Get Failed";
            }
        }
    }


    /// <summary>
    /// Win API wrapper
    /// </summary>
    
}

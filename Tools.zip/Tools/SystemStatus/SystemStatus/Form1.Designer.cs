﻿namespace SystemStatus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_Intranet = new System.Windows.Forms.TextBox();
            this.tbx_Internet = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbx_ServerURL = new System.Windows.Forms.TextBox();
            this.tbx_ServerIP = new System.Windows.Forms.TextBox();
            this.tbx_Domain = new System.Windows.Forms.TextBox();
            this.tbx_Attached = new System.Windows.Forms.TextBox();
            this.tbx_Headset = new System.Windows.Forms.TextBox();
            this.tbx_RunTimeSecurity = new System.Windows.Forms.TextBox();
            this.tbx_Username = new System.Windows.Forms.TextBox();
            this.tbx_UserCapabilities = new System.Windows.Forms.TextBox();
            this.tbx_UserRole = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbx_ServerReach = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbx_DomainStatus = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbx_MyDomain = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbx_Discovery = new System.Windows.Forms.TextBox();
            this.tbx_LocalIP = new System.Windows.Forms.TextBox();
            this.tbx_IsServerOnline = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(246, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Intranet Connection";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(37, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Internet Connection (Reg)";
            // 
            // tbx_Intranet
            // 
            this.tbx_Intranet.Location = new System.Drawing.Point(40, 26);
            this.tbx_Intranet.Name = "tbx_Intranet";
            this.tbx_Intranet.Size = new System.Drawing.Size(200, 20);
            this.tbx_Intranet.TabIndex = 2;
            // 
            // tbx_Internet
            // 
            this.tbx_Internet.Location = new System.Drawing.Point(172, 38);
            this.tbx_Internet.Name = "tbx_Internet";
            this.tbx_Internet.Size = new System.Drawing.Size(200, 20);
            this.tbx_Internet.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Brainwave Server URL (Reg)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Brainwave Server IP (Reg)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(111, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Domain";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 185);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Attached to Domain";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(107, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Headset";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(60, 237);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Run Time Security";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(246, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "User Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(81, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "User Capabilities";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(112, 301);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "User Role";
            // 
            // tbx_ServerURL
            // 
            this.tbx_ServerURL.Location = new System.Drawing.Point(172, 64);
            this.tbx_ServerURL.Name = "tbx_ServerURL";
            this.tbx_ServerURL.Size = new System.Drawing.Size(200, 20);
            this.tbx_ServerURL.TabIndex = 13;
            // 
            // tbx_ServerIP
            // 
            this.tbx_ServerIP.Location = new System.Drawing.Point(172, 90);
            this.tbx_ServerIP.Name = "tbx_ServerIP";
            this.tbx_ServerIP.Size = new System.Drawing.Size(200, 20);
            this.tbx_ServerIP.TabIndex = 14;
            // 
            // tbx_Domain
            // 
            this.tbx_Domain.Location = new System.Drawing.Point(160, 156);
            this.tbx_Domain.Name = "tbx_Domain";
            this.tbx_Domain.Size = new System.Drawing.Size(200, 20);
            this.tbx_Domain.TabIndex = 15;
            // 
            // tbx_Attached
            // 
            this.tbx_Attached.Location = new System.Drawing.Point(160, 182);
            this.tbx_Attached.Name = "tbx_Attached";
            this.tbx_Attached.Size = new System.Drawing.Size(200, 20);
            this.tbx_Attached.TabIndex = 16;
            // 
            // tbx_Headset
            // 
            this.tbx_Headset.Location = new System.Drawing.Point(160, 208);
            this.tbx_Headset.Name = "tbx_Headset";
            this.tbx_Headset.Size = new System.Drawing.Size(200, 20);
            this.tbx_Headset.TabIndex = 17;
            // 
            // tbx_RunTimeSecurity
            // 
            this.tbx_RunTimeSecurity.Location = new System.Drawing.Point(160, 234);
            this.tbx_RunTimeSecurity.Name = "tbx_RunTimeSecurity";
            this.tbx_RunTimeSecurity.Size = new System.Drawing.Size(200, 20);
            this.tbx_RunTimeSecurity.TabIndex = 18;
            // 
            // tbx_Username
            // 
            this.tbx_Username.Location = new System.Drawing.Point(40, 234);
            this.tbx_Username.Name = "tbx_Username";
            this.tbx_Username.Size = new System.Drawing.Size(200, 20);
            this.tbx_Username.TabIndex = 19;
            // 
            // tbx_UserCapabilities
            // 
            this.tbx_UserCapabilities.Location = new System.Drawing.Point(172, 272);
            this.tbx_UserCapabilities.Name = "tbx_UserCapabilities";
            this.tbx_UserCapabilities.Size = new System.Drawing.Size(200, 20);
            this.tbx_UserCapabilities.TabIndex = 20;
            // 
            // tbx_UserRole
            // 
            this.tbx_UserRole.Location = new System.Drawing.Point(172, 298);
            this.tbx_UserRole.Name = "tbx_UserRole";
            this.tbx_UserRole.Size = new System.Drawing.Size(200, 20);
            this.tbx_UserRole.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Check";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbx_ServerReach
            // 
            this.tbx_ServerReach.Location = new System.Drawing.Point(40, 78);
            this.tbx_ServerReach.Name = "tbx_ServerReach";
            this.tbx_ServerReach.Size = new System.Drawing.Size(200, 20);
            this.tbx_ServerReach.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(246, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Server Reach";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.tbx_RunTimeSecurity);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbx_Headset);
            this.groupBox1.Controls.Add(this.tbx_Domain);
            this.groupBox1.Controls.Add(this.tbx_Attached);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 360);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Brainwave Registry";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.tbx_IsServerOnline);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.tbx_DomainStatus);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.tbx_Username);
            this.groupBox2.Controls.Add(this.tbx_MyDomain);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.tbx_LocalIP);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.tbx_ServerReach);
            this.groupBox2.Controls.Add(this.tbx_Discovery);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.tbx_Intranet);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(418, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(400, 360);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Live Determination";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(246, 185);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 13);
            this.label16.TabIndex = 29;
            this.label16.Text = "Domain Status";
            // 
            // tbx_DomainStatus
            // 
            this.tbx_DomainStatus.Location = new System.Drawing.Point(40, 182);
            this.tbx_DomainStatus.Name = "tbx_DomainStatus";
            this.tbx_DomainStatus.Size = new System.Drawing.Size(200, 20);
            this.tbx_DomainStatus.TabIndex = 28;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(246, 159);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "My Domain";
            // 
            // tbx_MyDomain
            // 
            this.tbx_MyDomain.Location = new System.Drawing.Point(40, 156);
            this.tbx_MyDomain.Name = "tbx_MyDomain";
            this.tbx_MyDomain.Size = new System.Drawing.Size(200, 20);
            this.tbx_MyDomain.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(246, 133);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Local IP";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(246, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Server Discovery";
            // 
            // tbx_Discovery
            // 
            this.tbx_Discovery.Location = new System.Drawing.Point(40, 52);
            this.tbx_Discovery.Name = "tbx_Discovery";
            this.tbx_Discovery.Size = new System.Drawing.Size(200, 20);
            this.tbx_Discovery.TabIndex = 1;
            // 
            // tbx_LocalIP
            // 
            this.tbx_LocalIP.Location = new System.Drawing.Point(40, 130);
            this.tbx_LocalIP.Name = "tbx_LocalIP";
            this.tbx_LocalIP.Size = new System.Drawing.Size(200, 20);
            this.tbx_LocalIP.TabIndex = 0;
            // 
            // tbx_IsServerOnline
            // 
            this.tbx_IsServerOnline.Location = new System.Drawing.Point(40, 104);
            this.tbx_IsServerOnline.Name = "tbx_IsServerOnline";
            this.tbx_IsServerOnline.Size = new System.Drawing.Size(200, 20);
            this.tbx_IsServerOnline.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(246, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Is Server Online?";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 411);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbx_UserRole);
            this.Controls.Add(this.tbx_UserCapabilities);
            this.Controls.Add(this.tbx_ServerIP);
            this.Controls.Add(this.tbx_ServerURL);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbx_Internet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "System Status";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_Intranet;
        private System.Windows.Forms.TextBox tbx_Internet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbx_ServerURL;
        private System.Windows.Forms.TextBox tbx_Domain;
        private System.Windows.Forms.TextBox tbx_Attached;
        private System.Windows.Forms.TextBox tbx_Headset;
        private System.Windows.Forms.TextBox tbx_RunTimeSecurity;
        private System.Windows.Forms.TextBox tbx_Username;
        private System.Windows.Forms.TextBox tbx_UserCapabilities;
        private System.Windows.Forms.TextBox tbx_UserRole;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbx_ServerReach;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbx_LocalIP;
        private System.Windows.Forms.TextBox tbx_Discovery;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbx_MyDomain;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbx_DomainStatus;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbx_IsServerOnline;
        private System.Windows.Forms.TextBox tbx_ServerIP;
    }
}


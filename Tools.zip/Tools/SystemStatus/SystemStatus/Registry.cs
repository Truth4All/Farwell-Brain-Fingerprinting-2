﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemStatus
{
    public static class Registry
    {
        public static bool IsRegistryKeyInitialized(string value)
        {
            var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            if (key == null)
            {
                return false;
            }
            else
            {
                if (Microsoft.Win32.Registry.GetValue(key.ToString(), value, null) == null)
                {
                    return false;
                }
            }
            return true;
        }

        public static bool IsRegistryKeyExist(string value)
        {
            if (Microsoft.Win32.Registry.GetValue(@"HKEY_CURRENT_USER\SOFTWARE\Brainwave", value, null) == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsRegistryValueInitialized(string value)
        {
            var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            if (Microsoft.Win32.Registry.GetValue(key.ToString(), value, null) == null)
            {
                return false;
            }
            return true;
        }

        public static void SetRegistryValue(string key, object value)
        {
            Microsoft.Win32.RegistryKey wkey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Brainwave");
            if (value != null)
            {
                wkey.SetValue(key, value);
            }
            wkey.Close();
        }

        public static void InitializeRegistryValue(string key, object value)
        {
            if (GetRegistryValue(key) == null)
            {
                Microsoft.Win32.RegistryKey wkey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Brainwave");
                if (value != null)
                {
                    wkey.SetValue(key, value);
                }
                wkey.Close();
            }
        }

        public static object GetRegistryValue(string key)
        {
            Microsoft.Win32.RegistryKey rkey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            return rkey.GetValue(key, null);
        }

        private static string GetStringRegistryValue(string key)
        {
            Microsoft.Win32.RegistryKey rkey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            return rkey.GetValue(key, null).ToString();
        }

        private static bool GetBooleanRegistryValue(string key)
        {
            Microsoft.Win32.RegistryKey rkey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            if (rkey.GetValue(key, null).ToString() == "True")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}

﻿namespace Database_Restore
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SelectDir = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.restoreDB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(15, 64);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(317, 21);
            this.comboBox1.TabIndex = 0;
            // 
            // SelectDir
            // 
            this.SelectDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectDir.Location = new System.Drawing.Point(338, 63);
            this.SelectDir.Name = "SelectDir";
            this.SelectDir.Size = new System.Drawing.Size(31, 23);
            this.SelectDir.TabIndex = 1;
            this.SelectDir.Text = "...";
            this.SelectDir.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SelectDir.UseVisualStyleBackColor = true;
            this.SelectDir.Click += new System.EventHandler(this.SelectDir_Click);
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.ShowNewFolderButton = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(13, 101);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(453, 23);
            this.progressBar1.TabIndex = 2;
            // 
            // restoreDB
            // 
            this.restoreDB.Location = new System.Drawing.Point(390, 62);
            this.restoreDB.Name = "restoreDB";
            this.restoreDB.Size = new System.Drawing.Size(75, 23);
            this.restoreDB.TabIndex = 3;
            this.restoreDB.Text = "Restore";
            this.restoreDB.UseVisualStyleBackColor = true;
            this.restoreDB.Click += new System.EventHandler(this.restoreDB_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(453, 35);
            this.label1.TabIndex = 4;
            this.label1.Text = "The original location of the Brainwave Database Backups is: C:\\ProgramData\\Brainw" +
    "ave\\backups\\";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 139);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.restoreDB);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.SelectDir);
            this.Controls.Add(this.comboBox1);
            this.Name = "Main";
            this.Text = "Brainwave Database Restore";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button SelectDir;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button restoreDB;
        private System.Windows.Forms.Label label1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Database_Restore
{
    
    public partial class Main : Form
    {
        string sqlConnectionString = "Data Source=(localdb)\\MSSQLLOCALDB;Initial Catalog=master;Integrated Security=True";
        string startDirectory = @"C:\ProgramData\Brainwave\backups";

        public Main()
        {
            InitializeComponent();
            fillDropdown(startDirectory);
        }

        private void fillDropdown(string directory)
        {
            DirectoryInfo dir = new DirectoryInfo(directory);
            foreach(FileInfo file in dir.GetFiles())
            {
                comboBox1.Items.Add(file.Name);
            }
            var LatestBackup = (from f in dir.GetFiles() orderby f.LastWriteTime descending select f).First();
            comboBox1.Text = LatestBackup.Name;
        }

        private void SelectDir_Click(object sender, EventArgs e)
        {
            DialogResult dir = folderBrowserDialog1.ShowDialog();
            if (dir == DialogResult.OK)
            {
                startDirectory = folderBrowserDialog1.SelectedPath;
                fillDropdown(startDirectory);
            }
        }

        private void restoreDB_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(sqlConnectionString);
            string filePath = startDirectory + "\\" + comboBox1.Text;
            RestoreDatabaseThread(conn, "BrainwaveDB", filePath);
        }

        private void RestoreDatabaseThread(SqlConnection con, string databaseName, string backupFilename)
        {
            int complete;
            Thread backgroundBackup = new Thread(
                new ThreadStart(() =>
                {
                    con.FireInfoMessageEventOnUserErrors = true;
                    con.InfoMessage += OnInfoMessage;
                    con.Open();
                    using (var cmd = new SqlCommand(string.Format("RESTORE DATABASE {0} FROM DISK = '{1}' WITH REPLACE, STATS = 1", databaseName, backupFilename), con))
                    {
                        complete = cmd.ExecuteNonQuery();
                    }
                    con.Close();
                    con.InfoMessage -= OnInfoMessage;
                    con.FireInfoMessageEventOnUserErrors = false;
                }
                ));
            backgroundBackup.Start();
        }

        private void OnInfoMessage(object sender, SqlInfoMessageEventArgs e)
        {
            foreach (SqlError info in e.Errors)
            {
                if (info.Class < 10)
                {
                    int Progress = Int32.Parse(Regex.Match(e.Message, @"\d+").Value);
                    progressBar1.BeginInvoke(
                        new Action(() =>
                        {
                            if (Progress < 100)
                            {
                                progressBar1.Value = Progress;
                            }
                            else if (Progress == 100)
                            {
                                progressBar1.Value = 100;
                                this.Close();
                            }
                        }
                        ));
                }
            }
            Thread.Sleep(50);
        }

        private string QuoteIdentifier(string name)
        {
            return "[" + name.Replace("]", "]]") + "]";
        }

        private string QuoteString(string text)
        {
            return "'" + text.Replace("'", "''") + "'";
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace InlineStorage_Reader
{
    public partial class Main : Form
    {
        string filter = "ALL";


        public Main()
        {
            InitializeComponent();
            FillComboBox(filter);
            tbx_DestinationFolder.Text = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        }

        private void btn_SelectDestinationFolder_Click(object sender, EventArgs e)
        {
            DialogResult result = this.folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_DestinationFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btn_SelectFile_Click(object sender, EventArgs e)
        {
            DialogResult result = this.openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_SelectedFile.Text = openFileDialog1.FileName;
                tbx_GUID.Text = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
            }
        }

        private void cb_SelectGUID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            FillComboBox(filter);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            FillComboBox(filter);
        }

        private void FillComboBox(string filter)
        {
            cb_SelectGUID.DataSource = File.EnumerateFiles(filter);
        }

        private void btn_Extract_Click(object sender, EventArgs e)
        {
            byte[] content;
               
            InlineStorageFileAttributes FA = new InlineStorageFileAttributes();
            FA = File.GetAttributes(cb_SelectGUID.SelectedItem.ToString());

            if (String.IsNullOrEmpty(tbx_DestinationFolder.Text))
            {
                MessageBox.Show("Select a destination folder first");
            }

            string FilenamePath = tbx_DestinationFolder.Text+ "\\"+ FA.FileName;
            content = File.ReadAllBytes(cb_SelectGUID.SelectedItem.ToString());
            System.IO.File.WriteAllBytes(FilenamePath, content);
        }

        private void btn_NewGUID_Click(object sender, EventArgs e)
        {
            tbx_GUID.Text = Guid.NewGuid().ToString();
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            GWRelatedFile fileSpecs = new GWRelatedFile();
            MIMEResolver mr         = new MIMEResolver();

            string extension = Path.GetExtension(openFileDialog1.FileName);

            fileSpecs.FileId = tbx_GUID.Text;
            fileSpecs.FileStream = System.IO.File.ReadAllBytes(tbx_SelectedFile.Text);
            fileSpecs.FileMime = mr.GetMIMEType(extension.Substring(1));
            fileSpecs.FileName = tbx_GUID.Text + extension;
            File.WriteAllBytes(fileSpecs);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            filter = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            FillComboBox(filter);
        }
    }
}

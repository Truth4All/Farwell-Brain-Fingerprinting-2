﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace InlineStorage_Reader
{
    public class InlineStorageDL
    {
        public static Configuration CustomConfig;

        public InlineStorageDL()
        {

            string configFilePath = string.Format(@"{0}Brainwave.config", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)));

            //Mapping the appropriate path:
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = configFilePath;
            CustomConfig = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
        }

        public string ConnectionString
        {
            get
            {
                return CustomConfig.ConnectionStrings.ConnectionStrings["DefaultDBConnection"].ToString();
            }
        }

        public string AddInlineStorage(InlineStorageEntity Obj)
        {
            try
            {
                string GUIDNew = "";

                var sqlParams = new SqlParameter[4];

                sqlParams[0] = new SqlParameter("@FileType", SqlDbType.VarChar, 50) { Value = Obj.MediaType.TrimThis() };
                sqlParams[1] = new SqlParameter("@FileName", SqlDbType.VarChar, 50) { Value = Obj.MediaName.TrimThis() };
                sqlParams[2] = new SqlParameter("@FileData", SqlDbType.VarBinary, Obj.Media.Length) { Value = Obj.Media };
                sqlParams[3] = new SqlParameter("@GUID", SqlDbType.NVarChar, 255) { Value = Obj.ID };

                if (Obj.ID == null)
                {
                    GUIDNew = SqlHelper.ExecuteScalar(ConnectionString, "AddInlineImage", sqlParams).ToString();
                }
                else
                {
                    SqlHelper.ExecuteNonQuery(ConnectionString, "AddInlineImage", sqlParams);
                }
                return GUIDNew;
            }
            catch (Exception ex)
            {
                throw;
            }
            return "";
        }

        /// <summary>
        /// Method which adds Media files when you import
        /// </summary>
        /// <param name="Obj"></param>
        public void AddImportInlineStorage(InlineStorageEntity Obj)
        {
            try
            {
                var sqlParams = new SqlParameter[4];

                sqlParams[0] = new SqlParameter("@FileType", SqlDbType.VarChar, 50) { Value = Obj.MediaType.TrimThis() };
                sqlParams[1] = new SqlParameter("@FileName", SqlDbType.VarChar, 50) { Value = Obj.MediaName.TrimThis() };
                sqlParams[2] = new SqlParameter("@FileData", SqlDbType.VarBinary, Obj.Media.Length) { Value = Obj.Media };
                sqlParams[3] = new SqlParameter("@GUID", SqlDbType.VarBinary, Obj.Media.Length) { Value = Obj.ID };

                SqlHelper.ExecuteNonQuery(ConnectionString, "AddInlineImage", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void UpdateInlineStorage(InlineStorageEntity Obj)
        {
            try
            {
                var sqlParams = new SqlParameter[4];

                sqlParams[0] = new SqlParameter("@GUID", SqlDbType.NVarChar, 255) { Value = Obj.ID };
                sqlParams[1] = new SqlParameter("@FileType", SqlDbType.NVarChar, 50) { Value = Obj.MediaType.TrimThis() };
                sqlParams[2] = new SqlParameter("@FileName", SqlDbType.NVarChar, 50) { Value = Obj.MediaName.TrimThis() };
                sqlParams[3] = new SqlParameter("@FileData", SqlDbType.VarBinary, Obj.Media.Length) { Value = Obj.Media };

                SqlHelper.ExecuteScalar(ConnectionString, "UpdateInlineImage", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool DeleteInlineStorage(InlineStorageEntity Obj)
        {
            try
            {
                var sqlParams = new SqlParameter[2];

                sqlParams[0] = new SqlParameter("@tablename", SqlDbType.VarChar, 100) { Value = "BF_InlineStorage" };
                sqlParams[1] = new SqlParameter("@guid", SqlDbType.UniqueIdentifier) { Value = new System.Guid(Obj.ID) };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure,
                                                   "DeleteRecordFromTable", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }
            return true;
        }

        /// <summary>
        /// List the content of BF_InlineStorage table
        /// </summary>
        /// <returns>A list of record (GUID)</returns>
        public IEnumerable<string> EnumerateInlineStorage(string filter)
        {
            if (filter == "ALL") filter = "%";

            var Values = new List<string>();
            
            string sql = "SELECT [GUID] FROM [BF_InlineStorage] WHERE [MediaType] LIKE '" + filter + "' ORDER BY  [CreatedTimestamp] DESC";

            SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.Text, sql);

            while (reader.Read())
            {
                Values.Add(reader["GUID"].ToString());
            }
            reader.Close();
            return Values.AsEnumerable<string>();
        }

        /// <summary>
        /// Method for getting the Related file info
        /// </summary>
        /// <param name="guid"></param>
        /// <returns></returns>
        public GWRelatedFile GetRelatedFile(string guid)
        {
            GWRelatedFile file = null;
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@tablename", SqlDbType.VarChar, 100) { Value = "BF_InlineStorage" };
                sqlParams[1] = new SqlParameter("@guid", SqlDbType.UniqueIdentifier) { Value = new System.Guid(guid) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,"GetRecordFromTable", sqlParams);
                while (reader.Read())
                {
                    file            = new GWRelatedFile();
                    file.FileId     = reader["GUID"].ToString();
                    file.FileMime   = reader["MediaType"].ToString().TrimThis();
                    file.FileName   = reader["Description"].ToString().TrimThis();
                    byte[] img      = (byte[])reader["Media"];
                    file.FileStream = img;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            return file;
        }

    }

    public static class BrainwaveExtensions
    {
        public static string TrimThis(this String str)
        {
            if (str != null) return str.Trim();
            return null;
        }
    }
}

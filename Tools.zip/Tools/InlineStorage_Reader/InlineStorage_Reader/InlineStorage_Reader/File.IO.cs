﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace InlineStorage_Reader
{
    class File
    {
        /// <summary>
        /// Appends lines to an InlineStorage file(GUID), and then closes the file. If the specified file does not exist, this method creates a file,
        ///  writes the specified lines to the file, and then closes the file.
        /// </summary>
        /// <param name="GUID">Type: System.String, The file to append the lines to.The file is created if it doesn't already exist.</param>
        /// <param name="contents">Type: System.Collections.Generic.IEnumerable&lt;String&gt;, The lines to append to the file.</param>
        public static void AppendAllLines(string GUID, IEnumerable<string> contents)
        {

        }

        /// <summary>
        /// Opens a file(GUID), appends the specified string to the file, and then closes the file. If the file does not exist, this method creates a file, writes the specified string to the file, then closes the file.
        /// </summary>
        /// <param name="GUID">Type: System.String, The file to append the specified string to.</param>
        /// <param name="content">Type: System.String, The string to append to the file.</param>
        public static void AppendAllText(string GUID, string content)
        {

        }

        /// <summary>
        /// Copies an existing file(GUID) to a new file. Overwriting a file of the same name is not allowed.
        /// </summary>
        /// <param name="SourceGUID">The file(GUID) to copy.</param>
        /// <param name="DestGUID">The name of the destination file(GUID). This cannot be a directory or an existing file. </param>
        public void Copy(string SourceGUID, string DestGUID)
        {

        }

        /// <summary>
        /// Creates or overwrites a file(GUID) in the specified path. 
        /// </summary>
        /// <param name="GUID">The GUID of the file to create.</param>
        public void Create(string GUID)
        {

        }

        /// <summary>
        /// Determines whether the specified file(GUID) exists.
        /// </summary>
        /// <param name="GUID">The GUID of the file to check.</param>
        /// <returns>true if the caller has the required permissions and the GUID contains the record of an existing file; otherwise, false. This method also returns false if no record exist with that GUID</returns>
        public bool Exists(string GUID)
        {
            return false;
        }

        /// <summary>
        /// Gets the FileAttributes of the file(GUID) on the path.
        /// </summary>
        /// <param name="GUID">The path to the file. </param>
        /// <returns>The FileAttributes of the file on the path.</returns>
        public static InlineStorageFileAttributes GetAttributes(string GUID)
        {
            InlineStorageDL InlineStorage = new InlineStorageDL();
            GWRelatedFile InlineStorageFile = new GWRelatedFile();
            InlineStorageFileAttributes FileInfo = new InlineStorageFileAttributes();
            MIMEResolver mine = new MIMEResolver();

            InlineStorageFile = InlineStorage.GetRelatedFile(GUID);

            FileInfo.FileId = GUID.ToString();
            FileInfo.FileType = mine.GetFileType(InlineStorageFile.FileMime.ToString());
            FileInfo.FileName = GUID + "." + FileInfo.FileType;

            return FileInfo;
        }

        /// <summary>
        /// Returns the creation date and time of the specified file (GUID).
        /// </summary>
        /// <param name="GUID">The file(GUID) for which to obtain creation date and time information.</param>
        /// <returns>A DateTime structure set to the creation date and time for the specified file(GUID) record. This value is expressed in local time as recorded in the record.</returns>
        public static DateTime GetCreationTime(string GUID)
        {
            return DateTime.Now;
        }

        /// <summary>
        /// Returns the date and time the specified file(GUID) was last written to.
        /// </summary>
        /// <param name="GUID">The file(GUID) for which to obtain write date and time information. </param>
        /// <returns>A DateTime structure set to the date and time that the specified file(GUID) record was last modified. This value is expressed in local time as recorded in the record.</returns>
        public static DateTime GetLastModifiedTime(string GUID)
        {
            return DateTime.Now;
        }

        /// <summary>
        /// Returns the SID of the user that created the specified file (GUID).
        /// </summary>
        /// <param name="GUID">The file(GUID) for which to obtain the creator SID.</param>
        /// <returns>A string SID value representing the creator user</returns>
        public static string GetCreatorSID(string GUID)
        {
            return "";
        }

        /// <summary>
        /// Returns the SID of the user that modified the specified file (GUID).
        /// </summary>
        /// <param name="GUID">The file(GUID) for which to obtain the modifier SID.</param>
        /// <returns>A string SID value representing the modifier user</returns>
        public static string GetModifierSID(string GUID)
        {
            return "";
        }

        /// <summary>
        /// Moves a specified file(GUID) to a new record, providing the option to specify a new GUID.
        /// </summary>
        /// <param name="SourceGUID">The name of the file(GUID) to move.</param>
        /// <param name="DestGUID">The new GUID for the file.</param>
        public static void Move(string SourceGUID, string DestGUID)
        {

        }

        /// <summary>
        /// Opens a GUID file, reads the contents of the record into a byte array.
        /// </summary>
        /// <param name="GUID">The GUID to open for reading.</param>
        /// <returns>A byte array containing the contents of the record.</returns>
        public static byte[] ReadAllBytes(string GUID)
        {

            InlineStorageDL InlineStorage = null;
            GWRelatedFile DataFile = null;
            try
            {
                InlineStorage = new InlineStorageDL();
                DataFile = InlineStorage.GetRelatedFile(GUID);

                if (DataFile == null)
                {
                    throw new Exception("Unable to Load the file");
                }
                return DataFile.FileStream;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Opens a record containing text, reads all lines of the record. 
        /// </summary>
        /// <param name="GUID">The file(GUID) to open for reading. </param>
        /// <returns>A string array containing all text of the record.</returns>
        public static string[] ReadAllLines(string GUID)
        {
            InlineStorageDL InlineStorage = null;
            GWRelatedFile DataFile = null;
            try
            {
                InlineStorage = new InlineStorageDL();
                DataFile = InlineStorage.GetRelatedFile(GUID);

                if (DataFile == null)
                {
                    throw new Exception("Unable to Load the file");
                }
                byte[] byteData = DataFile.FileStream;

                var table = (Encoding.Default.GetString(
                                 byteData,
                                 0,
                                 byteData.Length - 1)).Split(new string[] { "\r\n", "\r", "\n" },
                                                             StringSplitOptions.None);
                return table;
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        /// <summary>
        /// Opens a text file(GUID), reads all lines of the record.
        /// </summary>
        /// <param name="GUID">The file(GUID) to open for reading.</param>
        /// <returns>A string containing all lines of the record.</returns>
        public static string ReadAllText(string GUID)
        {
            InlineStorageDL InlineStorage = null;
            GWRelatedFile DataFile = null;
            try
            {
                InlineStorage = new InlineStorageDL();
                DataFile = InlineStorage.GetRelatedFile(GUID);

                if (DataFile == null)
                {
                    throw new Exception("Unable to Load the file");
                }
                byte[] byteData = DataFile.FileStream;

                var stringData = System.Text.Encoding.UTF8.GetString(byteData);
                return stringData;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Reads the lines of a file(GUID). 
        /// </summary>
        /// <param name="GUID">The file(GUID) to read.</param>
        /// <returns>Type: System.Collections.Generic.IEnumerable&lt;String&gt; All the lines of the file, or the lines that are the result of a query.</returns>
        public static IEnumerable<string> ReadLines(string GUID)
        {
            InlineStorageDL InlineStorage = null;
            GWRelatedFile DataFile = null;
            try
            {
                InlineStorage = new InlineStorageDL();
                DataFile = InlineStorage.GetRelatedFile(GUID);

                if (DataFile == null)
                {
                    throw new Exception("Unable to Load the file");
                }
                byte[] byteData = DataFile.FileStream;

                var table = (Encoding.Default.GetString(
                                 byteData,
                                 0,
                                 byteData.Length - 1)).Split(new string[] { "\r\n", "\r", "\n" },
                                                             StringSplitOptions.None).AsEnumerable();
                return table;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Replaces the contents of a specified file(GUID) with the contents of another file(GUID), deleting the original file(GUID), and creating a backup of the replaced file(GUID).
        /// </summary>
        /// <param name="SourceGUID">The GUID of a record that replaces the record specified by DestGUID.</param>
        /// <param name="DestGUID">The GUID of the record being replaced.</param>
        /// <param name="BackupGUID">The GUID of the backup record.</param>
        public static void Replace(string SourceGUID, string DestGUID, string BackupGUID)
        {

        }

        public static void SetAccessControl()
        {

        }

        public static void SetAttributes()
        {

        }

        /// <summary>
        /// Creates a new file(GUID), writes the specified byte array to the record. If the record already exists, it is overwritten.
        /// </summary>
        /// <param name="GUID">The file(GUID) to write to. </param>
        /// <param name="content">The bytes to write to the record. </param>
        public static void WriteAllBytes(GWRelatedFile FileObj)
        {
            InlineStorageDL InlineStorage = new InlineStorageDL();
            FileObj.FileId = InlineStorage.AddInlineStorage(new InlineStorageEntity() { ID = FileObj.FileId, MediaName = FileObj.FileName, MediaType = FileObj.FileMime, Media = FileObj.FileStream });

        }

        /// <summary>
        /// Creates a new file(GUID), writes a collection of strings to the record.
        /// </summary>
        /// <param name="GWRelatedFile">The Object Instance with Property FileAllLines filled.</param>
        public static void WriteAllLines(GWRelatedFile FileObj)
        {
            IEnumerable<string> AllLines = FileObj.FileAllLines;

            using (var stream = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, AllLines);
                var byteArray = new byte[stream.Length];
                stream.Seek(0, SeekOrigin.Begin);
                stream.Read(byteArray, 0, (int)stream.Length);
                InlineStorageDL InlineStorage = new InlineStorageDL();
                FileObj.FileId = InlineStorage.AddInlineStorage(new InlineStorageEntity() { ID = FileObj.FileId, MediaName = FileObj.FileName, MediaType = FileObj.FileMime, Media = byteArray });
            }
        }

        /// <summary>
        /// Creates a new file(GUID), writes the specified string to the record.
        /// </summary>
        /// <param name="GWRelatedFile">The Object Instance with Property FileText filled.</param>
        public static void WriteAllText(GWRelatedFile FileObj)
        {
            byte[] fileStream = System.Text.Encoding.UTF8.GetBytes(FileObj.FileText);
            InlineStorageDL InlineStorage = new InlineStorageDL();
            FileObj.FileId = InlineStorage.AddInlineStorage(new InlineStorageEntity() { ID = FileObj.FileId, MediaName = FileObj.FileName, MediaType = FileObj.FileMime, Media = fileStream });

        }

        /// <summary>
        /// Creates a new file and return the GUID that was used, writes the specified string to the record.
        /// </summary>
        /// <param name="GWRelatedFile">The Object Instance with Property FileText filled.</param>
        /// <returns>string GUID</returns>
        public static string CreateAllText(GWRelatedFile FileObj)
        {
            byte[] fileStream = System.Text.Encoding.UTF8.GetBytes(FileObj.FileText);
            InlineStorageDL InlineStorage = new InlineStorageDL();
            FileObj.FileId = InlineStorage.AddInlineStorage(new InlineStorageEntity() { MediaName = FileObj.FileName, MediaType = FileObj.FileMime, Media = fileStream });
            return FileObj.FileId;
        }

        /// <summary>
        /// Mimic the Microsoft directory enumeration method to list out the content of a directory
        /// </summary>
        /// <returns>A list of GUID from InlineStorage</returns>
        public static IEnumerable<string> EnumerateFiles(string filter)
        {
            InlineStorageDL InlineStorage = new InlineStorageDL();
            return InlineStorage.EnumerateInlineStorage(filter);
        }
    }

    public class InlineStorageFileAttributes
    {
        public string FileId { get; set; }
        public string FileName { get; set; }
        public string FileType { get; set; }
    }

    public class MIMEResolver
    {
        // This dictionary is only for authorized Mime types for InlineStorage
        private readonly Dictionary<string, string> MIMETypesDictionary = new Dictionary<string, string>
        {
                            {"au",      "audio/basic"},
                            {"avi",     "video/x-msvideo"},
                            {"bin",     "application/octet-stream"},
                            {"bmp",     "image/bmp"},
                            {"css",     "text/css"},
                            {"dll",     "application/octet-stream"},
                            {"doc",     "application/msword"},
                            {"docx",    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
                            {"dotx",    "application/vnd.openxmlformats-officedocument.wordprocessingml.template"},
                            {"docm",    "application/vnd.ms-word.document.macroEnabled.12"},
                            {"dotm",    "application/vnd.ms-word.template.macroEnabled.12"},
                            {"dtd",     "application/xml-dtd"},
                            {"eps",     "application/postscript"},
                            {"exe",     "application/octet-stream"},
                            {"gif",     "image/gif"},
                            {"htm",     "text/html"},
                            {"html",    "text/html"},
                            {"ico",     "image/x-icon"},
                            {"jp2",     "image/jp2"},
                            {"jpg",     "image/jpeg"},
                            {"jpeg",    "image/jpeg"},
                            {"js",      "application/x-javascript"},
                            {"wma",     "audio/x-ms-wma"},
                            {"m4u",     "video/vnd.mpegurl"},
                            {"m4v",     "video/x-m4v"},
                            {"mid",     "audio/midi"},
                            {"midi",    "audio/midi"},
                            {"mov",     "video/quicktime"},
                            {"movie",   "video/x-sgi-movie"},
                            {"mp2",     "audio/mpeg"},
                            {"mp3",     "audio/mpeg"},
                            {"mp4",     "video/mp4"},
                            {"mpe",     "video/mpeg"},
                            {"mpeg",    "video/mpeg"},
                            {"mpg",     "video/mpeg"},
                            {"mpga",    "audio/mpeg"},
                            {"pdf",     "application/pdf"},
                            {"pgm",     "image/x-portable-graymap"},
                            {"pic",     "image/pict"},
                            {"pict",    "image/pict"},
                            {"png",     "image/png"},
                            {"ppt",     "application/vnd.ms-powerpoint"},
                            {"pptx",    "application/vnd.openxmlformats-officedocument.presentationml.presentation"},
                            {"potx",    "application/vnd.openxmlformats-officedocument.presentationml.template"},
                            {"ppsx",    "application/vnd.openxmlformats-officedocument.presentationml.slideshow"},
                            {"ppam",    "application/vnd.ms-powerpoint.addin.macroEnabled.12"},
                            {"pptm",    "application/vnd.ms-powerpoint.presentation.macroEnabled.12"},
                            {"potm",    "application/vnd.ms-powerpoint.template.macroEnabled.12"},
                            {"ppsm",    "application/vnd.ms-powerpoint.slideshow.macroEnabled.12"},
                            {"ps",      "application/postscript"},
                            {"qt",      "video/quicktime"},
                            {"qti",     "image/x-quicktime"},
                            {"qtif",    "image/x-quicktime"},
                            {"ra",      "audio/x-pn-realaudio"},
                            {"ram",     "audio/x-pn-realaudio"},
                            {"rtf",     "text/rtf"},
                            {"sgm",     "text/sgml"},
                            {"sgml",    "text/sgml"},
                            {"sh",      "application/x-sh"},
                            {"shar",    "application/x-shar"},
                            {"snd",     "audio/basic"},
                            {"src",     "application/x-wais-source"},
                            {"svg",     "image/svg+xml"},
                            {"swf",     "application/x-shockwave-flash"},
                            {"tar",     "application/x-tar"},
                            {"tif",     "image/tiff"},
                            {"tiff",    "image/tiff"},
                            {"txt",     "text/plain"},
                            {"wav",     "audio/x-wav"},
                            {"xht",     "application/xhtml+xml"},
                            {"xhtml",   "application/xhtml+xml"},
                            {"xls",     "application/vnd.ms-excel"},
                            {"xml",     "text/xml"},
                            {"xsl",     "application/xml"},
                            {"xlsx",    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
                            {"xltx",    "application/vnd.openxmlformats-officedocument.spreadsheetml.template"},
                            {"xlsm",    "application/vnd.ms-excel.sheet.macroEnabled.12"},
                            {"xltm",    "application/vnd.ms-excel.template.macroEnabled.12"},
                            {"xlam",    "application/vnd.ms-excel.addin.macroEnabled.12"},
                            {"xlsb",    "application/vnd.ms-excel.sheet.binary.macroEnabled.12"},
                            {"xslt",    "application/xslt+xml"},
                            {"xwd",     "image/x-xwindowdump"},
                            {"zip",     "application/zip"}
        };

        public string GetMIMEType(string FileExtensionString)
        {
            if (FileExtensionString.Length > 0 && MIMETypesDictionary.ContainsKey(FileExtensionString))
            {
                return MIMETypesDictionary[FileExtensionString].ToString();
            }
            return "unknown/unknown";
        }

        public string GetFileType(string MimeString)
        {
            if (MimeString.Length > 0 && MIMETypesDictionary.ContainsValue(MimeString))
            {
                foreach (KeyValuePair<string, string> pair in MIMETypesDictionary)
                    if (pair.Value == MimeString)
                    {
                        return pair.Key;
                    }
            }
            return "unknown";
        }

    }
}

﻿namespace InlineStorage_Reader
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btn_Extract = new System.Windows.Forms.Button();
            this.btn_SelectDestinationFolder = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_DestinationFolder = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_SelectGUID = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_NewGUID = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_GUID = new System.Windows.Forms.TextBox();
            this.btn_Insert = new System.Windows.Forms.Button();
            this.btn_SelectFile = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_SelectedFile = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(581, 237);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.btn_Extract);
            this.tabPage1.Controls.Add(this.btn_SelectDestinationFolder);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tbx_DestinationFolder);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.cb_SelectGUID);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(573, 211);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Read From InlineStorage";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(312, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "File Type";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {"ALL","text/xml","text/html","image/jpeg"});
            this.comboBox1.SelectedIndex = 0;
            this.comboBox1.Location = new System.Drawing.Point(316, 38);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btn_Extract
            // 
            this.btn_Extract.Location = new System.Drawing.Point(492, 182);
            this.btn_Extract.Name = "btn_Extract";
            this.btn_Extract.Size = new System.Drawing.Size(75, 23);
            this.btn_Extract.TabIndex = 5;
            this.btn_Extract.Text = "Extract";
            this.btn_Extract.UseVisualStyleBackColor = true;
            this.btn_Extract.Click += new System.EventHandler(this.btn_Extract_Click);
            // 
            // btn_SelectDestinationFolder
            // 
            this.btn_SelectDestinationFolder.Location = new System.Drawing.Point(315, 94);
            this.btn_SelectDestinationFolder.Name = "btn_SelectDestinationFolder";
            this.btn_SelectDestinationFolder.Size = new System.Drawing.Size(75, 23);
            this.btn_SelectDestinationFolder.TabIndex = 4;
            this.btn_SelectDestinationFolder.Text = "Select";
            this.btn_SelectDestinationFolder.UseVisualStyleBackColor = true;
            this.btn_SelectDestinationFolder.Click += new System.EventHandler(this.btn_SelectDestinationFolder_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Destination Folder";
            // 
            // tbx_DestinationFolder
            // 
            this.tbx_DestinationFolder.Location = new System.Drawing.Point(9, 96);
            this.tbx_DestinationFolder.Name = "tbx_DestinationFolder";
            this.tbx_DestinationFolder.Size = new System.Drawing.Size(300, 20);
            this.tbx_DestinationFolder.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "InlineStorage Record GUID";
            // 
            // cb_SelectGUID
            // 
            this.cb_SelectGUID.FormattingEnabled = true;
            this.cb_SelectGUID.Location = new System.Drawing.Point(9, 38);
            this.cb_SelectGUID.Name = "cb_SelectGUID";
            this.cb_SelectGUID.Size = new System.Drawing.Size(300, 21);
            this.cb_SelectGUID.TabIndex = 0;
            this.cb_SelectGUID.SelectedIndexChanged += new System.EventHandler(this.cb_SelectGUID_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btn_NewGUID);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.tbx_GUID);
            this.tabPage2.Controls.Add(this.btn_Insert);
            this.tabPage2.Controls.Add(this.btn_SelectFile);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.tbx_SelectedFile);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(573, 211);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Write Into InlineStorage";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btn_NewGUID
            // 
            this.btn_NewGUID.Location = new System.Drawing.Point(315, 94);
            this.btn_NewGUID.Name = "btn_NewGUID";
            this.btn_NewGUID.Size = new System.Drawing.Size(75, 23);
            this.btn_NewGUID.TabIndex = 6;
            this.btn_NewGUID.Text = "New GUID";
            this.btn_NewGUID.UseVisualStyleBackColor = true;
            this.btn_NewGUID.Click += new System.EventHandler(this.btn_NewGUID_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "GUID (override if change is needed)";
            // 
            // tbx_GUID
            // 
            this.tbx_GUID.Location = new System.Drawing.Point(9, 96);
            this.tbx_GUID.Name = "tbx_GUID";
            this.tbx_GUID.Size = new System.Drawing.Size(300, 20);
            this.tbx_GUID.TabIndex = 4;
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(492, 182);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(75, 23);
            this.btn_Insert.TabIndex = 3;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // btn_SelectFile
            // 
            this.btn_SelectFile.Location = new System.Drawing.Point(315, 36);
            this.btn_SelectFile.Name = "btn_SelectFile";
            this.btn_SelectFile.Size = new System.Drawing.Size(75, 23);
            this.btn_SelectFile.TabIndex = 2;
            this.btn_SelectFile.Text = "Select";
            this.btn_SelectFile.UseVisualStyleBackColor = true;
            this.btn_SelectFile.Click += new System.EventHandler(this.btn_SelectFile_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Selected File";
            // 
            // tbx_SelectedFile
            // 
            this.tbx_SelectedFile.Location = new System.Drawing.Point(9, 38);
            this.tbx_SelectedFile.Name = "tbx_SelectedFile";
            this.tbx_SelectedFile.Size = new System.Drawing.Size(300, 20);
            this.tbx_SelectedFile.TabIndex = 0;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.InitialDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 261);
            this.Controls.Add(this.tabControl1);
            this.Name = "Main";
            this.Text = "InlineStorage Reader / Writer";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btn_Extract;
        private System.Windows.Forms.Button btn_SelectDestinationFolder;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_DestinationFolder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_SelectGUID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.Button btn_SelectFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_SelectedFile;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_NewGUID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_GUID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InlineStorage_Reader
{
    public class InlineStorageEntity : BaseEntity
    {
        public string ID { get; set; }
        public string MediaType { get; set; }
        public string MediaName { get; set; }
        public byte[] Media { get; set; }
    }

    public class BaseEntity : INotifyPropertyChanged
    {
        public string _modifiedBy;
        public string _modifiedTimeStamp;
        public string _createdTimeStamp;
        public string _status;
        public bool _isChecked;
        public string _ownedBy;

        public string ModifiedBy
        {
            get { return _modifiedBy; }
            set
            {
                _modifiedBy = value;
                OnPropertyChanged("ModifiedBy");
            }
        }
        public string ModifiedTimeStamp
        {
            get { return _modifiedTimeStamp; }
            set
            {
                _modifiedTimeStamp = value;
                OnPropertyChanged("ModifiedTimeStamp");
            }
        }
        public string OwnedBy
        {
            get { return _ownedBy; }
            set
            {
                _ownedBy = value;
                OnPropertyChanged("OwnedBy");
            }
        }
        public string CreatedTimeStamp
        {
            get { return _createdTimeStamp; }
            set
            {
                _createdTimeStamp = value;
                OnPropertyChanged("CreatedTimeStamp");
            }
        }
        public string Status
        {
            get { return _status; }
            set
            {
                _status = value;
                OnPropertyChanged("Status");
            }
        }
        public bool IsChecked
        {
            get { return _isChecked; }
            set
            {
                _isChecked = value;
                OnPropertyChanged("IsChecked");
            }
        }
        private bool _isActive = true;
        private bool _isDelete = false;
        public bool IsActive
        {
            get { return _isActive; }
            set
            {
                _isActive = value;
                OnPropertyChanged("IsActive");
            }
        }
        public bool IsDeleted { get { return _isDelete; } set { _isDelete = value; OnPropertyChanged("IsDeleted"); } }

        private bool _canDeleteRecord = true;
        public bool CanDeleteRecord { get { return _canDeleteRecord; } set { _canDeleteRecord = value; OnPropertyChanged("CanDeleteRecord"); } }

        private bool _canShareRecord = true;
        public bool CanShareRecord { get { return _canShareRecord; } set { _canShareRecord = value; OnPropertyChanged("CanShareRecord"); } }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }

    public class GWRelatedFile
    {
        public string FileId { get; set; }
        public string FileName { get; set; }
        public string FileMime { get; set; }
        public string FilePath { get; set; }
        public byte[] FileStream { get; set; }
        public string FileText { get; set; }
        public IEnumerable<string> FileAllLines { get; set; }
        public bool IsNew { get; set; }
    }

}
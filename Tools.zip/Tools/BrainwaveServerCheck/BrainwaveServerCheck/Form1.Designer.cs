﻿namespace BrainwaveServerCheck
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_Discover = new System.Windows.Forms.Button();
            this.tbx_BrainwaveServerAddress = new System.Windows.Forms.TextBox();
            this.bt_GetCatalog = new System.Windows.Forms.Button();
            this.bt_ServerReachable = new System.Windows.Forms.Button();
            this.bt_GetLicense = new System.Windows.Forms.Button();
            this.tbx_status = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chbx_DomainAttached = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_Domain = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_Reg_BrainwaveServer = new System.Windows.Forms.TextBox();
            this.tbx_UserSID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bt_ReleaseLicense = new System.Windows.Forms.Button();
            this.lbl_ServerReachable = new System.Windows.Forms.Label();
            this.lbl_Catalog = new System.Windows.Forms.Label();
            this.lbl_License = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_Discover
            // 
            this.bt_Discover.Location = new System.Drawing.Point(12, 12);
            this.bt_Discover.Name = "bt_Discover";
            this.bt_Discover.Size = new System.Drawing.Size(140, 23);
            this.bt_Discover.TabIndex = 0;
            this.bt_Discover.Text = "Discover Server";
            this.bt_Discover.UseVisualStyleBackColor = true;
            this.bt_Discover.Click += new System.EventHandler(this.bt_Discover_Click);
            // 
            // tbx_BrainwaveServerAddress
            // 
            this.tbx_BrainwaveServerAddress.Location = new System.Drawing.Point(158, 14);
            this.tbx_BrainwaveServerAddress.Name = "tbx_BrainwaveServerAddress";
            this.tbx_BrainwaveServerAddress.Size = new System.Drawing.Size(235, 20);
            this.tbx_BrainwaveServerAddress.TabIndex = 1;
            // 
            // bt_GetCatalog
            // 
            this.bt_GetCatalog.Location = new System.Drawing.Point(12, 70);
            this.bt_GetCatalog.Name = "bt_GetCatalog";
            this.bt_GetCatalog.Size = new System.Drawing.Size(140, 23);
            this.bt_GetCatalog.TabIndex = 2;
            this.bt_GetCatalog.Text = "Get Catalog";
            this.bt_GetCatalog.UseVisualStyleBackColor = true;
            this.bt_GetCatalog.Click += new System.EventHandler(this.bt_GetCatalog_Click);
            // 
            // bt_ServerReachable
            // 
            this.bt_ServerReachable.Location = new System.Drawing.Point(12, 41);
            this.bt_ServerReachable.Name = "bt_ServerReachable";
            this.bt_ServerReachable.Size = new System.Drawing.Size(140, 23);
            this.bt_ServerReachable.TabIndex = 4;
            this.bt_ServerReachable.Text = "Is Server Reachable";
            this.bt_ServerReachable.UseVisualStyleBackColor = true;
            this.bt_ServerReachable.Click += new System.EventHandler(this.bt_ServerReachable_Click);
            // 
            // bt_GetLicense
            // 
            this.bt_GetLicense.Location = new System.Drawing.Point(12, 99);
            this.bt_GetLicense.Name = "bt_GetLicense";
            this.bt_GetLicense.Size = new System.Drawing.Size(140, 23);
            this.bt_GetLicense.TabIndex = 6;
            this.bt_GetLicense.Text = "Get License";
            this.bt_GetLicense.UseVisualStyleBackColor = true;
            this.bt_GetLicense.Click += new System.EventHandler(this.bt_GetLicense_Click);
            // 
            // tbx_status
            // 
            this.tbx_status.Location = new System.Drawing.Point(13, 158);
            this.tbx_status.Multiline = true;
            this.tbx_status.Name = "tbx_status";
            this.tbx_status.Size = new System.Drawing.Size(796, 81);
            this.tbx_status.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "BrainwaveServer:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chbx_DomainAttached);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbx_Domain);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbx_Reg_BrainwaveServer);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(413, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 111);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Registry";
            // 
            // chbx_DomainAttached
            // 
            this.chbx_DomainAttached.AutoSize = true;
            this.chbx_DomainAttached.Location = new System.Drawing.Point(109, 90);
            this.chbx_DomainAttached.Name = "chbx_DomainAttached";
            this.chbx_DomainAttached.Size = new System.Drawing.Size(15, 14);
            this.chbx_DomainAttached.TabIndex = 13;
            this.chbx_DomainAttached.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Domain attached ?";
            // 
            // tbx_Domain
            // 
            this.tbx_Domain.Location = new System.Drawing.Point(109, 58);
            this.tbx_Domain.Name = "tbx_Domain";
            this.tbx_Domain.Size = new System.Drawing.Size(276, 20);
            this.tbx_Domain.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Domain:";
            // 
            // tbx_Reg_BrainwaveServer
            // 
            this.tbx_Reg_BrainwaveServer.Location = new System.Drawing.Point(109, 29);
            this.tbx_Reg_BrainwaveServer.Name = "tbx_Reg_BrainwaveServer";
            this.tbx_Reg_BrainwaveServer.Size = new System.Drawing.Size(276, 20);
            this.tbx_Reg_BrainwaveServer.TabIndex = 9;
            // 
            // tbx_UserSID
            // 
            this.tbx_UserSID.Location = new System.Drawing.Point(522, 131);
            this.tbx_UserSID.Name = "tbx_UserSID";
            this.tbx_UserSID.Size = new System.Drawing.Size(276, 20);
            this.tbx_UserSID.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(419, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "User SID";
            // 
            // bt_ReleaseLicense
            // 
            this.bt_ReleaseLicense.Location = new System.Drawing.Point(13, 129);
            this.bt_ReleaseLicense.Name = "bt_ReleaseLicense";
            this.bt_ReleaseLicense.Size = new System.Drawing.Size(139, 23);
            this.bt_ReleaseLicense.TabIndex = 11;
            this.bt_ReleaseLicense.Text = "Release License";
            this.bt_ReleaseLicense.UseVisualStyleBackColor = true;
            this.bt_ReleaseLicense.Click += new System.EventHandler(this.bt_ReleaseLicense_Click);
            // 
            // lbl_ServerReachable
            // 
            this.lbl_ServerReachable.AutoSize = true;
            this.lbl_ServerReachable.Location = new System.Drawing.Point(158, 46);
            this.lbl_ServerReachable.Name = "lbl_ServerReachable";
            this.lbl_ServerReachable.Size = new System.Drawing.Size(54, 13);
            this.lbl_ServerReachable.TabIndex = 17;
            this.lbl_ServerReachable.Text = "lbl_Server";
            // 
            // lbl_Catalog
            // 
            this.lbl_Catalog.AutoSize = true;
            this.lbl_Catalog.Location = new System.Drawing.Point(158, 75);
            this.lbl_Catalog.Name = "lbl_Catalog";
            this.lbl_Catalog.Size = new System.Drawing.Size(59, 13);
            this.lbl_Catalog.TabIndex = 18;
            this.lbl_Catalog.Text = "lbl_Catalog";
            // 
            // lbl_License
            // 
            this.lbl_License.AutoSize = true;
            this.lbl_License.Location = new System.Drawing.Point(158, 104);
            this.lbl_License.Name = "lbl_License";
            this.lbl_License.Size = new System.Drawing.Size(60, 13);
            this.lbl_License.TabIndex = 19;
            this.lbl_License.Text = "lbl_License";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 254);
            this.Controls.Add(this.lbl_License);
            this.Controls.Add(this.lbl_Catalog);
            this.Controls.Add(this.lbl_ServerReachable);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_UserSID);
            this.Controls.Add(this.bt_ReleaseLicense);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbx_status);
            this.Controls.Add(this.bt_GetLicense);
            this.Controls.Add(this.bt_ServerReachable);
            this.Controls.Add(this.bt_GetCatalog);
            this.Controls.Add(this.tbx_BrainwaveServerAddress);
            this.Controls.Add(this.bt_Discover);
            this.Name = "Form1";
            this.Text = "Brainwave Server Check";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_Discover;
        private System.Windows.Forms.TextBox tbx_BrainwaveServerAddress;
        private System.Windows.Forms.Button bt_GetCatalog;
        private System.Windows.Forms.Button bt_ServerReachable;
        private System.Windows.Forms.Button bt_GetLicense;
        private System.Windows.Forms.TextBox tbx_status;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbx_Reg_BrainwaveServer;
        private System.Windows.Forms.TextBox tbx_Domain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chbx_DomainAttached;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_ReleaseLicense;
        private System.Windows.Forms.TextBox tbx_UserSID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_ServerReachable;
        private System.Windows.Forms.Label lbl_Catalog;
        private System.Windows.Forms.Label lbl_License;
    }
}


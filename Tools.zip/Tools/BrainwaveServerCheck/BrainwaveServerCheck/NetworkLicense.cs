﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using BWS.WebServices;
using System.DirectoryServices.AccountManagement;
using System.Net;
using System.Net.Sockets;

namespace BrainwaveServerCheck
{
    public partial class Form1
    {
        public string GetNetworkUserLicense()
        {
            string ConfigPath = string.Format(@"{0}\Brainwave\config\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));

            // LicenseMetaData Status Code:
            // S000 License Issued
            // S001 Your are not a Brainwave User
            // S002 Not enough user licenses
            // S003 Cannot reach the license server
            // S004 Request failed

            X509Certificate2 certificate = new X509Certificate2(ConfigPath + "BrainwaveServerSecurity.pfx", "c3xQT6Z2");
            ChannelFactory<ISynchro> channelFactory = null;
            EndpointAddress ep = null;
            ISynchro serviceObject = null;
            string BrainwaveServer = null;

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                return "S003";
            }

            // Create A service object for web services
            ep = new EndpointAddress(BrainwaveServer + @"/Synchro/");
            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.MaxReceivedMessageSize = int.MaxValue; // The ObjectMap is long !!! over 16,000. objects for 60 cases
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            // Get the file
            string _UserSID = UserPrincipal.Current.Sid.ToString();
            string _machineName = System.Environment.MachineName.ToString();

            try
            {
                LicenseMetaData licenseData = serviceObject.GetUserLicense(_machineName, GetLocalIP(), _UserSID);

                Registry.SetRegistryValue("UserRole", licenseData.Role);
                Registry.SetRegistryValue("UserCapabilities", licenseData.Capabilities);
                Registry.SetRegistryValue("UserSupervisorSID", licenseData.SupervisorSID);

                return licenseData.Status;
            }
            catch (FaultException)
            {
                return "S004";
            }
        }

        public string ReleaseNetworkUserLicense()
        {
            string ConfigPath = string.Format(@"{0}\Brainwave\config\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));

            // return Status Code:
            // S000 License Released
            // S003 Cannot reach the license server
            // S004 Request failed

            X509Certificate2 certificate = new X509Certificate2(ConfigPath + "BrainwaveServerSecurity.pfx", "c3xQT6Z2");
            ChannelFactory<ISynchro> channelFactory = null;
            EndpointAddress ep = null;
            ISynchro serviceObject = null;
            string BrainwaveServer = null;

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "") { return "S003"; }

            // Create A service object for web services
            ep = new EndpointAddress(BrainwaveServer + @"/Synchro/");
            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.MaxReceivedMessageSize = int.MaxValue; // The ObjectMap is long !!! over 16,000. objects for 60 cases
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            string _machineName = System.Environment.MachineName.ToString();

            try
            {
                serviceObject.ReleaseUserLicense(_machineName);
                return "S000";
            }
            catch (FaultException)
            {
                return "S004";
            }
        }

        public string GetLocalIP()
        {
            var localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            return localIpAddress.ToString();
        }
    }
}

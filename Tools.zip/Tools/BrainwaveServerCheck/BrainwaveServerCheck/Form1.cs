﻿using BWS.WebServices;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace BrainwaveServerCheck
{
    public partial class Form1 : Form
    {
        ISynchro serviceObject = null;
        ChannelFactory<ISynchro> channelFactory = null;
        EndpointAddress ep = null;

        string LocalCatalog = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\Catalog.xml";
        string TempCatalog = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\temp\Catalog.xml";
        string CatalogSchema = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\Catalog.xsd";
        string CertificateFile = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\BrainwaveServerSecurity.pfx";
        string CertificatePassword = "c3xQT6Z2";

        string BrainwaveServer;

        public Form1()
        {
            InitializeComponent();
            populateForm();
        }

        private void populateForm()
        {
            // Get infos from registry
            tbx_Reg_BrainwaveServer.Text    =  Registry.GetRegistryValue("BrainwaveServer").ToString();
            tbx_Domain.Text                 = Registry.GetRegistryValue("Domain").ToString();
            chbx_DomainAttached.Checked     = IsAttachedToDomain();

            // User information
            tbx_UserSID.Text                = GetLoggedInUser();

            // Checkmarks
            lbl_ServerReachable.Text    = string.Empty;
            lbl_Catalog.Text            = string.Empty;
            lbl_License.Text            = string.Empty;
        }

        private void bt_Discover_Click(object sender, EventArgs e)
        {
            tbx_status.Text = "";
            tbx_BrainwaveServerAddress.Text = "";
            tbx_BrainwaveServerAddress.Text = FindBrainwaveServerAddress().GetLeftPart(UriPartial.Authority).ToString();
            tbx_status.ForeColor = System.Drawing.Color.Green;
            tbx_status.Text = tbx_BrainwaveServerAddress.Text;
        }

        private void bt_ServerReachable_Click(object sender, EventArgs e)
        {
            lbl_ServerReachable.Text = string.Empty;

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer =="")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return;
            }

            if (IsBrainwaveServerOnline(BrainwaveServer))
            {
                lbl_ServerReachable.Text = "\u2713";
                lbl_ServerReachable.ForeColor = System.Drawing.Color.Green;
                tbx_status.ForeColor = System.Drawing.Color.Green;
                tbx_status.Text = "Reachable";
            }
            else
            {
                lbl_ServerReachable.Text = "X";
                lbl_ServerReachable.ForeColor = System.Drawing.Color.Red;
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Not Reachable";
            }
        }

        private void bt_GetCatalog_Click(object sender, EventArgs e)
        {
            lbl_Catalog.Text = string.Empty;

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return;
            }

            if (DownloadCatalog())
            {
                lbl_Catalog.Text = "\u2713";
                lbl_Catalog.ForeColor = System.Drawing.Color.Green;
                tbx_status.ForeColor = System.Drawing.Color.Green;
                tbx_status.Text = "Downloaded";
            }
            else
            {
                lbl_Catalog.Text = "X";
                lbl_Catalog.ForeColor = System.Drawing.Color.Red;
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Not Downloaded";
            }
        }

        private void bt_GetLicense_Click(object sender, EventArgs e)
        {
            lbl_License.Text = string.Empty;

            // LicenseMetaData Status Code:
            // S000 License Issued
            // S001 Your are not a Brainwave User
            // S002 Not enough user licenses
            // S003 Cannot reach the license server
            // S004 Request failed

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return;
            }

            string licenseStatus = GetNetworkUserLicense();
            switch (licenseStatus)
            {
                case "S000":
                    lbl_License.Text = "\u2713";
                    lbl_License.ForeColor = System.Drawing.Color.Green;
                    tbx_status.ForeColor = System.Drawing.Color.Green;
                    tbx_status.Text = "You can acquire a user license";
                    break;
                case "S001":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "You are not a Brainwave User";
                    break;
                case "S002":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Not enough user licenses";
                    break;
                case "S003":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Cannot reach the license server";
                    break;
                case "S004":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Request failed";
                    break;
                default:
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Request failed";
                    break;
            }
        }

        private void bt_ReleaseLicense_Click(object sender, EventArgs e)
        {
            // return Status Code:
            // S000 License Released
            // S003 Cannot reach the license server
            // S004 Request failed

            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return;
            }

            string licenseStatus = ReleaseNetworkUserLicense();
            switch (licenseStatus)
            {
                case "S000":
                    lbl_License.Text = string.Empty;
                    tbx_status.ForeColor = System.Drawing.Color.Green;
                    tbx_status.Text = "License Released";
                    break;
                case "S003":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Cannot reach the license server";
                    break;
                case "S004":
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Request failed";
                    break;
                default:
                    lbl_License.Text = "X";
                    lbl_License.ForeColor = System.Drawing.Color.Red;
                    tbx_status.ForeColor = System.Drawing.Color.Red;
                    tbx_status.Text = "Request failed";
                    break;
            }
        }

        private bool IsAttachedToDomain()
        {
            Win32.NetJoinStatus status = Win32.NetJoinStatus.NetSetupUnknownStatus;
            IntPtr pDomain = IntPtr.Zero;
            int result = Win32.NetGetJoinInformation(null, out pDomain, out status);
            if (pDomain != IntPtr.Zero)
            {
                Win32.NetApiBufferFree(pDomain);
            }
            if (result == Win32.ErrorSuccess)
            {
                return status == Win32.NetJoinStatus.NetSetupDomainName;
            }
            else
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Failed to get domain information";
                return false;
            }
        }

        private Uri FindBrainwaveServerAddress()
        {
            // Create the DiscoveryClient
            DiscoveryClient discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
            // Find Syncho endpoints
            FindCriteria FCriteria = new FindCriteria(typeof(ISynchro));
            //FCriteria.MaxResults = 1;
            //FCriteria.ScopeMatchBy.Equals("BWS.WebServices.Synchro");
            FindResponse findResponse = discoveryClient.Find(FCriteria);
            discoveryClient.Close();
            if (findResponse.Endpoints.Count > 0)
            {
                return findResponse.Endpoints[0].Address.Uri;
            }
            else
            {
                return null;
            }
        }

        private bool IsBrainwaveServerOnline(string server)
        {
            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return false;
            }

            X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
            string ServerPath = server.Trim() + @"/Synchro/";
            ep = new EndpointAddress(ServerPath);

            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            tcpb.MaxReceivedMessageSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferPoolSize = int.MaxValue; // should consider reducing that
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.CloseTimeout = TimeSpan.FromSeconds(20); // default: 10 seconds
            tcpb.OpenTimeout = TimeSpan.FromMinutes(1);  // default: 1 minute
            tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
            tcpb.SendTimeout = TimeSpan.FromMinutes(10); // default: 1 minute

            channelFactory = new ChannelFactory<ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            try
            {
                string IPAddress = serviceObject.GetServerIP();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private bool DownloadCatalog()
        {
            BrainwaveServer = tbx_BrainwaveServerAddress.Text.Trim();
            if (BrainwaveServer == null || BrainwaveServer == "")
            {
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text = "Discover Brainwave Server First";
                return false;
            }

            ISynchro serviceObject = null;

            X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
            string ServerPath = BrainwaveServer + @"/Synchro/";
            ep = new EndpointAddress(ServerPath);

            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
            tcpb.MaxReceivedMessageSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferSize = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferPoolSize = int.MaxValue; // should consider reducing that
            tcpb.TransferMode = TransferMode.Streamed;
            tcpb.CloseTimeout = TimeSpan.FromSeconds(20); // default: 10 seconds
            tcpb.OpenTimeout = TimeSpan.FromMinutes(1);  // default: 1 minute
            tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
            tcpb.SendTimeout = TimeSpan.FromMinutes(10); // default: 1 minute

            channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            // Get the Catalog
            var fileStream = File.Create(TempCatalog);
            tbx_status.ForeColor = System.Drawing.Color.Black;
            tbx_status.Text = "Calling Brainwave Server for Catalog";

            try
            {
                Stream FolioStream = serviceObject.GetCatalogFile(GetLoggedInUser(), System.Environment.MachineName.ToString());
                FolioStream.CopyTo(fileStream);
                fileStream.Close();

                tbx_status.Text += Environment.NewLine;
                tbx_status.ForeColor = System.Drawing.Color.Green;
                tbx_status.Text += "Successful of getting a Catalog";

                return true;
            }
            catch
            {
                tbx_status.Text += Environment.NewLine;
                tbx_status.ForeColor = System.Drawing.Color.Red;
                tbx_status.Text += "Unsuccessful of getting a Catalog";

                return false;
            }
        }

        private string GetLoggedInUser()
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem");
            ManagementObjectCollection collection = searcher.Get();
            string username = (string)collection.Cast<ManagementBaseObject>().First()["UserName"];

            NTAccount f = new NTAccount(username);
            SecurityIdentifier s = (SecurityIdentifier)f.Translate(typeof(SecurityIdentifier));
            String sidString = s.ToString();

            return sidString;
        }
    }

    internal class Win32
    {
        public const int ErrorSuccess = 0;

        [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int NetGetJoinInformation(string server, out IntPtr domain, out NetJoinStatus status);

        [DllImport("Netapi32.dll")]
        public static extern int NetApiBufferFree(IntPtr Buffer);

        public enum NetJoinStatus
        {
            NetSetupUnknownStatus = 0,
            NetSetupUnjoined,
            NetSetupWorkgroupName,
            NetSetupDomainName
        }
    }
}

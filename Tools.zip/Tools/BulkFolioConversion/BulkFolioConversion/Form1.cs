﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace BulkFolioConversion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tbx_FolioDirectory.Text = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\";
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                tbx_FolioDirectory.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btn_Convert_Click(object sender, EventArgs e)
        {
            string SourceDirectory = tbx_FolioDirectory.Text;
            string SchemaDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\";
            string currentLine;

            DirectoryInfo d = new DirectoryInfo(SourceDirectory);
            FileInfo[] Files = d.GetFiles("*.xml"); //Getting Text files

            // Progress bar initialization
            progressBar1.Minimum = 0;
            progressBar1.Maximum = d.GetFiles().Length;
            int filecount = 0;

            foreach (FileInfo file in Files)
            {
                if (file.Name == "Catalog.xml") break;

                string SourceFile = String.Format(@"{0}\{1}", SourceDirectory, file.Name);
                string TempFile1 = String.Format(@"{0}\{1}.temp", SourceDirectory, file.Name);

                // Change XML node names
                StreamReader reader = new StreamReader(SourceFile);
                StreamWriter writer = new StreamWriter(TempFile1);

                while (!reader.EndOfStream)
                {
                    currentLine = reader.ReadLine();
                    currentLine = currentLine.Replace("<Case>", "<BF_Cases><Case>");
                    currentLine = currentLine.Replace("</Case>", "</Case></BF_Cases>");
                    currentLine = currentLine.Replace("Facts>", "BF_Facts>");
                    currentLine = currentLine.Replace("Subjects>", "BF_Subjects>");
                    currentLine = currentLine.Replace("Groups>", "BF_Groups>");
                    currentLine = currentLine.Replace("Sets>", "BF_Sets>");
                    currentLine = currentLine.Replace("Protocols>", "BF_Protocols>");
                    currentLine = currentLine.Replace("TestSetups>", "BF_TestSetups>");
                    currentLine = currentLine.Replace("Tests>", "BF_Tests>");
                    currentLine = currentLine.Replace("Analyses>", "BF_Analyses>");
                    currentLine = currentLine.Replace("Reports>", "BF_Reports>");
                    currentLine = currentLine.Replace("InlineStorages>", "BF_InlineStorages>");
                    currentLine = currentLine.Replace("XrefConnections>", "BF_XrefConnections>");
                    writer.Write(currentLine + "\r\n");
                }
                reader.Close();
                writer.Close();

                // Remove duplicate "Test" nodes
                DataSet DS = new DataSet("BrainWave_DB");
                DS.ReadXmlSchema(SchemaDirectory + "BrainWave_DB.xsd");
                DS.EnforceConstraints = false;
                DS.ReadXml(TempFile1);

                //Populate the attributes (Case and Subject tables)
                foreach (DataRow dr in DS.Tables["Case"].Rows)
                {
                    dr["Serial"] = 0;
                    dr["Sync"] = true;
                    dr["IsActive"] = true;
                    dr["IsDeleted"] = false;
                    dr["IsLocked"] = false;
                }

                foreach (DataRow dr in DS.Tables["Subject"].Rows)
                {
                    dr["IsActive"] = true;
                }

                List<DataRow> rowsToDelete = new List<DataRow>();
                foreach (DataRow dr in DS.Tables["Test"].Rows)
                {
                    if (dr["BF_Tests_Id"].ToString() != "0") rowsToDelete.Add(dr);
                }
                foreach (var r in rowsToDelete)
                {
                    DS.Tables["Test"].Rows.Remove(r);
                }
                DS.Tables["Test"].AcceptChanges();
                DS.WriteXml(TempFile1);

                // Change the Root name
                StreamReader reader1 = new StreamReader(TempFile1);
                StreamWriter writer1 = new StreamWriter(SourceFile);

                while (!reader1.EndOfStream)
                {
                    currentLine = reader1.ReadLine();
                    currentLine = currentLine.Replace("<NewDataSet", "<BrainWave_DB Version=\"4.0.0.0\"");
                    currentLine = currentLine.Replace("</NewDataSet>", "</BrainWave_DB>");
                    writer1.Write(currentLine + "\r\n");
                }
                reader1.Close();
                writer1.Close();

                File.Delete(TempFile1);
                progressBar1.Value = ++filecount;
            }
            MessageBox.Show("Done");
            Application.Exit();

        }

    }
}

﻿namespace XML_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_SelectedFile = new System.Windows.Forms.TextBox();
            this.tbx_DestinationFolder = new System.Windows.Forms.TextBox();
            this.btn_SelectFile = new System.Windows.Forms.Button();
            this.btn_SelectDestinationFolder = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Selected File";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Destination Folder";
            // 
            // tbx_SelectedFile
            // 
            this.tbx_SelectedFile.Location = new System.Drawing.Point(15, 25);
            this.tbx_SelectedFile.Name = "tbx_SelectedFile";
            this.tbx_SelectedFile.Size = new System.Drawing.Size(457, 20);
            this.tbx_SelectedFile.TabIndex = 2;
            // 
            // tbx_DestinationFolder
            // 
            this.tbx_DestinationFolder.Location = new System.Drawing.Point(15, 79);
            this.tbx_DestinationFolder.Name = "tbx_DestinationFolder";
            this.tbx_DestinationFolder.Size = new System.Drawing.Size(457, 20);
            this.tbx_DestinationFolder.TabIndex = 3;
            // 
            // btn_SelectFile
            // 
            this.btn_SelectFile.Location = new System.Drawing.Point(478, 23);
            this.btn_SelectFile.Name = "btn_SelectFile";
            this.btn_SelectFile.Size = new System.Drawing.Size(75, 23);
            this.btn_SelectFile.TabIndex = 4;
            this.btn_SelectFile.Text = "Select";
            this.btn_SelectFile.UseVisualStyleBackColor = true;
            this.btn_SelectFile.Click += new System.EventHandler(this.btn_SelectFile_Click);
            // 
            // btn_SelectDestinationFolder
            // 
            this.btn_SelectDestinationFolder.Location = new System.Drawing.Point(478, 77);
            this.btn_SelectDestinationFolder.Name = "btn_SelectDestinationFolder";
            this.btn_SelectDestinationFolder.Size = new System.Drawing.Size(75, 23);
            this.btn_SelectDestinationFolder.TabIndex = 5;
            this.btn_SelectDestinationFolder.Text = "Select";
            this.btn_SelectDestinationFolder.UseVisualStyleBackColor = true;
            this.btn_SelectDestinationFolder.Click += new System.EventHandler(this.btn_SelectDestinationFolder_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(572, 77);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Convert";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Btn_Convert_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "XML Files|*.xml|All Files|*.*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 118);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btn_SelectDestinationFolder);
            this.Controls.Add(this.btn_SelectFile);
            this.Controls.Add(this.tbx_DestinationFolder);
            this.Controls.Add(this.tbx_SelectedFile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "XML Data File Converter 2.3 to 3.0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_SelectedFile;
        private System.Windows.Forms.TextBox tbx_DestinationFolder;
        private System.Windows.Forms.Button btn_SelectFile;
        private System.Windows.Forms.Button btn_SelectDestinationFolder;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}


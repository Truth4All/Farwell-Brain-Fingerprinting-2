﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Xsl;
using System.Reflection;

namespace XML_Converter
{
    public partial class Form1 : Form
    {
        private string CurrentAppDir;
        private const string stylesheet = "File_Conversion(2.3-3.0).xsl";
        private const string sourceFileType = "*.xml";
        private string OutputFilename;

        public Form1()
        {
            CurrentAppDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            InitializeComponent();
        }

        private void btn_SelectFile_Click(object sender, EventArgs e)
        {
            DialogResult result = this.openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_SelectedFile.Text = openFileDialog1.FileName;
                tbx_DestinationFolder.Text = Path.GetDirectoryName(tbx_SelectedFile.Text).ToString() + "\\";
                OutputFilename = Path.GetFileName(tbx_SelectedFile.Text);
            }
        }

        private void btn_SelectDestinationFolder_Click(object sender, EventArgs e)
        {
            DialogResult result = this.folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_DestinationFolder.Text = folderBrowserDialog1.SelectedPath + "\\" ;
            }
        }

        private void Btn_Convert_Click(object sender, EventArgs e)
        {
            XslCompiledTransform xslt = new XslCompiledTransform(true);

            // Create a resolver and specify the necessary credentials.
            XmlSecureResolver resolver = new XmlSecureResolver(new XmlUrlResolver(), CurrentAppDir);
            System.Net.NetworkCredential myCred;
            myCred = new System.Net.NetworkCredential();
            resolver.Credentials = myCred;

            String FullPathStyleSheet = Path.Combine(CurrentAppDir, stylesheet);
            xslt.Load(FullPathStyleSheet, XsltSettings.TrustedXslt, resolver);
            string backupFile = tbx_SelectedFile.Text + ".backup";
            FileStream outputStream = new FileStream(tbx_DestinationFolder.Text + "Converted-" + OutputFilename, FileMode.Create);
            xslt.Transform(tbx_SelectedFile.Text, null, outputStream);
            outputStream.Close();
        }
    }
}

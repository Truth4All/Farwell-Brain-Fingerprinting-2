﻿using System;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Windows.Forms;
using Brainwave.Data;
using Brainwave.Entities;
using System.Collections.Generic;

namespace BWS.CatalogBuilder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tbx_FolioDirectory.Text = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\BrainwaveServer\documents\";
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                tbx_FolioDirectory.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btn_Create_Click(object sender, EventArgs e)
        {
            string SourceDirectory = tbx_FolioDirectory.Text;
            string SchemaDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\";

            DirectoryInfo d = new DirectoryInfo(SourceDirectory);
            FileInfo[] Files = d.GetFiles("*.xml"); //Getting Text files

            // new Catalog
            DataSet Catalog = new DataSet();
            Catalog.ReadXmlSchema(SchemaDirectory + "Catalog.xsd");

            //Progress Bar
            progressBar1.Minimum = 0;
            progressBar1.Maximum = d.GetFiles().Length;
            int step = 0;

            foreach (FileInfo file in Files)
            {
                if (file.Name == "Catalog.xml") break;

                DataRow newRecord = Catalog.Tables["Case"].NewRow();
                string SourceFile = String.Format(@"{0}\{1}", SourceDirectory, file.Name);

                DataSet DS = new DataSet();
                DS.ReadXmlSchema(SchemaDirectory + "BrainWave_DB.xsd");
                DS.EnforceConstraints = false;
                DS.ReadXml(SourceFile);

                // Case GUID
                string CaseGUID = DS.Tables["Case"].Rows[0]["GUID"].ToString();

                // Case Serial Number
                int Serial = (int)DS.Tables["Case"].Rows[0]["Serial"];

                // JurisdictionID
                string JurisdictionID = DS.Tables["Case"].Rows[0]["JurisdictionID"].ToString();

                // Case Name
                string expression = String.Format("GUID = '{0}' and LCID = 'en-US'", DS.Tables["Case"].Rows[0]["CaseName"].ToString());
                DataRow[] selectedRows = DS.Tables["Language_Asset"].Select(expression);
                string CaseName = selectedRows[0]["Textual"].ToString();

                // Case Summary
                string CaseSummary = "";
                expression = String.Format("GUID = '{0}' and LCID = 'en-US'", DS.Tables["Case"].Rows[0]["CaseSummary"].ToString());
                selectedRows = DS.Tables["Language_Asset"].Select(expression);
                if (selectedRows.Length > 0) { CaseSummary = selectedRows[0]["Textual"].ToString(); }

                // Case Summary

                newRecord["GUID"]               = CaseGUID;
                newRecord["Serial"]             = Serial;
                newRecord["Sync"]               = true;
                newRecord["IsActive"]           = true;
                newRecord["IsDeleted"]          = false;
                newRecord["IsLocked"]           = false;
                newRecord["JurisdictionID"]     = JurisdictionID;
                newRecord["CaseName"]           = CaseName;
                newRecord["CaseSummary"]        = CaseSummary;
                newRecord["ModifiedBy"]         = UserPrincipal.Current.DisplayName.ToString();
                newRecord["ModifiedTimestamp"]  = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                newRecord["OwnedBy"]            = UserPrincipal.Current.DisplayName.ToString();
                newRecord["CreatedTimestamp"]   = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                newRecord["LockedBy"]           = "";

                Catalog.Tables["Case"].Rows.Add(newRecord);

                // Add Record to database (BrainwaveDB/BF_Catalog
                CatalogDL cdl = new CatalogDL();
                cdl.CreateCatalogRecord(Serial, CaseGUID, JurisdictionID, CaseName, CaseSummary, UserPrincipal.Current.Sid.ToString(), "");

                progressBar1.Value = ++step;
            }

            Catalog.WriteXml(tbx_FolioDirectory.Text + "Catalog.xml");
            MessageBox.Show("Done");
            Application.Exit();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            string SchemaDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\";

            // new Catalog
            DataSet Catalog = new DataSet();
            Catalog.ReadXmlSchema(SchemaDirectory + "Catalog.xsd");

            CatalogDL cdl = new CatalogDL();
            List<CatalogEntity> folios = cdl.ReadCatalogRecords();
            foreach(CatalogEntity folio in folios)
            {
                DataRow newRecord = Catalog.Tables["Case"].NewRow();

                newRecord["GUID"]               = folio.GUID;
                newRecord["Serial"]             = folio.Serial;
                newRecord["Sync"]               = folio.Sync;
                newRecord["IsActive"]           = folio.IsActive;
                newRecord["IsDeleted"]          = folio.IsDeleted;
                newRecord["IsLocked"]           = folio.IsLocked;
                newRecord["JurisdictionID"]     = folio.JurisdictionID;
                newRecord["CaseName"]           = folio.CaseName;
                newRecord["CaseSummary"]        = folio.CaseSummary;
                newRecord["ModifiedBy"]         = folio.ModifiedBy;
                newRecord["ModifiedTimestamp"]  = folio.ModifiedTimestamp;
                newRecord["OwnedBy"]            = folio.OwnedBy;
                newRecord["CreatedTimestamp"]   = folio.CreatedTimestamp;
                newRecord["LockedBy"]           = folio.LockedBy;

                Catalog.Tables["Case"].Rows.Add(newRecord);
            }

            Catalog.WriteXml(tbx_FolioDirectory.Text + "Catalog.xml");
            MessageBox.Show("Done");
            Application.Exit();

        }


    }
}

﻿using System;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace Registry_Editor
{
    public class Database_Read
    {
        public DataTable ConfigurationTable;

        //System Group
        public string   Language;               // System Default Language
        public string   CustomerName;
        public string   GoogleKey;

        // Capture Group
        public int      DefaultSamplingRate;    // System Sampling Rate
        public int      HeadsetResolution;      // 
        public int      DefaultPGAGain;
        public int      TargetsRequired;        // Required number of good Target trials:12
        public int      ProbesRequired;         // Required number of good Probe trials:12
        public int      IrrelevantsRequired;    // Required number of good Irrelevant trials:36
        public int      ERPInterval;            // Stimulus Interval:3000
        public int      FixationTime;           // Fixation time prior Stimulus onset:1000
        public int      TextExposureTime;       // Text Stimulus Exposition: 400
        public int      ImageExposureTime;      // Image Stimulus Exposition: 400
        public int      EOGRange;               // Max allowable range for EOG channels:2000
        public int      EEGRange;               // Max allowable range for EEG channels:2000
        public int      CaptureDuration;        // Capture Duration:3800
        public int      DataPostStimulus;       // Data epoch post-Stimulus:2800
        public int      ReactionTimeWindow;     // Valid period for reaction capture

        //Headset Group
        public string   btAddress;              // Headset_ID (MAC Address)
        public string   HeadsetDevConnection;   //
        public int      Channels;               // 

        //Tamper Protection
        public string   UserLicencesMD5;
        public string   TestLicensesMD5;
        public string   MachineHardwareID;

        //Analysis Group
        public int      EEGRangeCriterion;
        public int      EOGRangeCriterion;
        public int      FlatlineRange;
        public string   AnalysisEpoch;
        public int      AnalysisEpochStart;
        public int      AnalysisEpochEnd;
        public int      AnalysisBaselineStart;
        public int      AnalysisBaselineEnd;
        public int      RejectionEpochStart;
        public int      RejectionEpochEnd;
        public int      MERMERWindowStart;
        public int      MERMERWindowEnd;
        public string   AnalysisChannel;
        public int      MinimumNumberTrials;
        public int      PreliminaryMinTrials;
        public int      InfoPresentCriterion;
        public int      InfoAbsentCriterion;
        public int      BootstrappingIterations;
        public string   AnalysisMethod;
        public string   LowPassFilter;
        public int      AnalysisGraphStart;
        public int      AnalysisGraphEnd;
        public int      MERMERStartPoint;


        public Database_Read()
        {
            // Connection string
            ConfigurationTable      = GetConfigurationFromDB(main.connectionString);  // Fill the internal datatable from database

            //System Group
            Language                = GetConfigurationString("584d58a5-3f56-4a05-af01-f20cc307cf89");
            CustomerName            = GetConfigurationString("0c03410a-fcdb-4b63-84a1-2b4bf02528e3");
            GoogleKey               = GetConfigurationString("cb55004b-24d2-4b25-9f85-ac37e7a2d013");

            // Capture Group
            DefaultSamplingRate     = GetConfigurationInteger("53B4AE82-3E39-4CF0-9F6C-91519D0D7C23"); // 512
            HeadsetResolution       = GetConfigurationInteger("6FB77766-63E4-4006-99FC-AC39EB8D4BDE"); // 24
            DefaultPGAGain          = GetConfigurationInteger("6040EA13-077F-48D7-B040-727D5DB6BEF4"); // 1 at start
            TargetsRequired         = GetConfigurationInteger("4312C1E2-AD6F-4BED-ADC9-6DBB7A11E6AA");
            ProbesRequired          = GetConfigurationInteger("66CB6DC0-F52F-4311-973F-A9C413F7B153");
            IrrelevantsRequired     = GetConfigurationInteger("B1EA48CF-20D3-4B0B-9F92-312F089BC1DE");
            ERPInterval             = GetConfigurationInteger("FFEB82E1-382D-45D8-8B83-938D808502C1"); // 3000 mS
            FixationTime            = GetConfigurationInteger("B80D9364-A51F-44F1-BF11-3FC73A85B2A0"); // 1000 mS
            TextExposureTime        = GetConfigurationInteger("64E4BF89-8CD1-403A-95CC-105E8456E492"); // 400 mS
            ImageExposureTime       = GetConfigurationInteger("FBBA9379-E126-44BC-888D-D615923CC62B"); // 400 mS
            EOGRange                = GetConfigurationInteger("A993B010-7DF3-4C3E-BD70-571863566757");
            EEGRange                = GetConfigurationInteger("B4B65C80-4E59-405F-A544-2B91219F4CD4");
            CaptureDuration         = GetConfigurationInteger("1D2DD90E-C1B2-473B-9DAE-7757AA0D492E"); // 3800 mS
            DataPostStimulus        = GetConfigurationInteger("67F70DBE-E32E-4B68-909C-2F39DDFD0C41"); // 2800 mS
            ReactionTimeWindow      = GetConfigurationInteger("6E3055AF-B371-4DF5-A0A7-40D1B016BAB0"); // 1800 mS

            //Headset Group
            btAddress               = GetConfigurationString("E57B9D7A-9628-46F2-A356-AD904935D3C1"); //"001AFF0900B6"
            HeadsetDevConnection    = GetConfigurationString("411411f8-9012-4942-8f44-3fb20145fda6"); //
            Channels                = GetConfigurationInteger("C520E37E-74B6-4E1F-BA03-31B5D1176A10"); // 2

            //Tamper Protection
            UserLicencesMD5         = GetConfigurationString("d25ae539-6ac2-49fe-9a5e-e564a9174525"); //
            TestLicensesMD5         = GetConfigurationString("fb6d2cfc-5bbc-4968-ab3f-0cce3515fa89"); //
            MachineHardwareID       = GetConfigurationString("48ad3e28-88e9-4141-8df7-e2fba0b6cb05"); //

            //Analysis Group
            EEGRangeCriterion       = GetConfigurationInteger("6c173823-7318-491a-82c3-cb0895298d4b");
            EOGRangeCriterion       = GetConfigurationInteger("d2c7a493-adea-4f8a-aa29-76f22625f94f");
            FlatlineRange           = GetConfigurationInteger("f04391fb-10ce-4315-913e-419e3b6da316");
            AnalysisEpoch           = GetConfigurationString("1e7f9a12-8077-402b-99c9-e187decb6960");
            AnalysisEpochStart      = GetConfigurationInteger("8258891b-2290-4030-a862-22d45a906e70");
            AnalysisEpochEnd        = GetConfigurationInteger("f47d9dfb-ca51-4d25-a002-557dc3a286a8");
            AnalysisBaselineStart   = GetConfigurationInteger("fa7c0ac4-02db-4f38-9fb0-2fc06295f38e");
            AnalysisBaselineEnd     = GetConfigurationInteger("4b1b6e9b-badc-4f44-a774-97930b007adb");
            RejectionEpochStart     = GetConfigurationInteger("3feda310-06cf-40d8-aa7f-8f08e6ca8592");
            RejectionEpochEnd       = GetConfigurationInteger("7dcf0c67-d0c6-4599-bd56-2dfc60136beb");
            MERMERWindowStart       = GetConfigurationInteger("2df0ac1b-28f3-42b5-9d37-d45e684cc39e");
            MERMERWindowEnd         = GetConfigurationInteger("258a1a8f-0866-4192-a7d0-24fd9e069e4e");
            AnalysisChannel         = GetConfigurationString("50477937-7d9c-4a15-baaf-fc144dfe1a61"); //
            MinimumNumberTrials     = GetConfigurationInteger("848360ac-f710-4518-a93c-fd05e9d25b97");
            PreliminaryMinTrials    = GetConfigurationInteger("320861e9-547c-4c48-aecb-708797fbfadb");
            InfoPresentCriterion    = GetConfigurationInteger("40eae0c1-07bb-445d-b48c-e462808236b3");
            InfoAbsentCriterion     = GetConfigurationInteger("703fcf3d-6d1e-49a5-98bc-fc6543772098");
            BootstrappingIterations = GetConfigurationInteger("fbfbfe97-f08b-4036-b29d-06b883c70005");
            AnalysisMethod          = GetConfigurationString("bbc19d13-5471-4f25-88b3-a36a34db8cdc"); //
            LowPassFilter           = GetConfigurationString("e85020d0-bd83-49c6-9310-77495679900c"); //
            AnalysisGraphStart      = GetConfigurationInteger("638c181d-d25e-4a1f-acc4-0e30e2f4f46d");
            AnalysisGraphEnd        = GetConfigurationInteger("99dd1b5c-4a47-455d-b31c-e3d5895cc385");
            MERMERStartPoint        = GetConfigurationInteger("7d5e160a-890e-4758-8948-d64d4b8a9ad8");
        }

        public DataTable GetConfigurationFromDB(string ConnectionString)
        {
            DataTable ConfigTable = new DataTable();
            SqlConnection spContentConn = new SqlConnection(ConnectionString);
            string sqlselectQuery = "SELECT KeyClassGUID,KeyValue FROM BF_Registry";
            try
            {
                spContentConn.Open();
                SqlCommand sqlCmd = new SqlCommand(sqlselectQuery, spContentConn);
                sqlCmd.CommandTimeout = 0;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.ExecuteNonQuery();
                SqlDataAdapter adptr = new SqlDataAdapter(sqlCmd);
                adptr.Fill(ConfigTable);
                spContentConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (spContentConn != null)
                    spContentConn.Dispose();
            }
            return ConfigTable;
        }

        public string GetConfigurationString(string KeyClassGUID)
        {
            try
            {
                KeyClassGUID = "KeyClassGUID = '" + KeyClassGUID + "'";
                return ConfigurationTable.Select(KeyClassGUID)[0].ItemArray[1].ToString();
            }
            catch
            {
                return "";
            }
        }
        
        public int GetConfigurationInteger(string KeyClassGUID)
        {
            try
            {
                KeyClassGUID = "KeyClassGUID = '" + KeyClassGUID + "'";
                return Convert.ToInt32(ConfigurationTable.Select(KeyClassGUID)[0].ItemArray[1]);
            }
            catch
            {
                return 0;
            }
        }
    }
}

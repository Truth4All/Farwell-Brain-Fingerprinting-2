﻿namespace Registry_Editor
{
    class Registry
    {
        public static void InitializeRegistryValue(string key, object value)
        {
            if (GetRegistryValue(key) == null)
            {
                Microsoft.Win32.RegistryKey wkey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Brainwave");
                if (value != null)
                {
                    wkey.SetValue(key, value);
                }
                wkey.Close();
            }
        }

        public static void SetRegistryValue(string key, object value)
        {
            Microsoft.Win32.RegistryKey wkey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Brainwave");
            if (value != null)
            {
                wkey.SetValue(key, value);
            }
            wkey.Close();
        }

        public static object GetRegistryValue(string key)
        {
            Microsoft.Win32.RegistryKey rkey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            return rkey.GetValue(key, null);
        }

        public static bool GetBooleanRegistryValue(string key)
        {
            Microsoft.Win32.RegistryKey rkey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Brainwave");
            if (rkey.GetValue(key, null).ToString() == "True")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Registry_Editor
{
    public partial class main
    {
        private void FactoryReset_Click(object sender, EventArgs e)
        {
            SqlConnection spContentConn = new SqlConnection(connectionString);
            string sqlQuery = SQLResetQuery;
            try
            {
                spContentConn.Open();
                SqlCommand sqlCmd = new SqlCommand(sqlQuery, spContentConn);
                sqlCmd.CommandTimeout = 0;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.ExecuteNonQuery();
                spContentConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (spContentConn != null)
                    spContentConn.Dispose();
            }

            LoadDefaultValues();
        }

        string SQLResetQuery =  "UPDATE [BF_Registry] SET [KeyValue] = 'en-US'          WHERE [KeyClassGUID] = '584d58a5-3f56-4a05-af01-f20cc307cf89'; " + // Language
                                "UPDATE [BF_Registry] SET [KeyValue] = '512'            WHERE [KeyClassGUID] = '53B4AE82-3E39-4CF0-9F6C-91519D0D7C23'; " + // DefaultSamplingRate
                                "UPDATE [BF_Registry] SET [KeyValue] = '24'             WHERE [KeyClassGUID] = '6FB77766-63E4-4006-99FC-AC39EB8D4BDE'; " + // HeadsetResolution
                                "UPDATE [BF_Registry] SET [KeyValue] = '1'              WHERE [KeyClassGUID] = '6040EA13-077F-48D7-B040-727D5DB6BEF4'; " + // DefaultPGAGain
                                "UPDATE [BF_Registry] SET [KeyValue] = '12'             WHERE [KeyClassGUID] = '4312C1E2-AD6F-4BED-ADC9-6DBB7A11E6AA'; " + // TargetsRequired
                                "UPDATE [BF_Registry] SET [KeyValue] = '12'             WHERE [KeyClassGUID] = '66CB6DC0-F52F-4311-973F-A9C413F7B153'; " + // ProbesRequired
                                "UPDATE [BF_Registry] SET [KeyValue] = '36'             WHERE [KeyClassGUID] = 'B1EA48CF-20D3-4B0B-9F92-312F089BC1DE'; " + // IrrelevantsRequired
                                "UPDATE [BF_Registry] SET [KeyValue] = '3000'           WHERE [KeyClassGUID] = 'FFEB82E1-382D-45D8-8B83-938D808502C1'; " + // ERPInterval
                                "UPDATE [BF_Registry] SET [KeyValue] = '1000'           WHERE [KeyClassGUID] = 'B80D9364-A51F-44F1-BF11-3FC73A85B2A0'; " + // FixationTime
                                "UPDATE [BF_Registry] SET [KeyValue] = '400'            WHERE [KeyClassGUID] = '64E4BF89-8CD1-403A-95CC-105E8456E492'; " + // TextExposureTime
                                "UPDATE [BF_Registry] SET [KeyValue] = '400'            WHERE [KeyClassGUID] = 'FBBA9379-E126-44BC-888D-D615923CC62B'; " + // ImageExposureTime
                                "UPDATE [BF_Registry] SET [KeyValue] = '250'            WHERE [KeyClassGUID] = 'A993B010-7DF3-4C3E-BD70-571863566757'; " + // EOGRange
                                "UPDATE [BF_Registry] SET [KeyValue] = '100'            WHERE [KeyClassGUID] = 'B4B65C80-4E59-405F-A544-2B91219F4CD4'; " + // EEGRange
                                "UPDATE [BF_Registry] SET [KeyValue] = '3800'           WHERE [KeyClassGUID] = '1D2DD90E-C1B2-473B-9DAE-7757AA0D492E'; " + // CaptureDuration
                                "UPDATE [BF_Registry] SET [KeyValue] = '2800'           WHERE [KeyClassGUID] = '67F70DBE-E32E-4B68-909C-2F39DDFD0C41'; " + // DataPostStimulus
                                "UPDATE [BF_Registry] SET [KeyValue] = '1800'           WHERE [KeyClassGUID] = '6E3055AF-B371-4DF5-A0A7-40D1B016BAB0'; " + // ReactionTimeWindow
                                "UPDATE [BF_Registry] SET [KeyValue] = '2'              WHERE [KeyClassGUID] = 'C520E37E-74B6-4E1F-BA03-31B5D1176A10'; " + // Channels
                                "UPDATE [BF_Registry] SET [KeyValue] = '100'            WHERE [KeyClassGUID] = '6c173823-7318-491a-82c3-cb0895298d4b'; " + // EEGRangeCriterion
                                "UPDATE [BF_Registry] SET [KeyValue] = '250'            WHERE [KeyClassGUID] = 'd2c7a493-adea-4f8a-aa29-76f22625f94f'; " + // EOGRangeCriterion
                                //"UPDATE [BF_Registry] SET [KeyValue] = '0'              WHERE [KeyClassGUID] = 'f04391fb-10ce-4315-913e-419e3b6da316'; " + // FlatlineRange
                                //"UPDATE [BF_Registry] SET [KeyValue] = 'whole'          WHERE [KeyClassGUID] = '1e7f9a12-8077-402b-99c9-e187decb6960'; " + // AnalysisEpoch
                                "UPDATE [BF_Registry] SET [KeyValue] = '300'            WHERE [KeyClassGUID] = '8258891b-2290-4030-a862-22d45a906e70'; " + // AnalysisEpochStart
                                "UPDATE [BF_Registry] SET [KeyValue] = '1800'           WHERE [KeyClassGUID] = 'f47d9dfb-ca51-4d25-a002-557dc3a286a8'; " + // AnalysisEpochEnd
                                "UPDATE [BF_Registry] SET [KeyValue] = '-250'           WHERE [KeyClassGUID] = 'fa7c0ac4-02db-4f38-9fb0-2fc06295f38e'; " + // AnalysisBaselineStart
                                "UPDATE [BF_Registry] SET [KeyValue] = '0'              WHERE [KeyClassGUID] = '4b1b6e9b-badc-4f44-a774-97930b007adb'; " + // AnalysisBaselineEnd
                                "UPDATE [BF_Registry] SET [KeyValue] = '-250'           WHERE [KeyClassGUID] = '3feda310-06cf-40d8-aa7f-8f08e6ca8592'; " + // RejectionEpochStart
                                "UPDATE [BF_Registry] SET [KeyValue] = '1800'           WHERE [KeyClassGUID] = '7dcf0c67-d0c6-4599-bd56-2dfc60136beb'; " + // RejectionEpochEnd
                                //"UPDATE [BF_Registry] SET [KeyValue] = '270'            WHERE [KeyClassGUID] = '2df0ac1b-28f3-42b5-9d37-d45e684cc39e'; " + // MERMERWindowStart
                                //"UPDATE [BF_Registry] SET [KeyValue] = '1000'           WHERE [KeyClassGUID] = '258a1a8f-0866-4192-a7d0-24fd9e069e4e'; " + // MERMERWindowEnd
                                "UPDATE [BF_Registry] SET [KeyValue] = 'Pz'             WHERE [KeyClassGUID] = '50477937-7d9c-4a15-baaf-fc144dfe1a61'; " + // AnalysisChannel
                                "UPDATE [BF_Registry] SET [KeyValue] = '70'             WHERE [KeyClassGUID] = '848360ac-f710-4518-a93c-fd05e9d25b97'; " + // MinimumNumberTrials
                                "UPDATE [BF_Registry] SET [KeyValue] = '5'              WHERE [KeyClassGUID] = '320861e9-547c-4c48-aecb-708797fbfadb'; " + // PreliminaryMinTrials
                                "UPDATE [BF_Registry] SET [KeyValue] = '90'             WHERE [KeyClassGUID] = '40eae0c1-07bb-445d-b48c-e462808236b3'; " + // InfoPresentCriterion
                                "UPDATE [BF_Registry] SET [KeyValue] = '70'             WHERE [KeyClassGUID] = '703fcf3d-6d1e-49a5-98bc-fc6543772098'; " + // InfoAbsentCriterion
                                "UPDATE [BF_Registry] SET [KeyValue] = '1000'            WHERE [KeyClassGUID] = 'fbfbfe97-f08b-4036-b29d-06b883c70005'; " + // BootstrappingIterations
                                "UPDATE [BF_Registry] SET [KeyValue] = 'VOTING'         WHERE [KeyClassGUID] = 'bbc19d13-5471-4f25-88b3-a36a34db8cdc'; " + // AnalysisMethod
                                "UPDATE [BF_Registry] SET [KeyValue] = 'filter-4.xml'   WHERE [KeyClassGUID] = 'e85020d0-bd83-49c6-9310-77495679900c'; " + // LowPassFilter
                                //"UPDATE [BF_Registry] SET [KeyValue] = '600'            WHERE [KeyClassGUID] = '7d5e160a-890e-4758-8948-d64d4b8a9ad8'; " + // MERMERStartPoint
                                "UPDATE [BF_Registry] SET [KeyValue] = '0'              WHERE [KeyClassGUID] = '638c181d-d25e-4a1f-acc4-0e30e2f4f46d'; " + // AnalysisGraphStart
                                "UPDATE [BF_Registry] SET [KeyValue] = '1800'           WHERE [KeyClassGUID] = '99dd1b5c-4a47-455d-b31c-e3d5895cc385' ";   // AnalysisGraphEnd
       
    }
}

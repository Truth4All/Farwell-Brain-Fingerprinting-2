﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Registry_Editor
{
    public partial class main : Form
    {
        public static string   connectionString;

        public main()
        {
            InitializeComponent();
            LoadDefaultValues();
        }

        private void LoadDefaultValues()
        {
            connectionString = "Data Source=(localdb)\\MSSQLLOCALDB;Initial Catalog=BrainwaveDB;Integrated Security=True";
            Database_Read DB = new Database_Read();

            //System Group
            this.CustomerName.Text = DB.CustomerName.ToString();
            this.GoogleKey.Text = DB.GoogleKey.ToString();

            // Capture Group
            this.DefaultSamplingRate.Text = DB.DefaultSamplingRate.ToString();
            this.HeadsetResolution.Text = DB.HeadsetResolution.ToString();
            this.DefaultPGAGain.Text = DB.DefaultPGAGain.ToString();
            this.TargetsRequired.Text = DB.TargetsRequired.ToString();
            this.ProbesRequired.Text = DB.ProbesRequired.ToString();
            this.IrrelevantsRequired.Text = DB.IrrelevantsRequired.ToString();
            this.ERPInterval.Text = DB.ERPInterval.ToString();
            this.FixationTime.Text = DB.FixationTime.ToString();
            this.TextExposureTime.Text = DB.TextExposureTime.ToString();
            this.ImageExposureTime.Text = DB.ImageExposureTime.ToString();
            this.EOGRange.Text = DB.EOGRange.ToString();
            this.EEGRange.Text = DB.EEGRange.ToString();
            this.CaptureDuration.Text = DB.CaptureDuration.ToString();
            this.DataPostStimulus.Text = DB.DataPostStimulus.ToString();
            this.ReactionTimeWindow.Text = DB.ReactionTimeWindow.ToString();

            //Headset Group
            this.HeadsetDevConnection.Text = DB.HeadsetDevConnection.ToString();
            this.Channels.Text = DB.Channels.ToString();

            //Tamper Protection
            this.UserLicencesMD5.Text = DB.UserLicencesMD5.ToString();
            this.TestLicensesMD5.Text = DB.TestLicensesMD5.ToString();
            this.MachineHardwareID.Text = DB.MachineHardwareID.ToString();

            //Analysis Group
            this.EEGRangeCriterion.Text = DB.EEGRangeCriterion.ToString();
            this.EOGRangeCriterion.Text = DB.EOGRangeCriterion.ToString();
            this.AnalysisEpochStart.Text = DB.AnalysisEpochStart.ToString();
            this.AnalysisEpochEnd.Text = DB.AnalysisEpochEnd.ToString();
            this.AnalysisBaselineStart.Text = DB.AnalysisBaselineStart.ToString();
            this.AnalysisBaselineEnd.Text = DB.AnalysisBaselineEnd.ToString();
            this.RejectionEpochStart.Text = DB.RejectionEpochStart.ToString();
            this.RejectionEpochEnd.Text = DB.RejectionEpochEnd.ToString();
            this.AnalysisChannel.Text = DB.AnalysisChannel.ToString();
            this.MinimumNumberTrials.Text = DB.MinimumNumberTrials.ToString();
            this.PreliminaryMinTrials.Text = DB.PreliminaryMinTrials.ToString();
            this.InfoPresentCriterion.Text = DB.InfoPresentCriterion.ToString();
            this.InfoAbsentCriterion.Text = DB.InfoAbsentCriterion.ToString();
            this.BootstrappingIterations.Text = DB.BootstrappingIterations.ToString();
            this.AnalysisMethod.Text = DB.AnalysisMethod.ToString();
            this.LowPassFilter.Text = DB.LowPassFilter.ToString();
            this.AnalysisGraphStart.Text = DB.AnalysisGraphStart.ToString();
            this.AnalysisGraphEnd.Text = DB.AnalysisGraphEnd.ToString();

            // Windows Registry group
            this.Language.Text               = (string)Registry.GetRegistryValue("LCID");
            this.btAddress.Text              = (string)Registry.GetRegistryValue("HeadSetMAC");
            this.Domain.Text                 = (string)Registry.GetRegistryValue("Domain");                 // Connected to domain
            this.RuntimeConfiguration.Text   = (string)Registry.GetRegistryValue("RunTimeConfiguration");   // Runtime Configuration
            this.RuntimeSecurity.Text        = (string)Registry.GetRegistryValue("RunTimeSecurity");        // Runtime Security
            this.RuntimeTarget.Text          = (string)Registry.GetRegistryValue("RunTimeTarget");          // Runtime Code Target
            this.IsDomainConnected.Checked   = Registry.GetBooleanRegistryValue("Connection");              //Connected to own domain
            this.IsInternetConnected.Checked = Registry.GetBooleanRegistryValue("Internet");                // Connected to Internet
        }


        private void Language_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("584d58a5-3f56-4a05-af01-f20cc307cf89", Language.Text);
        }

        private void CustomerName_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("0c03410a-fcdb-4b63-84a1-2b4bf02528e3", CustomerName.Text);
        }

        private void GoogleKey_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("cb55004b-24d2-4b25-9f85-ac37e7a2d013", GoogleKey.Text);
        }

        private void DefaultSamplingRate_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("53B4AE82-3E39-4CF0-9F6C-91519D0D7C23", DefaultSamplingRate.Text);
        }

        private void HeadsetResolution_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("6FB77766-63E4-4006-99FC-AC39EB8D4BDE", HeadsetResolution.Text);
        }

        private void DefaultPGAGain_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("6040EA13-077F-48D7-B040-727D5DB6BEF4", DefaultPGAGain.Text);
        }

        private void TargetsRequired_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("4312C1E2-AD6F-4BED-ADC9-6DBB7A11E6AA", TargetsRequired.Text);
        }

        private void ProbesRequired_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("66CB6DC0-F52F-4311-973F-A9C413F7B153", ProbesRequired.Text);
        }

        private void IrrelevantsRequired_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("B1EA48CF-20D3-4B0B-9F92-312F089BC1DE", IrrelevantsRequired.Text);
        }

        private void ERPInterval_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("FFEB82E1-382D-45D8-8B83-938D808502C1", ERPInterval.Text);
        }

        private void FixationTime_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("B80D9364-A51F-44F1-BF11-3FC73A85B2A0", FixationTime.Text);
        }

        private void TextExposureTime_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("64E4BF89-8CD1-403A-95CC-105E8456E492", TextExposureTime.Text);
        }

        private void ImageExposureTime_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("FBBA9379-E126-44BC-888D-D615923CC62B", ImageExposureTime.Text);
        }

        private void EOGRange_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("A993B010-7DF3-4C3E-BD70-571863566757", EOGRange.Text);
        }

        private void EEGRange_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("B4B65C80-4E59-405F-A544-2B91219F4CD4", EEGRange.Text);
        }

        private void CaptureDuration_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("1D2DD90E-C1B2-473B-9DAE-7757AA0D492E", CaptureDuration.Text);
        }

        private void DataPostStimulus_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("67F70DBE-E32E-4B68-909C-2F39DDFD0C41", DataPostStimulus.Text);
        }

        private void ReactionTimeWindow_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("6E3055AF-B371-4DF5-A0A7-40D1B016BAB0", ReactionTimeWindow.Text);
        }

        private void btAddress_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("E57B9D7A-9628-46F2-A356-AD904935D3C1", btAddress.Text);
        }

        private void HeadsetDevConnection_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("411411f8-9012-4942-8f44-3fb20145fda6", HeadsetDevConnection.Text);
        }

        private void Channels_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("C520E37E-74B6-4E1F-BA03-31B5D1176A10", Channels.Text);
        }

        private void UserLicencesMD5_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("d25ae539-6ac2-49fe-9a5e-e564a9174525", UserLicencesMD5.Text);
        }

        private void TestLicensesMD5_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("fb6d2cfc-5bbc-4968-ab3f-0cce3515fa89", TestLicensesMD5.Text);
        }

        private void MachineHardwareID_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("48ad3e28-88e9-4141-8df7-e2fba0b6cb05", MachineHardwareID.Text);
        }

        private void EEGRangeCriterion_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("6c173823-7318-491a-82c3-cb0895298d4b", EEGRangeCriterion.Text);
        }

        private void EOGRangeCriterion_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("d2c7a493-adea-4f8a-aa29-76f22625f94f", EOGRangeCriterion.Text);
        }

        private void AnalysisEpochStart_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("8258891b-2290-4030-a862-22d45a906e70", AnalysisEpochStart.Text);
        }

        private void AnalysisEpochEnd_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("f47d9dfb-ca51-4d25-a002-557dc3a286a8", AnalysisEpochEnd.Text);
        }

        private void AnalysisBaselineStart_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("fa7c0ac4-02db-4f38-9fb0-2fc06295f38e", AnalysisBaselineStart.Text);
        }

        private void AnalysisBaselineEnd_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("4b1b6e9b-badc-4f44-a774-97930b007adb", AnalysisBaselineEnd.Text);
        }

        private void RejectionEpochStart_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("3feda310-06cf-40d8-aa7f-8f08e6ca8592", RejectionEpochStart.Text);
        }

        private void RejectionEpochEnd_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("7dcf0c67-d0c6-4599-bd56-2dfc60136beb", RejectionEpochEnd.Text);
        }

        private void AnalysisChannel_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("50477937-7d9c-4a15-baaf-fc144dfe1a61", AnalysisChannel.Text);
        }

        private void MinimumNumberTrials_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("848360ac-f710-4518-a93c-fd05e9d25b97", MinimumNumberTrials.Text);
        }

        private void PreliminaryMinTrials_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("320861e9-547c-4c48-aecb-708797fbfadb", PreliminaryMinTrials.Text);
        }

        private void InfoPresentCriterion_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("40eae0c1-07bb-445d-b48c-e462808236b3", InfoPresentCriterion.Text);
        }

        private void InfoAbsentCriterion_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("703fcf3d-6d1e-49a5-98bc-fc6543772098", InfoAbsentCriterion.Text);
        }

        private void BootstrappingIterations_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("fbfbfe97-f08b-4036-b29d-06b883c70005", BootstrappingIterations.Text);
        }

        private void AnalysisMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("bbc19d13-5471-4f25-88b3-a36a34db8cdc", AnalysisMethod.Text);
        }

        private void AnalysisMethod_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("bbc19d13-5471-4f25-88b3-a36a34db8cdc", AnalysisMethod.Text);
        }

        private void LowPassFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("e85020d0-bd83-49c6-9310-77495679900c", LowPassFilter.Text);
        }

        private void AnalysisGraphStart_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("638c181d-d25e-4a1f-acc4-0e30e2f4f46d", AnalysisGraphStart.Text);
        }

        private void AnalysisGraphEnd_TextChanged(object sender, EventArgs e)
        {
            UpdateDBRegistryEntry("99dd1b5c-4a47-455d-b31c-e3d5895cc385", AnalysisGraphEnd.Text);
        }

        public static void UpdateDBRegistryEntry(string KeyClassGUID, string KeyValue)
        {
            SqlConnection spContentConn = new SqlConnection(connectionString);
            string sqlQuery = string.Format("UPDATE [BF_Registry] SET [KeyValue] = '{0}' WHERE [KeyClassGUID] = '{1}'", KeyValue, KeyClassGUID);
            try
            {
                spContentConn.Open();
                SqlCommand sqlCmd = new SqlCommand(sqlQuery, spContentConn);
                sqlCmd.CommandTimeout = 0;
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.ExecuteNonQuery();
                spContentConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (spContentConn != null)
                    spContentConn.Dispose();
            }
        }

    }
}
﻿namespace Registry_Editor
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.MachineHardwareID = new System.Windows.Forms.TextBox();
            this.TestLicensesMD5 = new System.Windows.Forms.TextBox();
            this.UserLicencesMD5 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label41 = new System.Windows.Forms.Label();
            this.PreliminaryMinTrials = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.FactoryReset = new System.Windows.Forms.Button();
            this.AnalysisMethod = new System.Windows.Forms.ComboBox();
            this.AnalysisGraphEnd = new System.Windows.Forms.TextBox();
            this.AnalysisGraphStart = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.AnalysisEpochEnd = new System.Windows.Forms.TextBox();
            this.AnalysisChannel = new System.Windows.Forms.ComboBox();
            this.LowPassFilter = new System.Windows.Forms.ComboBox();
            this.BootstrappingIterations = new System.Windows.Forms.TextBox();
            this.InfoAbsentCriterion = new System.Windows.Forms.TextBox();
            this.InfoPresentCriterion = new System.Windows.Forms.TextBox();
            this.MinimumNumberTrials = new System.Windows.Forms.TextBox();
            this.RejectionEpochEnd = new System.Windows.Forms.TextBox();
            this.RejectionEpochStart = new System.Windows.Forms.TextBox();
            this.AnalysisBaselineEnd = new System.Windows.Forms.TextBox();
            this.AnalysisBaselineStart = new System.Windows.Forms.TextBox();
            this.AnalysisEpochStart = new System.Windows.Forms.TextBox();
            this.EOGRangeCriterion = new System.Windows.Forms.TextBox();
            this.EEGRangeCriterion = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ReactionTimeWindow = new System.Windows.Forms.TextBox();
            this.DataPostStimulus = new System.Windows.Forms.TextBox();
            this.CaptureDuration = new System.Windows.Forms.TextBox();
            this.EEGRange = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.EOGRange = new System.Windows.Forms.TextBox();
            this.ImageExposureTime = new System.Windows.Forms.TextBox();
            this.TextExposureTime = new System.Windows.Forms.TextBox();
            this.FixationTime = new System.Windows.Forms.TextBox();
            this.ERPInterval = new System.Windows.Forms.TextBox();
            this.IrrelevantsRequired = new System.Windows.Forms.TextBox();
            this.ProbesRequired = new System.Windows.Forms.TextBox();
            this.TargetsRequired = new System.Windows.Forms.TextBox();
            this.DefaultPGAGain = new System.Windows.Forms.TextBox();
            this.HeadsetResolution = new System.Windows.Forms.TextBox();
            this.DefaultSamplingRate = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.GoogleKey = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.CustomerName = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Language = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btAddress = new System.Windows.Forms.TextBox();
            this.HeadsetDevConnection = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Channels = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.RuntimeTarget = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.RuntimeSecurity = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.RuntimeConfiguration = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.IsInternetConnected = new System.Windows.Forms.CheckBox();
            this.IsDomainConnected = new System.Windows.Forms.CheckBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.Domain = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.MachineHardwareID);
            this.groupBox1.Controls.Add(this.TestLicensesMD5);
            this.groupBox1.Controls.Add(this.UserLicencesMD5);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Location = new System.Drawing.Point(683, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 100);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tamper Protection";
            // 
            // MachineHardwareID
            // 
            this.MachineHardwareID.Location = new System.Drawing.Point(74, 65);
            this.MachineHardwareID.Name = "MachineHardwareID";
            this.MachineHardwareID.Size = new System.Drawing.Size(250, 20);
            this.MachineHardwareID.TabIndex = 43;
            this.MachineHardwareID.TextChanged += new System.EventHandler(this.MachineHardwareID_TextChanged);
            // 
            // TestLicensesMD5
            // 
            this.TestLicensesMD5.Location = new System.Drawing.Point(96, 39);
            this.TestLicensesMD5.Name = "TestLicensesMD5";
            this.TestLicensesMD5.Size = new System.Drawing.Size(228, 20);
            this.TestLicensesMD5.TabIndex = 42;
            this.TestLicensesMD5.TextChanged += new System.EventHandler(this.TestLicensesMD5_TextChanged);
            // 
            // UserLicencesMD5
            // 
            this.UserLicencesMD5.Location = new System.Drawing.Point(96, 13);
            this.UserLicencesMD5.Name = "UserLicencesMD5";
            this.UserLicencesMD5.Size = new System.Drawing.Size(228, 20);
            this.UserLicencesMD5.TabIndex = 41;
            this.UserLicencesMD5.TextChanged += new System.EventHandler(this.UserLicencesMD5_TextChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label42.Location = new System.Drawing.Point(6, 65);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(62, 13);
            this.label42.TabIndex = 40;
            this.label42.Text = "Machine ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(6, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Test Lic. MD5";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(6, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "User Lic. MD5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Current Language (LCID)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(6, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Default Sampling Rate (Hz)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(6, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Default PGA Gain";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(6, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Required # of Good Targets";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(6, 126);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Required # of Good Probes";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(6, 152);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Required # of Good Irrelevants";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(6, 230);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Text Stimulus Duration (mS)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(6, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(145, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Image Stimulus Duration (mS)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(6, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Heaset Resolution (bits)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(6, 282);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(130, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "EOG Max Range (µV P-P)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(6, 308);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(119, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Pz Max Range (µV P-P)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(6, 204);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(113, 13);
            this.label16.TabIndex = 19;
            this.label16.Text = "Fixation  Duration (mS)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.Location = new System.Drawing.Point(6, 178);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 13);
            this.label17.TabIndex = 20;
            this.label17.Text = "Stimulus Trial Interval (mS)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label18.Location = new System.Drawing.Point(6, 389);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(142, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "Reaction Time Window (mS)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(342, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 13);
            this.label19.TabIndex = 22;
            this.label19.Text = "Analysis Channel";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(342, 126);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(136, 13);
            this.label20.TabIndex = 23;
            this.label20.Text = "Information Absent Criterion";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label21.Location = new System.Drawing.Point(342, 74);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "Minimum # of Trials";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.PreliminaryMinTrials);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.FactoryReset);
            this.groupBox2.Controls.Add(this.AnalysisMethod);
            this.groupBox2.Controls.Add(this.AnalysisGraphEnd);
            this.groupBox2.Controls.Add(this.AnalysisGraphStart);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.AnalysisEpochEnd);
            this.groupBox2.Controls.Add(this.AnalysisChannel);
            this.groupBox2.Controls.Add(this.LowPassFilter);
            this.groupBox2.Controls.Add(this.BootstrappingIterations);
            this.groupBox2.Controls.Add(this.InfoAbsentCriterion);
            this.groupBox2.Controls.Add(this.InfoPresentCriterion);
            this.groupBox2.Controls.Add(this.MinimumNumberTrials);
            this.groupBox2.Controls.Add(this.RejectionEpochEnd);
            this.groupBox2.Controls.Add(this.RejectionEpochStart);
            this.groupBox2.Controls.Add(this.AnalysisBaselineEnd);
            this.groupBox2.Controls.Add(this.AnalysisBaselineStart);
            this.groupBox2.Controls.Add(this.AnalysisEpochStart);
            this.groupBox2.Controls.Add(this.EOGRangeCriterion);
            this.groupBox2.Controls.Add(this.EEGRangeCriterion);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Location = new System.Drawing.Point(348, 221);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(666, 417);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Analysis";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label41.Location = new System.Drawing.Point(342, 48);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(129, 13);
            this.label41.TabIndex = 78;
            this.label41.Text = "Preliminary Minimum Trials";
            // 
            // PreliminaryMinTrials
            // 
            this.PreliminaryMinTrials.Location = new System.Drawing.Point(510, 45);
            this.PreliminaryMinTrials.Name = "PreliminaryMinTrials";
            this.PreliminaryMinTrials.Size = new System.Drawing.Size(150, 20);
            this.PreliminaryMinTrials.TabIndex = 77;
            this.PreliminaryMinTrials.TextChanged += new System.EventHandler(this.PreliminaryMinTrials_TextChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 362);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(202, 13);
            this.label40.TabIndex = 76;
            this.label40.Text = "* Rejection Epoch is also used in Capture";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(147, 204);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(11, 13);
            this.label34.TabIndex = 75;
            this.label34.Text = "*";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(147, 178);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 13);
            this.label23.TabIndex = 74;
            this.label23.Text = "*";
            // 
            // FactoryReset
            // 
            this.FactoryReset.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FactoryReset.Location = new System.Drawing.Point(328, 384);
            this.FactoryReset.Name = "FactoryReset";
            this.FactoryReset.Size = new System.Drawing.Size(150, 23);
            this.FactoryReset.TabIndex = 73;
            this.FactoryReset.Text = "Reset to Factory";
            this.FactoryReset.UseVisualStyleBackColor = true;
            this.FactoryReset.Click += new System.EventHandler(this.FactoryReset_Click);
            // 
            // AnalysisMethod
            // 
            this.AnalysisMethod.FormattingEnabled = true;
            this.AnalysisMethod.Items.AddRange(new object[] {
            "DCGM",
            "DCUW",
            "PEARSON",
			"Comparison_CIT", //LF add a new analysis method: Comparison CIT
            "VOTING"});
            this.AnalysisMethod.Location = new System.Drawing.Point(510, 175);
            this.AnalysisMethod.Name = "AnalysisMethod";
            this.AnalysisMethod.Size = new System.Drawing.Size(150, 21);
            this.AnalysisMethod.TabIndex = 72;
            this.AnalysisMethod.SelectedIndexChanged += new System.EventHandler(this.AnalysisMethod_SelectedIndexChanged);
            // 
            // AnalysisGraphEnd
            // 
            this.AnalysisGraphEnd.Location = new System.Drawing.Point(510, 256);
            this.AnalysisGraphEnd.Name = "AnalysisGraphEnd";
            this.AnalysisGraphEnd.Size = new System.Drawing.Size(150, 20);
            this.AnalysisGraphEnd.TabIndex = 71;
            this.AnalysisGraphEnd.TextChanged += new System.EventHandler(this.AnalysisGraphEnd_TextChanged);
            // 
            // AnalysisGraphStart
            // 
            this.AnalysisGraphStart.Location = new System.Drawing.Point(510, 230);
            this.AnalysisGraphStart.Name = "AnalysisGraphStart";
            this.AnalysisGraphStart.Size = new System.Drawing.Size(150, 20);
            this.AnalysisGraphStart.TabIndex = 70;
            this.AnalysisGraphStart.TextChanged += new System.EventHandler(this.AnalysisGraphStart_TextChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label46.Location = new System.Drawing.Point(342, 259);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(123, 13);
            this.label46.TabIndex = 67;
            this.label46.Text = "Analysis Graph End (mS)";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label44.Location = new System.Drawing.Point(342, 233);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(126, 13);
            this.label44.TabIndex = 66;
            this.label44.Text = "Analysis Graph Start (mS)";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 389);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(292, 13);
            this.label45.TabIndex = 65;
            this.label45.Text = "Start and End time are referenced from beginning of Stimulus";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(510, 384);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 22);
            this.button1.TabIndex = 63;
            this.button1.Text = "Apply";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label43.Location = new System.Drawing.Point(6, 100);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(125, 13);
            this.label43.TabIndex = 62;
            this.label43.Text = "Analysis Epoch End (mS)";
            // 
            // AnalysisEpochEnd
            // 
            this.AnalysisEpochEnd.Location = new System.Drawing.Point(174, 97);
            this.AnalysisEpochEnd.Name = "AnalysisEpochEnd";
            this.AnalysisEpochEnd.Size = new System.Drawing.Size(150, 20);
            this.AnalysisEpochEnd.TabIndex = 61;
            this.AnalysisEpochEnd.TextChanged += new System.EventHandler(this.AnalysisEpochEnd_TextChanged);
            // 
            // AnalysisChannel
            // 
            this.AnalysisChannel.FormattingEnabled = true;
            this.AnalysisChannel.Items.AddRange(new object[] {
            "Pz",
            "EOG"});
            this.AnalysisChannel.Location = new System.Drawing.Point(510, 18);
            this.AnalysisChannel.Name = "AnalysisChannel";
            this.AnalysisChannel.Size = new System.Drawing.Size(150, 21);
            this.AnalysisChannel.TabIndex = 60;
            this.AnalysisChannel.SelectedIndexChanged += new System.EventHandler(this.AnalysisChannel_SelectedIndexChanged);
            // 
            // LowPassFilter
            // 
            this.LowPassFilter.FormattingEnabled = true;
            this.LowPassFilter.Items.AddRange(new object[] {
            "filter-4.xml",
            "filter-6.xml"});
            this.LowPassFilter.Location = new System.Drawing.Point(510, 202);
            this.LowPassFilter.Name = "LowPassFilter";
            this.LowPassFilter.Size = new System.Drawing.Size(150, 21);
            this.LowPassFilter.TabIndex = 59;
            this.LowPassFilter.SelectedIndexChanged += new System.EventHandler(this.LowPassFilter_SelectedIndexChanged);
            // 
            // BootstrappingIterations
            // 
            this.BootstrappingIterations.Location = new System.Drawing.Point(510, 149);
            this.BootstrappingIterations.Name = "BootstrappingIterations";
            this.BootstrappingIterations.Size = new System.Drawing.Size(150, 20);
            this.BootstrappingIterations.TabIndex = 55;
            this.BootstrappingIterations.TextChanged += new System.EventHandler(this.BootstrappingIterations_TextChanged);
            // 
            // InfoAbsentCriterion
            // 
            this.InfoAbsentCriterion.Location = new System.Drawing.Point(510, 123);
            this.InfoAbsentCriterion.Name = "InfoAbsentCriterion";
            this.InfoAbsentCriterion.Size = new System.Drawing.Size(150, 20);
            this.InfoAbsentCriterion.TabIndex = 54;
            this.InfoAbsentCriterion.TextChanged += new System.EventHandler(this.InfoAbsentCriterion_TextChanged);
            // 
            // InfoPresentCriterion
            // 
            this.InfoPresentCriterion.Location = new System.Drawing.Point(510, 97);
            this.InfoPresentCriterion.Name = "InfoPresentCriterion";
            this.InfoPresentCriterion.Size = new System.Drawing.Size(150, 20);
            this.InfoPresentCriterion.TabIndex = 53;
            this.InfoPresentCriterion.TextChanged += new System.EventHandler(this.InfoPresentCriterion_TextChanged);
            // 
            // MinimumNumberTrials
            // 
            this.MinimumNumberTrials.Location = new System.Drawing.Point(510, 71);
            this.MinimumNumberTrials.Name = "MinimumNumberTrials";
            this.MinimumNumberTrials.Size = new System.Drawing.Size(150, 20);
            this.MinimumNumberTrials.TabIndex = 52;
            this.MinimumNumberTrials.TextChanged += new System.EventHandler(this.MinimumNumberTrials_TextChanged);
            // 
            // RejectionEpochEnd
            // 
            this.RejectionEpochEnd.Location = new System.Drawing.Point(174, 201);
            this.RejectionEpochEnd.Name = "RejectionEpochEnd";
            this.RejectionEpochEnd.Size = new System.Drawing.Size(150, 20);
            this.RejectionEpochEnd.TabIndex = 48;
            this.RejectionEpochEnd.TextChanged += new System.EventHandler(this.RejectionEpochEnd_TextChanged);
            // 
            // RejectionEpochStart
            // 
            this.RejectionEpochStart.Location = new System.Drawing.Point(174, 175);
            this.RejectionEpochStart.Name = "RejectionEpochStart";
            this.RejectionEpochStart.Size = new System.Drawing.Size(150, 20);
            this.RejectionEpochStart.TabIndex = 47;
            this.RejectionEpochStart.TextChanged += new System.EventHandler(this.RejectionEpochStart_TextChanged);
            // 
            // AnalysisBaselineEnd
            // 
            this.AnalysisBaselineEnd.Location = new System.Drawing.Point(174, 149);
            this.AnalysisBaselineEnd.Name = "AnalysisBaselineEnd";
            this.AnalysisBaselineEnd.Size = new System.Drawing.Size(150, 20);
            this.AnalysisBaselineEnd.TabIndex = 46;
            this.AnalysisBaselineEnd.TextChanged += new System.EventHandler(this.AnalysisBaselineEnd_TextChanged);
            // 
            // AnalysisBaselineStart
            // 
            this.AnalysisBaselineStart.Location = new System.Drawing.Point(174, 123);
            this.AnalysisBaselineStart.Name = "AnalysisBaselineStart";
            this.AnalysisBaselineStart.Size = new System.Drawing.Size(150, 20);
            this.AnalysisBaselineStart.TabIndex = 45;
            this.AnalysisBaselineStart.TextChanged += new System.EventHandler(this.AnalysisBaselineStart_TextChanged);
            // 
            // AnalysisEpochStart
            // 
            this.AnalysisEpochStart.Location = new System.Drawing.Point(174, 71);
            this.AnalysisEpochStart.Name = "AnalysisEpochStart";
            this.AnalysisEpochStart.Size = new System.Drawing.Size(150, 20);
            this.AnalysisEpochStart.TabIndex = 44;
            this.AnalysisEpochStart.TextChanged += new System.EventHandler(this.AnalysisEpochStart_TextChanged);
            // 
            // EOGRangeCriterion
            // 
            this.EOGRangeCriterion.Location = new System.Drawing.Point(174, 45);
            this.EOGRangeCriterion.Name = "EOGRangeCriterion";
            this.EOGRangeCriterion.Size = new System.Drawing.Size(150, 20);
            this.EOGRangeCriterion.TabIndex = 41;
            this.EOGRangeCriterion.TextChanged += new System.EventHandler(this.EOGRangeCriterion_TextChanged);
            // 
            // EEGRangeCriterion
            // 
            this.EEGRangeCriterion.Location = new System.Drawing.Point(174, 19);
            this.EEGRangeCriterion.Name = "EEGRangeCriterion";
            this.EEGRangeCriterion.Size = new System.Drawing.Size(150, 20);
            this.EEGRangeCriterion.TabIndex = 40;
            this.EEGRangeCriterion.TextChanged += new System.EventHandler(this.EEGRangeCriterion_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(6, 48);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(128, 13);
            this.label25.TabIndex = 29;
            this.label25.Text = "EOG Range Criterion (µV)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label33.Location = new System.Drawing.Point(342, 178);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(84, 13);
            this.label33.TabIndex = 31;
            this.label33.Text = "Analysis Method";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label35.Location = new System.Drawing.Point(342, 205);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(78, 13);
            this.label35.TabIndex = 33;
            this.label35.Text = "Low-Pass Filter";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(6, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(127, 13);
            this.label24.TabIndex = 27;
            this.label24.Text = "EEG Range Criterion (µV)";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label39.Location = new System.Drawing.Point(6, 204);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(132, 13);
            this.label39.TabIndex = 37;
            this.label39.Text = "Rejection Epoch End (mS)";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label38.Location = new System.Drawing.Point(6, 178);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(135, 13);
            this.label38.TabIndex = 36;
            this.label38.Text = "Rejection Epoch Start (mS)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label36.Location = new System.Drawing.Point(342, 152);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(118, 13);
            this.label36.TabIndex = 34;
            this.label36.Text = "Bootstrapping Iterations";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label37.Location = new System.Drawing.Point(6, 74);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(128, 13);
            this.label37.TabIndex = 35;
            this.label37.Text = "Analysis Epoch Start (mS)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(342, 100);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(139, 13);
            this.label22.TabIndex = 27;
            this.label22.Text = "Information Present Criterion";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label31.Location = new System.Drawing.Point(6, 152);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(134, 13);
            this.label31.TabIndex = 29;
            this.label31.Text = "Analysis Baseline End (mS)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label32.Location = new System.Drawing.Point(6, 126);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(137, 13);
            this.label32.TabIndex = 30;
            this.label32.Text = "Analysis Baseline Start (mS)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ReactionTimeWindow);
            this.groupBox3.Controls.Add(this.DataPostStimulus);
            this.groupBox3.Controls.Add(this.CaptureDuration);
            this.groupBox3.Controls.Add(this.EEGRange);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.EOGRange);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.ImageExposureTime);
            this.groupBox3.Controls.Add(this.TextExposureTime);
            this.groupBox3.Controls.Add(this.FixationTime);
            this.groupBox3.Controls.Add(this.ERPInterval);
            this.groupBox3.Controls.Add(this.IrrelevantsRequired);
            this.groupBox3.Controls.Add(this.ProbesRequired);
            this.groupBox3.Controls.Add(this.TargetsRequired);
            this.groupBox3.Controls.Add(this.DefaultPGAGain);
            this.groupBox3.Controls.Add(this.HeadsetResolution);
            this.groupBox3.Controls.Add(this.DefaultSamplingRate);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox3.Location = new System.Drawing.Point(12, 221);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(330, 407);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Capture";
            // 
            // ReactionTimeWindow
            // 
            this.ReactionTimeWindow.Location = new System.Drawing.Point(174, 386);
            this.ReactionTimeWindow.Name = "ReactionTimeWindow";
            this.ReactionTimeWindow.Size = new System.Drawing.Size(150, 20);
            this.ReactionTimeWindow.TabIndex = 38;
            this.ReactionTimeWindow.TextChanged += new System.EventHandler(this.ReactionTimeWindow_TextChanged);
            // 
            // DataPostStimulus
            // 
            this.DataPostStimulus.Location = new System.Drawing.Point(174, 359);
            this.DataPostStimulus.Name = "DataPostStimulus";
            this.DataPostStimulus.Size = new System.Drawing.Size(150, 20);
            this.DataPostStimulus.TabIndex = 37;
            this.DataPostStimulus.TextChanged += new System.EventHandler(this.DataPostStimulus_TextChanged);
            // 
            // CaptureDuration
            // 
            this.CaptureDuration.Location = new System.Drawing.Point(174, 332);
            this.CaptureDuration.Name = "CaptureDuration";
            this.CaptureDuration.Size = new System.Drawing.Size(150, 20);
            this.CaptureDuration.TabIndex = 36;
            this.CaptureDuration.TextChanged += new System.EventHandler(this.CaptureDuration_TextChanged);
            // 
            // EEGRange
            // 
            this.EEGRange.Location = new System.Drawing.Point(174, 305);
            this.EEGRange.Name = "EEGRange";
            this.EEGRange.Size = new System.Drawing.Size(150, 20);
            this.EEGRange.TabIndex = 35;
            this.EEGRange.TextChanged += new System.EventHandler(this.EEGRange_TextChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(6, 335);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(162, 13);
            this.label30.TabIndex = 34;
            this.label30.Text = "EEG Data Capture Duration (mS)";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label28.Location = new System.Drawing.Point(6, 362);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 13);
            this.label28.TabIndex = 33;
            this.label28.Text = "Data Post Stimulus (mS)";
            // 
            // EOGRange
            // 
            this.EOGRange.Location = new System.Drawing.Point(174, 279);
            this.EOGRange.Name = "EOGRange";
            this.EOGRange.Size = new System.Drawing.Size(150, 20);
            this.EOGRange.TabIndex = 32;
            this.EOGRange.TextChanged += new System.EventHandler(this.EOGRange_TextChanged);
            // 
            // ImageExposureTime
            // 
            this.ImageExposureTime.Location = new System.Drawing.Point(174, 253);
            this.ImageExposureTime.Name = "ImageExposureTime";
            this.ImageExposureTime.Size = new System.Drawing.Size(150, 20);
            this.ImageExposureTime.TabIndex = 31;
            this.ImageExposureTime.TextChanged += new System.EventHandler(this.ImageExposureTime_TextChanged);
            // 
            // TextExposureTime
            // 
            this.TextExposureTime.Location = new System.Drawing.Point(174, 227);
            this.TextExposureTime.Name = "TextExposureTime";
            this.TextExposureTime.Size = new System.Drawing.Size(150, 20);
            this.TextExposureTime.TabIndex = 30;
            this.TextExposureTime.TextChanged += new System.EventHandler(this.TextExposureTime_TextChanged);
            // 
            // FixationTime
            // 
            this.FixationTime.Location = new System.Drawing.Point(174, 201);
            this.FixationTime.Name = "FixationTime";
            this.FixationTime.Size = new System.Drawing.Size(150, 20);
            this.FixationTime.TabIndex = 29;
            this.FixationTime.TextChanged += new System.EventHandler(this.FixationTime_TextChanged);
            // 
            // ERPInterval
            // 
            this.ERPInterval.Location = new System.Drawing.Point(174, 175);
            this.ERPInterval.Name = "ERPInterval";
            this.ERPInterval.Size = new System.Drawing.Size(150, 20);
            this.ERPInterval.TabIndex = 28;
            this.ERPInterval.TextChanged += new System.EventHandler(this.ERPInterval_TextChanged);
            // 
            // IrrelevantsRequired
            // 
            this.IrrelevantsRequired.Location = new System.Drawing.Point(174, 149);
            this.IrrelevantsRequired.Name = "IrrelevantsRequired";
            this.IrrelevantsRequired.Size = new System.Drawing.Size(150, 20);
            this.IrrelevantsRequired.TabIndex = 27;
            this.IrrelevantsRequired.TextChanged += new System.EventHandler(this.IrrelevantsRequired_TextChanged);
            // 
            // ProbesRequired
            // 
            this.ProbesRequired.Location = new System.Drawing.Point(174, 123);
            this.ProbesRequired.Name = "ProbesRequired";
            this.ProbesRequired.Size = new System.Drawing.Size(150, 20);
            this.ProbesRequired.TabIndex = 26;
            this.ProbesRequired.TextChanged += new System.EventHandler(this.ProbesRequired_TextChanged);
            // 
            // TargetsRequired
            // 
            this.TargetsRequired.Location = new System.Drawing.Point(174, 97);
            this.TargetsRequired.Name = "TargetsRequired";
            this.TargetsRequired.Size = new System.Drawing.Size(150, 20);
            this.TargetsRequired.TabIndex = 25;
            this.TargetsRequired.TextChanged += new System.EventHandler(this.TargetsRequired_TextChanged);
            // 
            // DefaultPGAGain
            // 
            this.DefaultPGAGain.Location = new System.Drawing.Point(174, 71);
            this.DefaultPGAGain.Name = "DefaultPGAGain";
            this.DefaultPGAGain.Size = new System.Drawing.Size(150, 20);
            this.DefaultPGAGain.TabIndex = 24;
            this.DefaultPGAGain.TextChanged += new System.EventHandler(this.DefaultPGAGain_TextChanged);
            // 
            // HeadsetResolution
            // 
            this.HeadsetResolution.Location = new System.Drawing.Point(174, 45);
            this.HeadsetResolution.Name = "HeadsetResolution";
            this.HeadsetResolution.Size = new System.Drawing.Size(150, 20);
            this.HeadsetResolution.TabIndex = 23;
            this.HeadsetResolution.TextChanged += new System.EventHandler(this.HeadsetResolution_TextChanged);
            // 
            // DefaultSamplingRate
            // 
            this.DefaultSamplingRate.Location = new System.Drawing.Point(174, 19);
            this.DefaultSamplingRate.Name = "DefaultSamplingRate";
            this.DefaultSamplingRate.Size = new System.Drawing.Size(150, 20);
            this.DefaultSamplingRate.TabIndex = 22;
            this.DefaultSamplingRate.TextChanged += new System.EventHandler(this.DefaultSamplingRate_TextChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.GoogleKey);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.CustomerName);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.Language);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox5.Location = new System.Drawing.Point(12, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(330, 100);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "System";
            // 
            // GoogleKey
            // 
            this.GoogleKey.Location = new System.Drawing.Point(174, 65);
            this.GoogleKey.Name = "GoogleKey";
            this.GoogleKey.Size = new System.Drawing.Size(150, 20);
            this.GoogleKey.TabIndex = 8;
            this.GoogleKey.TextChanged += new System.EventHandler(this.GoogleKey_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label27.Location = new System.Drawing.Point(6, 68);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(62, 13);
            this.label27.TabIndex = 7;
            this.label27.Text = "Google Key";
            // 
            // CustomerName
            // 
            this.CustomerName.Location = new System.Drawing.Point(174, 39);
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.Size = new System.Drawing.Size(150, 20);
            this.CustomerName.TabIndex = 6;
            this.CustomerName.TextChanged += new System.EventHandler(this.CustomerName_TextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(6, 42);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(82, 13);
            this.label26.TabIndex = 5;
            this.label26.Text = "Customer Name";
            // 
            // Language
            // 
            this.Language.Location = new System.Drawing.Point(174, 13);
            this.Language.Name = "Language";
            this.Language.Size = new System.Drawing.Size(150, 20);
            this.Language.TabIndex = 4;
            this.Language.TextChanged += new System.EventHandler(this.Language_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(6, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Headset Device Connection";
            // 
            // btAddress
            // 
            this.btAddress.Location = new System.Drawing.Point(174, 13);
            this.btAddress.Name = "btAddress";
            this.btAddress.Size = new System.Drawing.Size(150, 20);
            this.btAddress.TabIndex = 10;
            this.btAddress.TextChanged += new System.EventHandler(this.btAddress_TextChanged);
            // 
            // HeadsetDevConnection
            // 
            this.HeadsetDevConnection.Location = new System.Drawing.Point(174, 39);
            this.HeadsetDevConnection.Name = "HeadsetDevConnection";
            this.HeadsetDevConnection.Size = new System.Drawing.Size(150, 20);
            this.HeadsetDevConnection.TabIndex = 11;
            this.HeadsetDevConnection.TextChanged += new System.EventHandler(this.HeadsetDevConnection_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Headset MAC Address";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Channels);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.HeadsetDevConnection);
            this.groupBox4.Controls.Add(this.btAddress);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox4.Location = new System.Drawing.Point(347, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(330, 100);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Headset";
            // 
            // Channels
            // 
            this.Channels.Location = new System.Drawing.Point(174, 65);
            this.Channels.Name = "Channels";
            this.Channels.Size = new System.Drawing.Size(150, 20);
            this.Channels.TabIndex = 13;
            this.Channels.TextChanged += new System.EventHandler(this.Channels_TextChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label29.Location = new System.Drawing.Point(6, 65);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(116, 13);
            this.label29.TabIndex = 12;
            this.label29.Text = "Headset # of Channels";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.RuntimeTarget);
            this.groupBox6.Controls.Add(this.label49);
            this.groupBox6.Controls.Add(this.label48);
            this.groupBox6.Controls.Add(this.RuntimeSecurity);
            this.groupBox6.Controls.Add(this.label47);
            this.groupBox6.Controls.Add(this.RuntimeConfiguration);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox6.Location = new System.Drawing.Point(12, 118);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(330, 97);
            this.groupBox6.TabIndex = 29;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Configuration";
            // 
            // RuntimeTarget
            // 
            this.RuntimeTarget.Location = new System.Drawing.Point(174, 65);
            this.RuntimeTarget.Name = "RuntimeTarget";
            this.RuntimeTarget.Size = new System.Drawing.Size(150, 20);
            this.RuntimeTarget.TabIndex = 5;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label49.Location = new System.Drawing.Point(6, 68);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(108, 13);
            this.label49.TabIndex = 4;
            this.label49.Text = "Runtime Code Target";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label48.Location = new System.Drawing.Point(6, 42);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(87, 13);
            this.label48.TabIndex = 3;
            this.label48.Text = "Runtime Security";
            // 
            // RuntimeSecurity
            // 
            this.RuntimeSecurity.Location = new System.Drawing.Point(174, 39);
            this.RuntimeSecurity.Name = "RuntimeSecurity";
            this.RuntimeSecurity.Size = new System.Drawing.Size(150, 20);
            this.RuntimeSecurity.TabIndex = 2;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label47.Location = new System.Drawing.Point(6, 16);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(111, 13);
            this.label47.TabIndex = 1;
            this.label47.Text = "Runtime Configuration";
            // 
            // RuntimeConfiguration
            // 
            this.RuntimeConfiguration.Location = new System.Drawing.Point(174, 13);
            this.RuntimeConfiguration.Name = "RuntimeConfiguration";
            this.RuntimeConfiguration.Size = new System.Drawing.Size(150, 20);
            this.RuntimeConfiguration.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.IsInternetConnected);
            this.groupBox7.Controls.Add(this.IsDomainConnected);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.Domain);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox7.Location = new System.Drawing.Point(347, 118);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(330, 97);
            this.groupBox7.TabIndex = 30;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Environment";
            // 
            // IsInternetConnected
            // 
            this.IsInternetConnected.AutoSize = true;
            this.IsInternetConnected.Location = new System.Drawing.Point(174, 62);
            this.IsInternetConnected.Name = "IsInternetConnected";
            this.IsInternetConnected.Size = new System.Drawing.Size(138, 17);
            this.IsInternetConnected.TabIndex = 5;
            this.IsInternetConnected.Text = "Is connected to internet";
            this.IsInternetConnected.UseVisualStyleBackColor = true;
            // 
            // IsDomainConnected
            // 
            this.IsDomainConnected.AutoSize = true;
            this.IsDomainConnected.Location = new System.Drawing.Point(174, 39);
            this.IsDomainConnected.Name = "IsDomainConnected";
            this.IsDomainConnected.Size = new System.Drawing.Size(137, 17);
            this.IsDomainConnected.TabIndex = 4;
            this.IsDomainConnected.Text = "Is connected to domain";
            this.IsDomainConnected.UseVisualStyleBackColor = true;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label52.Location = new System.Drawing.Point(6, 68);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(100, 13);
            this.label52.TabIndex = 3;
            this.label52.Text = "Internet Connection";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label51.Location = new System.Drawing.Point(6, 42);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(100, 13);
            this.label51.TabIndex = 2;
            this.label51.Text = "Domain Connection";
            // 
            // Domain
            // 
            this.Domain.Location = new System.Drawing.Point(174, 13);
            this.Domain.Name = "Domain";
            this.Domain.Size = new System.Drawing.Size(150, 20);
            this.Domain.TabIndex = 1;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label50.Location = new System.Drawing.Point(6, 16);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(43, 13);
            this.label50.TabIndex = 0;
            this.label50.Text = "Domain";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 648);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Name = "main";
            this.Text = "Registry Editor (Version 2.1)";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox EOGRange;
        private System.Windows.Forms.TextBox ImageExposureTime;
        private System.Windows.Forms.TextBox TextExposureTime;
        private System.Windows.Forms.TextBox FixationTime;
        private System.Windows.Forms.TextBox ERPInterval;
        private System.Windows.Forms.TextBox IrrelevantsRequired;
        private System.Windows.Forms.TextBox ProbesRequired;
        private System.Windows.Forms.TextBox TargetsRequired;
        private System.Windows.Forms.TextBox DefaultPGAGain;
        private System.Windows.Forms.TextBox HeadsetResolution;
        private System.Windows.Forms.TextBox DefaultSamplingRate;
        private System.Windows.Forms.TextBox Language;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox GoogleKey;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox CustomerName;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox BootstrappingIterations;
        private System.Windows.Forms.TextBox InfoAbsentCriterion;
        private System.Windows.Forms.TextBox InfoPresentCriterion;
        private System.Windows.Forms.TextBox MinimumNumberTrials;
        private System.Windows.Forms.TextBox RejectionEpochEnd;
        private System.Windows.Forms.TextBox RejectionEpochStart;
        private System.Windows.Forms.TextBox AnalysisBaselineEnd;
        private System.Windows.Forms.TextBox AnalysisBaselineStart;
        private System.Windows.Forms.TextBox AnalysisEpochStart;
        private System.Windows.Forms.TextBox EOGRangeCriterion;
        private System.Windows.Forms.TextBox EEGRangeCriterion;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox ReactionTimeWindow;
        private System.Windows.Forms.TextBox DataPostStimulus;
        private System.Windows.Forms.TextBox CaptureDuration;
        private System.Windows.Forms.TextBox EEGRange;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox btAddress;
        private System.Windows.Forms.TextBox HeadsetDevConnection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox Channels;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox MachineHardwareID;
        private System.Windows.Forms.TextBox TestLicensesMD5;
        private System.Windows.Forms.TextBox UserLicencesMD5;
        private System.Windows.Forms.ComboBox LowPassFilter;
        private System.Windows.Forms.ComboBox AnalysisChannel;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox AnalysisEpochEnd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox AnalysisGraphEnd;
        private System.Windows.Forms.TextBox AnalysisGraphStart;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox AnalysisMethod;
        private System.Windows.Forms.Button FactoryReset;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox PreliminaryMinTrials;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox RuntimeConfiguration;
        private System.Windows.Forms.TextBox RuntimeTarget;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox RuntimeSecurity;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox IsInternetConnected;
        private System.Windows.Forms.CheckBox IsDomainConnected;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox Domain;
        private System.Windows.Forms.Label label50;
    }
}


﻿using System.Windows.Controls;

namespace Brainwave.UserManagementShell.Controls
{
    /// <summary>
    /// Interaction logic for RoundedBox.xaml
    /// </summary>
    public partial class RoundedBox : UserControl
    {
        public RoundedBox()
        {
            InitializeComponent();
        }
    }
}

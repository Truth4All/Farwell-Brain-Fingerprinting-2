﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace Brainwave.UserManagementShell.Controls
{
    public class AnimatedContentControl:ContentControl
    {
        //public static readonly RoutedEvent IsLoadedEvent = EventManager.RegisterRoutedEvent(
        //  "IsLoading", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(AnimatedContentControl));
  
        //public event RoutedEventHandler IsLoading
        //{
        //    add { AddHandler(IsLoadedEvent, value); }
        //    remove { RemoveHandler(IsLoadedEvent, value); }
        //}

        

        //// This method raises the Tap event
        //private void RaiseIsLoadedEvent()
        //{
        //    var args = new RoutedEventArgs(IsLoadedEvent);
        //    RaiseEvent(args);
        //}

        //protected override void OnContentChanged(object oldContentTemplate, object newContentTemplate)
        //{
        //    this.RaiseIsLoadedEvent();

        //    base.OnContentChanged(oldContentTemplate, newContentTemplate);
        //}
    }
}

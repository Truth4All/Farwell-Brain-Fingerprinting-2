﻿using Brainwave.Business;
using Brainwave.Entities;
using Brainwave.Infrastructure;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.UnityExtensions;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Windows;

namespace Brainwave.UserManagementShell
{
    public class UM_BFPBootStrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            return ServiceLocator.Current.GetInstance<UM_Shell>();
        }

        /// <summary>
        /// Initializes the shell.
        /// </summary>
        protected override void InitializeShell()
        {
            UM_App.Current.MainWindow = (Window)this.Shell;
            SetUserDefaultLanguage();
            UM_App.Current.MainWindow.Show();
        }

        protected override void ConfigureModuleCatalog()
        {
            ModuleCatalog moduleCatalog = (ModuleCatalog)this.ModuleCatalog;
            LanguageAssetBusiness.LoadAllLabelsAndLookUps();
            moduleCatalog.AddModule(typeof(Brainwave.UserManagement.UserManagementModule));
        }

        private void SetUserDefaultLanguage()
        {
            LanguageAssetBusiness objLanguageAssetBusiness = new LanguageAssetBusiness();
            LanguageEntity languageEntity = objLanguageAssetBusiness.GetLanguageInfo(GlobalVariables.CurrentLCID);
            ResourceDictionary newXaml = new ResourceDictionary();
            ResourceDictionary tabXaml = new ResourceDictionary();
            tabXaml.Source = new Uri(@"../Resources/TabItemResource.xaml", UriKind.Relative);
            System.Windows.Application.Current.Resources.MergedDictionaries.Clear();
            System.Windows.Application.Current.Resources.MergedDictionaries.Add(tabXaml);
            if (string.IsNullOrEmpty(languageEntity.Style))
            {
                newXaml.Source = new Uri(@"../Resources/Styles_en-US.xaml", UriKind.Relative);
                System.Windows.Application.Current.Resources.MergedDictionaries.Add(newXaml);
            }
            else
            {
                newXaml.Source = new Uri(@"../Resources/" + languageEntity.Style, UriKind.Relative);
                System.Windows.Application.Current.Resources.MergedDictionaries.Add(newXaml);
            }
            if (languageEntity.Direction == "RTL")
            {
                UM_App.Current.MainWindow.FlowDirection = FlowDirection.RightToLeft;
            }
            else
            {
                UM_App.Current.MainWindow.FlowDirection = FlowDirection.LeftToRight;
            }
        }

    }
}

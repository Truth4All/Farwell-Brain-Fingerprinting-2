﻿using Brainwave.Business;
using Brainwave.Entities;
using Brainwave.Helper;
using Brainwave.Infrastructure;
using Brainwave.UserManagement.View;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Unity;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;

namespace Brainwave.UserManagementShell
{
    public class ShellViewModel : ViewModelBase
    {
        private IRegionManager regionManager;
        private IEventAggregator eventAggregator;
        private IUnityContainer container;
        private ObservableCollection<ParentMenu> _menuItems;

        #region Common

        private void ClearAll()
        {
            ClearMainRegion();
          //  ClearActionRegion();
            ClearResearchRegion();
        }

        private void ClearMainRegion()
        {
            try
            {
                IRegion region1 = this.regionManager.Regions[RegionNames.MainRegion];
                IViewsCollection ActionViews = region1.Views;

                foreach (object obj in ActionViews)
                {
                    region1.Remove(obj);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void ClearActionRegion()
        //{
        //    try
        //    {
        //        IRegion region1 = this.regionManager.Regions[RegionNames.ActionRegion];
        //        IViewsCollection ActionViews = region1.Views;

        //        foreach (object obj in ActionViews)
        //        {
        //            region1.Remove(obj);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        private void ClearResearchRegion()
        {
            try
            {
                IRegion region1 = this.regionManager.Regions[RegionNames.ResearchRegion];
                IViewsCollection ResearchViews = region1.Views;

                foreach (object obj in ResearchViews)
                {
                    region1.Remove(obj);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region User Management

        private void ShowUserManagementSetUpManager()
        {
            try
            {
                ClearAll();
                IRegion region = regionManager.Regions[RegionNames.MainRegion];
                var view = container.Resolve<UserManagementView>();
                region.Add(view, "UserManagementView");
                RegionExtensions.Show(region, "UserManagementView");

                if (region != null)
                {
                    region.Activate(view);
                }
            }
            catch (Exception ex)
            {
                string logMsg = string.Format("Error occurred while showing the User Management screen -{0} ", ex.Message + ex.StackTrace );
                Business.EventLogging.BrainwaveLogEvent(EventSource.Main, logMsg, 2124, EventLogEntryType.Error);
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        public ShellViewModel(IRegionManager regionManager, IEventAggregator eventAggregator, IUnityContainer container)
        {
            this.regionManager = regionManager;
            this.eventAggregator = eventAggregator;
            this.container = container;

        }

      

    }

    public class ParentMenu : ViewModelBase
    {
        private ObservableCollection<ParentMenu> _items;
        public string Header { get; set; }
        private ICommand _command;
        private bool _isEnabled = true;

        public string CommandParameter { get; set; }

        public bool IsEnabled
        {
            get { return _isEnabled; }
            set
            {
                _isEnabled = value;
                OnPropertyChanged("IsEnabled");
            }
        }

        public ICommand Command
        {
            get
            {
                return (_command = _command ??
                                   new DelegateCommand<string>(OnMenuItemClick, (x) => IsEnabled));
            }
        }

        public ObservableCollection<ParentMenu> Items
        {
            get
            {
                return (_items = _items ??
                                 new ObservableCollection<ParentMenu>());
            }
        }

        public bool HasChildren
        {
            get { return Items.Count > 0; }
        }

        public event FileMenuHandler FileMenuClick;

        public virtual void OnFileMenuClick(object sender, FileMenuEventArgs args)
        {
            if (FileMenuClick != null)
            {
                FileMenuClick(sender, args);
            }
        }

        public virtual void OnMenuItemClick(string parameter)
        {
            OnFileMenuClick(this, new FileMenuEventArgs
            {
                CommandName = parameter
            });
        }
    }

    public delegate void FileMenuHandler(object sender, FileMenuEventArgs args);

    public class FileMenuEventArgs : EventArgs
    {
        public FileMenuEventArgs()
            : this(string.Empty)
        {

        }
        public FileMenuEventArgs(string commandName)
        {
            CommandName = CommandName;
        }
        public string CommandName
        {
            get;
            set;
        }
    }

}

﻿using System.Windows;

namespace Brainwave.UserManagementShell
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class UM_Shell : Window
    {
        public UM_Shell(ShellViewModel Model)
        {
            InitializeComponent();
            this.DataContext = Model;
        }

    }

}

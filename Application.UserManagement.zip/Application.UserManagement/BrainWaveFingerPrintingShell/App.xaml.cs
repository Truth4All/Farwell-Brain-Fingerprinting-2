﻿using Brainwave.Automation;
using Brainwave.Infrastructure;
using System;
using System.Diagnostics;
using System.Windows;
using Brainwave.Business;

namespace Brainwave.UserManagementShell
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class UM_App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {

                Process thisProc = Process.GetCurrentProcess();
                if (Process.GetProcessesByName(thisProc.ProcessName).Length > 1)
                {
                    MessageBox.Show(LanguageAssetBusiness.ApplicationRunning); 
                    Application.Current.Shutdown();
                    return;
                }

                base.OnStartup(e);


                GlobalVariables.DomainConnection = false; // Not true until server is discovered
                Automat au = new Automat();
                GlobalVariables.RunTimeSecurity = au.myRunTimeSecurity();
                GlobalVariables.Internet = au.GetInternetConnectionState();
                GlobalVariables.DomainAttached = au.IsAttachedToDomain();
                GlobalVariables.Domain = au.myDomain();
                GlobalVariables.CurrentLCID = au.LCID;

                GlobalVariables.ConfigPath = string.Format(@"{0}config\", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)));

                GlobalVariables.DocumentsPath = string.Format(@"{0}documents\", string.Format(@"{0}\Brainwave\", Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)));
                //Load Master Data
                GlobalVariables.MasterData = Brainwave.DataSet.MasterDataDL.LoadMasterData();

                UM_BFPBootStrapper bootStrapper = new UM_BFPBootStrapper();
                BFPConfiguration.Load();
                bootStrapper.Run();

            }
            catch (Exception)
            {
                this.Shutdown();
            }
           
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
        }
    }
}

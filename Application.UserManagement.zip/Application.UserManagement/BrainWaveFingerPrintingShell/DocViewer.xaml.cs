﻿using System.Windows;

namespace Brainwave.UserManagementShell
{
    /// <summary>
    /// Interaction logic for DocViewer.xaml
    /// </summary>
    public partial class DocViewer : Window
    {
        public DocViewer()
        {
            InitializeComponent();
        }
    }
}

﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace MonitorService
{
    [RunInstaller(true)]
    public partial class MonitorInstaller : Installer
    {
        private ServiceProcessInstaller serviceProcessInstaller;
        private ServiceInstaller serviceInstaller;

        public MonitorInstaller()
        {
            serviceProcessInstaller = new ServiceProcessInstaller();
            serviceInstaller = new ServiceInstaller();

            serviceProcessInstaller.Account = ServiceAccount.LocalService;
            serviceInstaller.StartType      = ServiceStartMode.Automatic;
            serviceInstaller.ServiceName    = MonitorService.Name;
            serviceInstaller.DisplayName    = MonitorService.DisplayName;
            serviceInstaller.Description    = MonitorService.Description;

            this.Installers.AddRange(new Installer[] { serviceProcessInstaller, serviceInstaller });
            this.AfterInstall += new InstallEventHandler(ServiceInstaller_AfterInstall);
        }

        void ServiceInstaller_AfterInstall(object sender, InstallEventArgs e)
        {
            serviceInstaller.ServiceName = MonitorService.Name;
            using (ServiceController sc = new ServiceController(serviceInstaller.ServiceName))
            {
                sc.Start();
            }

        }
    }
}

﻿using BWS.WebServices;
using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Discovery;

namespace MonitorService
{
    partial class Discovery
    {
        ISynchro serviceObject = null;
        ChannelFactory<ISynchro> channelFactory = null;

        string CertificateFile      = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\BrainwaveServerSecurity.pfx";
        string CertificatePassword  = "c3xQT6Z2";

        EndpointAddress ep = null;
        Uri discoveredAddress;
        string BrainwaveServer;

        private Uri FindBrainwaveServerAddress()
        {
            // Create the DiscoveryClient
            DiscoveryClient discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
            // Find Syncho endpoints
            FindCriteria FCriteria = new FindCriteria(typeof(ISynchro));
            //FCriteria.MaxResults = 1;
            //FCriteria.ScopeMatchBy.Equals("BWS.WebServices.Synchro");
            FindResponse findResponse = discoveryClient.Find(FCriteria);
            discoveryClient.Close();
            if (findResponse.Endpoints.Count > 0)
            {
                return findResponse.Endpoints[0].Address.Uri;
            }
            else
            {
                return null;
            }
        }

        public bool IsBrainwaveServerOnline()
        {
            // Is the registry set with a BrainwaveServer value?
            if (!Registry.IsRegistryKeyExist("BrainwaveServer"))
            {
                discoveredAddress = FindBrainwaveServerAddress();
                BrainwaveServer = discoveredAddress.GetLeftPart(UriPartial.Authority).ToString();
                Registry.SetRegistryValue("BrainwaveServer", BrainwaveServer);
            }
            else
            {
                BrainwaveServer = Registry.GetRegistryValue("BrainwaveServer").ToString();
            }

            X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
            string ServerPath = BrainwaveServer + @"/Synchro/";
            ep = new EndpointAddress(ServerPath);

            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.Security.Message.ClientCredentialType  = MessageCredentialType.Certificate;
            tcpb.MaxReceivedMessageSize                 = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferSize                          = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferPoolSize                      = int.MaxValue; // should consider reducing that
            tcpb.TransferMode                           = TransferMode.Streamed;
            tcpb.CloseTimeout                           = TimeSpan.FromSeconds(20); // default: 10 seconds
            tcpb.OpenTimeout                            = TimeSpan.FromMinutes(1);  // default: 1 minute
            tcpb.ReceiveTimeout                         = TimeSpan.FromMinutes(20); // default: 10 minutes
            tcpb.SendTimeout                            = TimeSpan.FromMinutes(10); // default: 1 minute

            channelFactory = new ChannelFactory<ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            try
            {
                string IPAddress = serviceObject.GetServerIP();
                return true;
            }
            catch(Exception)
            {
                discoveredAddress = FindBrainwaveServerAddress();
                BrainwaveServer = discoveredAddress.GetLeftPart(UriPartial.Authority).ToString();
                Registry.SetRegistryValue("BrainwaveServer", BrainwaveServer);
                try
                {
                    string IPAddress = serviceObject.GetServerIP();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Detect if the machine was connected to a domain controller
        /// </summary>
        /// <returns>true if attached to a domain</returns>
        public bool IsAttachedToDomain()
        {
            Win32.NetJoinStatus status = Win32.NetJoinStatus.NetSetupUnknownStatus;
            IntPtr pDomain = IntPtr.Zero;
            int result = Win32.NetGetJoinInformation(null, out pDomain, out status);
            if (pDomain != IntPtr.Zero)
            {
                Win32.NetApiBufferFree(pDomain);
            }
            if (result == Win32.ErrorSuccess)
            {
                return status == Win32.NetJoinStatus.NetSetupDomainName;
            }
            else
            {
                throw new Exception("Domain Info Get Failed");
            }
        }

    }

    /// <summary>
    /// Win API wrapper
    /// </summary>
    internal class Win32
    {
        public const int ErrorSuccess = 0;

        [DllImport("Netapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int NetGetJoinInformation(string server, out IntPtr domain, out NetJoinStatus status);

        [DllImport("Netapi32.dll")]
        public static extern int NetApiBufferFree(IntPtr Buffer);

        public enum NetJoinStatus
        {
            NetSetupUnknownStatus = 0,
            NetSetupUnjoined,
            NetSetupWorkgroupName,
            NetSetupDomainName
        }
    }
}

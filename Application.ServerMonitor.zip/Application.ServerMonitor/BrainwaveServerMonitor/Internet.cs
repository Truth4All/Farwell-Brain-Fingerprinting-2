﻿using System;
using System.Runtime.InteropServices;

namespace MonitorService
{
    class InternetService
    {

        ConnectionState description = 0;

        [Flags]
        enum ConnectionState : int
        {
            INTERNET_CONNECTION_MODEM = 0x1,  // Local system uses a modem to connect to the Internet.
            INTERNET_CONNECTION_LAN = 0x2,  // Local system uses a local area network to connect to the Internet.
            INTERNET_CONNECTION_PROXY = 0x4,  // Local system uses a proxy server to connect to the Internet.
            INTERNET_RAS_INSTALLED = 0x10, // Local system has RAS installed.
            INTERNET_CONNECTION_OFFLINE = 0x20, // Local system is in offline mode.
            INTERNET_CONNECTION_CONFIGURED = 0x40  // Local system has a valid connection to the Internet, but it might or might not be currently connected.
        }

        [DllImport("wininet.dll", CharSet = CharSet.Auto)]
        static extern bool InternetGetConnectedState(ref ConnectionState lpdwFlags, int dwReserved);

        /// <summary>
        /// This method detect the connection to an intranet, ehternet network, it does not necessarily means that we have a public Internet connection.
        /// </summary>
        /// <returns>true when connected</returns>
        public bool GetInternetConnectionState()
        {
            return InternetGetConnectedState(ref description, 0);
        }

    }
}

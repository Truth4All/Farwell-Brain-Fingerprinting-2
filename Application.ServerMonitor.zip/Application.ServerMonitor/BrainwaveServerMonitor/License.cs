﻿using BWS.WebServices;
using System;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceModel;


namespace MonitorService
{
    class License
    {
        ChannelFactory<ISynchro> channelFactory = null;
        EndpointAddress ep = null;
        string LicenseToPayFile    = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\database\D669F7E1-6A86-4D8C-AE8F-22B209223407";
        string LocalCatalog        = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\Catalog.xml";
        string TempCatalog         = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\temp\Catalog.xml";
        string CatalogSchema       = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)          + @"\Brainwave\config\Catalog.xsd";
        string CertificateFile     = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)          + @"\Brainwave\config\BrainwaveServerSecurity.pfx";
        string CertificatePassword = "c3xQT6Z2";

        public void tickleLicense()
        {
            // Are we connected to the Internet
            InternetService IS = new InternetService();
            Discovery DS = new Discovery();
            ISynchro serviceObject = null;

            if (IS.GetInternetConnectionState())
            {
                if (DS.IsBrainwaveServerOnline())
                {
                    X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
                    string ServerPath = Registry.GetRegistryValue("BrainwaveServer").ToString() + @"/Synchro/";
                    ep = new EndpointAddress(ServerPath);

                    NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
                    tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
                    tcpb.MaxReceivedMessageSize = int.MaxValue;     // should consider reducing that
                    tcpb.MaxBufferSize = int.MaxValue;              // should consider reducing that
                    tcpb.MaxBufferPoolSize = int.MaxValue;          // should consider reducing that
                    tcpb.TransferMode = TransferMode.Streamed;
                    tcpb.CloseTimeout = TimeSpan.FromSeconds(20);   // default: 10 seconds
                    tcpb.OpenTimeout = TimeSpan.FromMinutes(1);     // default: 1 minute
                    tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
                    tcpb.SendTimeout = TimeSpan.FromMinutes(10);    // default: 1 minute

                    channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
                    channelFactory.Credentials.ClientCertificate.Certificate = certificate;
                    serviceObject = channelFactory.CreateChannel(ep);

                    // Now get the elements for "GetLicense"
                    // Local IP address
                    var localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);

                    serviceObject.TickleUserLicense(System.Environment.MachineName.ToString(), localIpAddress.ToString(), GetLoggedInUser());
                }
            }
        }

        private string GetLoggedInUser()
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem");
            ManagementObjectCollection collection = searcher.Get();
            string username = (string)collection.Cast<ManagementBaseObject>().First()["UserName"];

            NTAccount f = new NTAccount(username);
            SecurityIdentifier s = (SecurityIdentifier)f.Translate(typeof(SecurityIdentifier));
            String sidString = s.ToString();

            return sidString;
        }

        public void LicenseToPay()
        {
            if (File.Exists(LicenseToPayFile))
            {
                if (GetLicenseToPay() != 0)
                {
                    PayCachedTestLicense(GetLicenseToPay());
                    SetLicenseBalance(0);
                }
            }
        }

        public void PayCachedTestLicense(int count)
        {
            // Are we connected to the Internet
            InternetService IS = new InternetService();
            Discovery DS = new Discovery();
            ISynchro serviceObject = null;

            if (IS.GetInternetConnectionState())
            {
                if (DS.IsBrainwaveServerOnline())
                {
                    X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
                    string ServerPath = Registry.GetRegistryValue("BrainwaveServer").ToString() + @"/Synchro/";
                    ep = new EndpointAddress(ServerPath);
                    ChannelFactory<ISynchro> channelFactory = null;

                    NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
                    tcpb.Security.Message.ClientCredentialType = MessageCredentialType.Certificate;
                    tcpb.MaxReceivedMessageSize = int.MaxValue;     // should consider reducing that
                    tcpb.MaxBufferSize = int.MaxValue;              // should consider reducing that
                    tcpb.MaxBufferPoolSize = int.MaxValue;          // should consider reducing that
                    tcpb.TransferMode = TransferMode.Streamed;
                    tcpb.CloseTimeout = TimeSpan.FromSeconds(20);   // default: 10 seconds
                    tcpb.OpenTimeout = TimeSpan.FromMinutes(1);     // default: 1 minute
                    tcpb.ReceiveTimeout = TimeSpan.FromMinutes(20); // default: 10 minutes
                    tcpb.SendTimeout = TimeSpan.FromMinutes(10);    // default: 1 minute

                    channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
                    channelFactory.Credentials.ClientCertificate.Certificate = certificate;
                    serviceObject = channelFactory.CreateChannel(ep);

                    // Get the count
                    string _machineName = System.Environment.MachineName.ToString();

                    try
                    {
                        serviceObject.DebitTestLicense(GetLoggedInUser(), _machineName, count);
                    }
                    catch
                    {
                    }
                }
            }
        }

        public int GetLicenseToPay()
        {
            string existingLicenseCount = File.ReadAllText(LicenseToPayFile);
            existingLicenseCount = Crypto.Decrypt(existingLicenseCount, "EECAF687-580D-40FC-BD24-EF7ED9110DD1");
            return Convert.ToInt32(existingLicenseCount);
        }

        public void SetLicenseBalance(int count)
        {
            string LicenseCount = count.ToString();
            LicenseCount = Crypto.Encrypt(LicenseCount, "EECAF687-580D-40FC-BD24-EF7ED9110DD1");
            File.WriteAllText(LicenseToPayFile, LicenseCount);
        }

    }
}

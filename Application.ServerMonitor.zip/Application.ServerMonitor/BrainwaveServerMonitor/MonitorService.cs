﻿using System.ServiceProcess;

namespace MonitorService
{
    public class MonitorService : ServiceBase
    {
        private System.ComponentModel.IContainer components = null;

        //Service constants
        public const string Name = "BrainwaveServerMonitor";
        public const string DisplayName = "Brainwave Server Monitor";
        public const string Description = "This service monitors the state of the Brainwave Server";

        //Event Logging constants
        public static string eventLog = "Brainwave";
        public static string eventSource = "BrainwaveServerMonitor";

        public MonitorService()
        {
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.ServiceName = "BrainwaveServerMonitor";
        }

        protected override void OnStart(string[] args)
        {
            // 2 minutes delay
            //System.Threading.Thread.Sleep(2 * 60 * 1000);

            //License lic = new License();
            //lic.InitLicenseCache();

            Registry.SetRegistryValue("CatalogSynced", false);
            TimerService TS = new TimerService();
        }

        protected override void OnStop()
        {
            Registry.SetRegistryValue("CatalogSynced", false);
        }
    }
}

﻿using BWS.WebServices;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceModel;

namespace MonitorService
{
    public class Catalog
    {
        ChannelFactory<ISynchro> channelFactory = null;
        EndpointAddress ep = null;

        string LocalCatalog         = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\documents\Catalog.xml";
        string TempCatalog          = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\Brainwave\temp\Catalog.xml";
        string CatalogSchema        = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\Catalog.xsd";
        string CertificateFile      = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Brainwave\config\BrainwaveServerSecurity.pfx";
        string CertificatePassword  = "c3xQT6Z2";

        public void DownloadCatalog()
        {
            ISynchro serviceObject = null;

            X509Certificate2 certificate = new X509Certificate2(CertificateFile, CertificatePassword);
            string ServerPath = Registry.GetRegistryValue("BrainwaveServer").ToString() + @"/Synchro/";
            ep = new EndpointAddress(ServerPath);

            NetTcpBinding tcpb = new NetTcpBinding(SecurityMode.Transport);
            tcpb.Security.Message.ClientCredentialType  = MessageCredentialType.Certificate;
            tcpb.MaxReceivedMessageSize                 = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferSize                          = int.MaxValue; // should consider reducing that
            tcpb.MaxBufferPoolSize                      = int.MaxValue; // should consider reducing that
            tcpb.TransferMode                           = TransferMode.Streamed;
            tcpb.CloseTimeout                           = TimeSpan.FromSeconds(20); // default: 10 seconds
            tcpb.OpenTimeout                            = TimeSpan.FromMinutes(1);  // default: 1 minute
            tcpb.ReceiveTimeout                         = TimeSpan.FromMinutes(20); // default: 10 minutes
            tcpb.SendTimeout                            = TimeSpan.FromMinutes(10); // default: 1 minute

            channelFactory = new ChannelFactory<BWS.WebServices.ISynchro>(tcpb);
            channelFactory.Credentials.ClientCertificate.Certificate = certificate;
            serviceObject = channelFactory.CreateChannel(ep);

            // Get the Catalog
            var fileStream = File.Create(TempCatalog);
            Stream FolioStream = serviceObject.GetCatalogFile(GetLoggedInUser(), System.Environment.MachineName.ToString());
            FolioStream.CopyTo(fileStream);
            fileStream.Close();
        }

        public void CatalogReconciliation()
        {
            if (!File.Exists(TempCatalog))
            {
                // Temporary Catalog does not exist - therefore nothing to do
                return;
            }
            else
            {
                if (!File.Exists(LocalCatalog))
                {
                    DataSet TempDS = new DataSet("Catalog");
                    TempDS.ReadXmlSchema(CatalogSchema);
                    TempDS.EnforceConstraints = false;
                    TempDS.ReadXml(TempCatalog);
                    TempDS.WriteXml(LocalCatalog);
                }
                else
                {
                    // perform reconciliation
                    CompareCatalogs();
                }
                Registry.SetRegistryValue("CatalogSynced", true);
            }
        }

        public void CompareCatalogs()
        {
            DataSet LocalDS = new DataSet("Catalog");
            LocalDS.ReadXmlSchema(CatalogSchema);
            LocalDS.EnforceConstraints = false;
            LocalDS.ReadXml(LocalCatalog);

            DataSet TempDS = new DataSet("Catalog");
            TempDS.ReadXmlSchema(CatalogSchema);
            TempDS.EnforceConstraints = false;
            TempDS.ReadXml(TempCatalog);

            // The Temp table is from the storage of reference - so it's the master.  We start by analyzing the master.
            foreach (DataRow TempDR in TempDS.Tables["Case"].Rows)
            {
                string CaseGUID = TempDR["GUID"].ToString();

                // Select corresponding case in local catalog
                DataRow[] localDR = LocalDS.Tables["Case"].Select(String.Format("GUID = '{0}'", CaseGUID));
                if (localDR != null && localDR.Length != 0)
                {
                    int TempSerial = Convert.ToInt32(TempDR["Serial"]);
                    int LocalSerial = Convert.ToInt32(localDR[0]["Serial"]);

                    if (TempSerial == LocalSerial)
                    {
                        // Case are in sync
                        // Nothing to do
                    }
                    else
                    {
                        if (TempSerial > LocalSerial) // Server Version is new
                        {
                            // if case lock by be and server new -> should not exists

                            // if case is not cached (that is not in the documents directory) and not locked -> just update the local catalog
                            string LocalFile = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + String.Format(@"\Brainwave\documents\{0}.xml", CaseGUID);
                            if (!File.Exists(LocalFile)) // No cached copy
                            {
                                // Update the Local Catalog with the new record
                                DataRow[] temp = TempDS.Tables["Case"].Select(String.Format("GUID = '{0}'", CaseGUID));
                                DataRow[] local = LocalDS.Tables["Case"].Select(String.Format("GUID = '{0}'", CaseGUID));
                                {
                                    local[0]["Serial"]              = temp[0]["Serial"];
                                    local[0]["Sync"]                = temp[0]["Sync"];
                                    local[0]["IsActive"]            = temp[0]["IsActive"];
                                    local[0]["IsDeleted"]           = temp[0]["IsDeleted"];
                                    local[0]["IsLocked"]            = temp[0]["IsLocked"];

                                    local[0]["JurisdictionID"]      = temp[0]["JurisdictionID"];
                                    local[0]["CaseName"]            = temp[0]["CaseName"];
                                    local[0]["CaseSummary"]         = temp[0]["CaseSummary"];
                                    local[0]["ModifiedBy"]          = temp[0]["ModifiedBy"];
                                    local[0]["ModifiedTimestamp"]   = temp[0]["ModifiedTimestamp"];
                                    local[0]["OwnedBy"]             = temp[0]["OwnedBy"];
                                    local[0]["CreatedTimestamp"]    = temp[0]["CreatedTimestamp"];
                                    local[0]["LockedBy"]            = temp[0]["LockedBy"];
                                }
                                LocalDS.AcceptChanges();
                                LocalDS.WriteXml(LocalCatalog);
                            }
                            else
                            {
                                // The record is new on the server, but the case is loaded on the local machine.
                                // Error
                            }
                        }
                        else
                        {
                            // The Local catalog record is newer than the server - we need to upload the revised case to the server
                            string LocalFile = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + String.Format(@"\Brainwave\documents\{0}.xml", CaseGUID);
                            if (!File.Exists(LocalFile)) // No cached copy
                            {
                                // We have modified the Catalog record, but the file has been deleted locally
                                // Error
                            }
                            else
                            {
                                // When exit needs to update server
                            }
                        }
                    }
                }
                else
                {
                    // The GUID does not exist in the Local Catalog, It's a new case on the server
                    // Create a new record to be inserted in the Local Catalog
                    DataRow[] FromR = TempDS.Tables["Case"].Select(String.Format("GUID = '{0}'", CaseGUID));
                    LocalDS.Tables["Case"].ImportRow(FromR[0]);
                    LocalDS.AcceptChanges();
                    LocalDS.WriteXml(LocalCatalog);
                }
            }

            // We now analyse the local table to see if new case have been created.
            foreach (DataRow LocalDR in LocalDS.Tables["Case"].Rows)
            {
                string CaseGUID = LocalDR["GUID"].ToString();

                // Select corresponding case in local catalog
                DataRow[] TempDR = TempDS.Tables["Case"].Select(String.Format("GUID = '{0}'", CaseGUID));
                if (TempDR == null || TempDR.Length == 0)
                {
                    // We created a new case
                    // new case -> update server
                }
            }
        }

        private string GetLoggedInUser()
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem");
            ManagementObjectCollection collection = searcher.Get();
            string username = (string)collection.Cast<ManagementBaseObject>().First()["UserName"];

            NTAccount f = new NTAccount(username);
            SecurityIdentifier s = (SecurityIdentifier)f.Translate(typeof(SecurityIdentifier));
            String sidString = s.ToString();

            return sidString;
        }
    }
}

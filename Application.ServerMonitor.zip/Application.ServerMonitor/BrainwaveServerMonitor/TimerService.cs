﻿using System;
using System.ComponentModel;
using System.Timers;


namespace MonitorService
{
    class TimerService
    {
        private Timer ScheduleTimer;
        private BackgroundWorker worker;

        public TimerService()
        {
            InitialTask();
            worker = new BackgroundWorker();
            worker.DoWork += ScheduledTask;
            ScheduleTimer = new Timer(TimeSpan.FromMinutes(5).TotalMilliseconds);
            ScheduleTimer.Elapsed += timer_Elapsed;
            ScheduleTimer.Start();
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (!worker.IsBusy) worker.RunWorkerAsync();
        }

        void ScheduledTask(object sender, DoWorkEventArgs e)
        {
            InternetService IS = new InternetService();
            Discovery DS = new Discovery();

            if (DS.IsAttachedToDomain())
            {
                if (IS.GetInternetConnectionState())
                {
                    if (DS.IsBrainwaveServerOnline())
                    {
                        // Get fresh catalog from server
                        Catalog CT = new Catalog();
                        CT.DownloadCatalog();
                        CT.CatalogReconciliation();

                        // Ping User license
                        License lic = new License();
                        lic.tickleLicense();

                        // Any Test License to debit?
                        lic.LicenseToPay();
                    }
                }
            }
        }

        void InitialTask()
        {
            InternetService IS = new InternetService();
            Discovery DS = new Discovery();

            if (DS.IsAttachedToDomain())
            {
                if (IS.GetInternetConnectionState())
                {
                    if (DS.IsBrainwaveServerOnline())
                    {
                        // Get fresh catalog from server
                        Catalog CT = new Catalog();
                        CT.DownloadCatalog();
                        CT.CatalogReconciliation();
                    }
                }
            }
        }
    }
}

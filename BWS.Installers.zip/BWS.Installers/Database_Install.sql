BEGIN TRANSACTION;
BEGIN TRY
	CREATE DATABASE BrainwaveDB
		ON PRIMARY (NAME = BrainwaveDB, FILENAME = 'C:\ProgramData\BrainwaveServer\database\BrainwaveDB.mdf',     SIZE = 2MB, MAXSIZE = 10MB, FILEGROWTH = 10%)
		LOG ON (NAME = BrainwaveDB_Log, FILENAME = 'C:\ProgramData\BrainwaveServer\database\BrainwaveDB_log.ldf', SIZE = 1MB, MAXSIZE = 5MB,  FILEGROWTH = 10%)
		
		USE [master]
        IF NOT EXISTS (SELECT * FROM master.sys.server_principals WHERE name = N'brainwave')
			BEGIN
				CREATE LOGIN [brainwave] WITH PASSWORD = N'brainwave', DEFAULT_DATABASE =[master], DEFAULT_LANGUAGE =[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
			END

        USE [BrainwaveDB]
		IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE name = N'brainwave')	
			BEGIN
				CREATE USER [brainwave] FOR LOGIN [brainwave] WITH DEFAULT_SCHEMA=[dbo]
			END				
END TRY

BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
END CATCH;

IF @@TRANCOUNT > 0
    COMMIT TRANSACTION;
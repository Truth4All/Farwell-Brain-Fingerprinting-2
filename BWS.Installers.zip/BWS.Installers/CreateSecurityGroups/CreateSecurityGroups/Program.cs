﻿using System.DirectoryServices.AccountManagement;

namespace CreateSecurityGroups
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var local = new PrincipalContext(ContextType.Machine))
            {
                var group = GroupPrincipal.FindByIdentity(local, "BF_Operators");
                if (group == null)
                {
                    GroupPrincipal entry = new GroupPrincipal(local);
                    entry.Name = "BF_Operators";
                    entry.Description = "Brain Fingerprinting Operator Group";
                    entry.Save();
                }

                group = GroupPrincipal.FindByIdentity(local, "BF_Supervisors");
                if (group == null)
                {
                    GroupPrincipal entry = new GroupPrincipal(local);
                    entry.Name = "BF_Supervisors";
                    entry.Description = "Brain Fingerprinting Supervisor Group";
                    entry.Save();
                }

                group = GroupPrincipal.FindByIdentity(local, "BF_Investigators");
                if (group == null)
                {
                    GroupPrincipal entry = new GroupPrincipal(local);
                    entry.Name = "BF_Investigators";
                    entry.Description = "Brain Fingerprinting Investigator Group";
                    entry.Save();
                }

                group = GroupPrincipal.FindByIdentity(local, "BF_Managers");
                if (group == null)
                {
                    GroupPrincipal entry = new GroupPrincipal(local);
                    entry.Name = "BF_Managers";
                    entry.Description = "Brain Fingerprinting Manager Group";
                    entry.Save();
                }

                // Set the initial Manager user
                var user = UserPrincipal.FindByIdentity(local, "Manager");
                if (user == null)
                {
                    // Create the user
                    UserPrincipal entry = new UserPrincipal(local);
                    entry.Name = "Manager";
                    entry.SetPassword("password@1234");
                    entry.PasswordNeverExpires = true;
                    entry.Description = "Initial Brain Fingerprinting Manager user";
                    entry.Save();

                    // Add the user to group
                    using (PrincipalContext sourceContext = new PrincipalContext(ContextType.Machine))
                    {
                        try
                        {
                            GroupPrincipal Mgroup = GroupPrincipal.FindByIdentity(sourceContext, "BF_Managers");
                            Mgroup.Members.Add(sourceContext, IdentityType.SamAccountName, entry.Name);
                            Mgroup.Save();
                            Mgroup.Dispose();
                        }
                        catch
                        {
                        }
                    }
                    using (PrincipalContext sourceContext = new PrincipalContext(ContextType.Machine))
                    {
                        try
                        {
                            GroupPrincipal Mgroup = GroupPrincipal.FindByIdentity(sourceContext, "Administrators");
                            Mgroup.Members.Add(sourceContext, IdentityType.SamAccountName, entry.Name);
                            Mgroup.Save();
                            Mgroup.Dispose();
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }
    }
}

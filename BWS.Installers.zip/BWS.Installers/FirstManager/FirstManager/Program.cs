﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;

namespace FirstManager
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", string.Format(@"{0}config\Brainwave.config", string.Format(@"{0}\BrainwaveServer\", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles))));
            string connectionString = ConfigurationManager.ConnectionStrings["BrainwaveDBConnectionString"].ConnectionString;
            Program.InsertInitialUser(connectionString);
        }

        static void InsertInitialUser(string connectionString) {

            string SID      = UserPrincipal.Current.Sid.ToString();
            string Username = Environment.UserName;
            string UID      = Guid.NewGuid().ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText  = @"INSERT INTO BF_Users (SID, UID, Username, SupervisorSID, SupervisorName, Role) ";
                cmd.CommandText += @"VALUES ('" + SID + "','" + UID + "','" + Username + "','" + SID + "','" + Username + "', 'BF_Managers'" + "); ";
                cmd.CommandType  = CommandType.Text;
                cmd.Connection   = connection;

                connection.Open();
                cmd.ExecuteNonQuery();
            }

        }
    }
}

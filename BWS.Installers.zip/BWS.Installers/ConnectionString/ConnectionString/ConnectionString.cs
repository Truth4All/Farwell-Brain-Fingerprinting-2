﻿using System;
using System.Configuration;
using System.Windows.Forms;
using System.Xml;
using System.Data.SqlClient;


namespace ConnectionString
{
    public partial class ConnectionString : Form
    {
        public string SchemaDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\";
        public string InstallDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\bin\install\";
        public Configuration CustomConfig;
        static public string connectionStringText;

        public ConnectionString()
        {
            InitializeComponent();
            InitialConfiguration();
        }

        private void InitialConfiguration()
        {
            System.Data.SqlClient.SqlConnectionStringBuilder connBld = new System.Data.SqlClient.SqlConnectionStringBuilder();
            connBld.ConnectionString = ReadConfigurationString();
            tbx_DataSource.Text = connBld.DataSource;
            tbx_InitialCatalog.Text = connBld.InitialCatalog;
            tbx_UserID.Text = connBld.UserID;
            tbx_Password.Text = connBld.Password;
            cbx_IntegratedAuth.Checked = connBld.IntegratedSecurity;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionWizard CW = new ConnectionWizard();
            CW.ShowDialog();

            System.Data.SqlClient.SqlConnectionStringBuilder connBld = new System.Data.SqlClient.SqlConnectionStringBuilder();
            connBld.ConnectionString = connectionStringText;
            tbx_DataSource.Text = connBld.DataSource;
            tbx_InitialCatalog.Text = connBld.InitialCatalog;
            tbx_UserID.Text = connBld.UserID;
            tbx_Password.Text = connBld.Password;
            cbx_IntegratedAuth.Checked = connBld.IntegratedSecurity;

            WriteConfigurationString(connBld.ConnectionString);
            ModifyPublishProfile(connBld.ConnectionString);
        }

        private string ReadConfigurationString()
        {
            string configFilePath = string.Format(@"{0}Brainwave.config", SchemaDirectory);
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = configFilePath;
            CustomConfig = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            return CustomConfig.ConnectionStrings.ConnectionStrings["BrainwaveDBConnectionString"].ToString();
        }

        private void WriteConfigurationString(string configurationString)
        {
            string configFilePath = string.Format(@"{0}Brainwave.config", SchemaDirectory);
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = configFilePath;
            var config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            var connectionStringsSection = (ConnectionStringsSection)config.GetSection("connectionStrings");
            connectionStringsSection.ConnectionStrings["BrainwaveDBConnectionString"].ConnectionString = configurationString;
            config.Save();
            ConfigurationManager.RefreshSection("connectionStrings");
        }

        private void ModifyPublishProfile(string configurationString)
        {
            string ProfileFilePath = string.Format(@"{0}BrainwaveDB.publish.xml", InstallDirectory);

            XmlDocument doc = new XmlDocument();
            XmlNamespaceManager nsMgr = new XmlNamespaceManager(doc.NameTable);
            nsMgr.AddNamespace("ab", "http://schemas.microsoft.com/developer/msbuild/2003");
            doc.Load(ProfileFilePath);

            XmlNode node = doc.SelectSingleNode("/ab:Project/ab:PropertyGroup/ab:TargetConnectionString", nsMgr);
            node.InnerText = configurationString;

            doc.Save(ProfileFilePath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿namespace ConnectionString
{
    partial class ConnectionString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tbx_DataSource = new System.Windows.Forms.TextBox();
            this.tbx_InitialCatalog = new System.Windows.Forms.TextBox();
            this.tbx_UserID = new System.Windows.Forms.TextBox();
            this.tbx_Password = new System.Windows.Forms.TextBox();
            this.cbx_IntegratedAuth = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(120, 139);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Change Database Settings";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbx_DataSource
            // 
            this.tbx_DataSource.Location = new System.Drawing.Point(120, 12);
            this.tbx_DataSource.Name = "tbx_DataSource";
            this.tbx_DataSource.Size = new System.Drawing.Size(274, 20);
            this.tbx_DataSource.TabIndex = 2;
            // 
            // tbx_InitialCatalog
            // 
            this.tbx_InitialCatalog.Location = new System.Drawing.Point(120, 38);
            this.tbx_InitialCatalog.Name = "tbx_InitialCatalog";
            this.tbx_InitialCatalog.Size = new System.Drawing.Size(274, 20);
            this.tbx_InitialCatalog.TabIndex = 3;
            // 
            // tbx_UserID
            // 
            this.tbx_UserID.Location = new System.Drawing.Point(119, 64);
            this.tbx_UserID.Name = "tbx_UserID";
            this.tbx_UserID.Size = new System.Drawing.Size(275, 20);
            this.tbx_UserID.TabIndex = 4;
            // 
            // tbx_Password
            // 
            this.tbx_Password.Location = new System.Drawing.Point(120, 90);
            this.tbx_Password.Name = "tbx_Password";
            this.tbx_Password.Size = new System.Drawing.Size(274, 20);
            this.tbx_Password.TabIndex = 5;
            // 
            // cbx_IntegratedAuth
            // 
            this.cbx_IntegratedAuth.AutoSize = true;
            this.cbx_IntegratedAuth.Location = new System.Drawing.Point(120, 116);
            this.cbx_IntegratedAuth.Name = "cbx_IntegratedAuth";
            this.cbx_IntegratedAuth.Size = new System.Drawing.Size(145, 17);
            this.cbx_IntegratedAuth.TabIndex = 6;
            this.cbx_IntegratedAuth.Text = "Integrated Authentication";
            this.cbx_IntegratedAuth.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Data Source";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Database Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Database User";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Database Password";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(278, 139);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Exist";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ConnectionString
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 174);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbx_IntegratedAuth);
            this.Controls.Add(this.tbx_Password);
            this.Controls.Add(this.tbx_UserID);
            this.Controls.Add(this.tbx_InitialCatalog);
            this.Controls.Add(this.tbx_DataSource);
            this.Controls.Add(this.button1);
            this.Name = "ConnectionString";
            this.Text = "Select Brainwave Database";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbx_DataSource;
        private System.Windows.Forms.TextBox tbx_InitialCatalog;
        private System.Windows.Forms.TextBox tbx_UserID;
        private System.Windows.Forms.TextBox tbx_Password;
        private System.Windows.Forms.CheckBox cbx_IntegratedAuth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
    }
}


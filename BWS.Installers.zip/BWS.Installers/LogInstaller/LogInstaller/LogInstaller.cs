﻿using System;
using System.Configuration.Install;
using System.Diagnostics;
using System.ComponentModel;

namespace LogInstaller
{
    [RunInstaller(true)]

    public class BainwaveLogInstaller : Installer
    {
        private EventLogInstaller LogInstaller;

        public static bool InstallBrainwaveLogging()
        {
            try
            {
                BainwaveLogInstaller myInstaller = new BainwaveLogInstaller();
                string msg = "An Event Source for Brainwave Logging was installed";
                BrainwaveLogEvent("Install", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Main", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Capture", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Replay", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Analysis", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Reports ", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Licensing", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Updates", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("XML_File_Watcher", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Case_Export", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Case_Import", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Test_Export", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Test_Import", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Language", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("Monitor", msg, 1001, EventLogEntryType.Information);
                BrainwaveLogEvent("ServerService", msg, 1001, EventLogEntryType.Information);
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        private BainwaveLogInstaller()
        {
            // Create an instance of an EventLogInstaller.
            LogInstaller = new EventLogInstaller();

            // Set the source name of the event log.
            //LogInstaller.Source = "Capture";

            // Set the event log that the source writes entries to.
            LogInstaller.Log = "Brainwave";

            // Add tLogInstaller to the Installer collection.
            Installers.Add(LogInstaller);
        }

        private static void BrainwaveLogEvent(string eventSource, string message, int eventID, EventLogEntryType level)
        {
            string eventLog = "Brainwave";
            string eventSourceMachine = ".";

            if (!EventLog.SourceExists(eventSource))
            {
                EventSourceCreationData mySourceData = new EventSourceCreationData(eventSource, eventLog);
                mySourceData.MachineName = eventSourceMachine;
                EventLog.CreateEventSource(mySourceData);
            }

            DateTime dt = new DateTime();
            dt = System.DateTime.UtcNow;
            message = dt.ToLocalTime() + ": " + message;
            EventLog.WriteEntry(eventSource, message, level, eventID);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Entities
{
    public class LicenseEntity : BaseEntity, ICloneable
    {
        public string GUID { get; set; }
        public string Serial { get; set; }
        public string Sync { get; set; }
        public int? ProductID { get; set; }
        public string ProductName { get; set; }
        public string LicenseCode { get; set; }
        public DateTime? LicenseExpiration { get; set; }
        public int? OriginalCount { get; set; }
        public int? LicenseCount { get; set; }
        public string ActivationCode { get; set; }
        public string MachineId { get; set; }
        public DateTime? ActivationDate { get; set; }
        public string ActivationDateText{ get; set; }
        public string LicenseType { get; set; }
        public string LockedBy { get; set; }
        public bool IsLocked { get; set; }

        object ICloneable.Clone()
        {
            return this.Clone();
        }
        public LicenseEntity Clone()
        {
            return (LicenseEntity)this.MemberwiseClone();
        }
    }

    public class MachineEntity : BaseEntity
    {
        public string MachineName { get; set; }
        public string MachineIP { get; set; }
        public string UserSID { get; set; }
        public string UserName { get; set; }
        public string OnlineStatus { get; set; }
        public string LicenseStatus { get; set; }
    }

}

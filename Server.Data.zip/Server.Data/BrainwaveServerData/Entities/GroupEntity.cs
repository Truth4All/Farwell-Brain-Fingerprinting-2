﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Entities
{
    public class GroupEntity : BaseEntity
    {
        public string GID { get; set; }
        public string GroupName { get; set; }
        public string OwnerUID { get; set; }
    }

    public class GroupMembershipEntity : BaseEntity
    {
        public string GID { get; set; }

        public string MemberName { get; set; }
        public string MemberUID { get; set; }
        public string Access { get; set; }
    }
}

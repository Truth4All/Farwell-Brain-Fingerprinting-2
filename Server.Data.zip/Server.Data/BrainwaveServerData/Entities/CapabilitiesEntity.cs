﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Entities
{
    public class CapabilitiesEntity : BaseEntity
    {
        public string ID { get; set; }
        public string Capability { get; set; }
        public string ManagerRights { get; set; }
        public string SupervisorRights { get; set; }
        public string InvestigatorRights { get; set; }
        public string OperatorRights { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Brainwave.Entities
{
    public class CatalogEntity : BaseEntity
    {
        public int Serial { get; set; }
        public bool Sync { get; set; }
        public bool IsLocked { get; set; }
        public string GUID { get; set; }
        public string JurisdictionID { get; set; }
        public string CaseName { get; set; }
        public string CaseSummary { get; set; }
        //public DateTime ModifiedTimestamp { get; set; }
        public string GID { get; set; }
        //public DateTime CreatedTimestamp { get; set; }
        public string LockedBy { get; set; }
    }

    public class FolioMetaData
    {
        public int Serial { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsLocked { get; set; }
        public string CaseName { get; set; }
        public string CaseSummary { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedTimestamp { get; set; }
        public string OwnedBy { get; set; }
        public DateTime CreatedTimestamp { get; set; }
        public string LockedBy { get; set; }
        public string GID { get; set; }
        public string GroupName { get; set; }
        public string Access { get; set; }
    }
}

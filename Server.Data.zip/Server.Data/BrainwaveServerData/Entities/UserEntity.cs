﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Entities
{
    public class UserEntity : BaseEntity, ICloneable
    {
        public string SID { get; set; }
        public string UID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Description { get; set; }
        public string GroupName { get; set; }
        public string GroupID { get; set; }
        public string SupervisorID { get; set; }
        public string SupervisorName { get; set; }
        public string Role { get; set; }
        public string PreviousGroupName { get; set; }
        public string Capabilities { get; set; }
        public bool IsInDB { get; set; }


        object ICloneable.Clone()
        {
            return this.Clone();
        }
        public UserEntity Clone()
        {
            return (UserEntity)this.MemberwiseClone();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Entities
{
    public class BaseEntity : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public string _modifiedBy;
        public string _modifiedTimestamp;
        public string _createdTimestamp;
        public string _status;
        public bool _isChecked;
        public string _ownedBy;

        private bool _isActive = true;
        private bool _isDelete = false;
        private bool _canDeleteRecord = true;
        private bool _canShareRecord = true;

        public bool IsActive
        {
            get { return _isActive; }
            set
            {
                _isActive = value;
                OnPropertyChanged("IsActive");
            }
        }

        public string ModifiedBy
        {
            get { return _modifiedBy; }
            set
            {
                _modifiedBy = value;
                OnPropertyChanged("ModifiedBy");
            }
        }

        public string ModifiedTimestamp
        {
            get { return _modifiedTimestamp; }
            set
            {
                _modifiedTimestamp = value;
                OnPropertyChanged("ModifiedTimestamp");
            }
        }

        public string OwnedBy
        {
            get { return _ownedBy; }
            set
            {
                _ownedBy = value;
                OnPropertyChanged("OwnedBy");
            }
        }

        public string CreatedTimestamp
        {
            get { return _createdTimestamp; }
            set
            {
                _createdTimestamp = value;
                OnPropertyChanged("CreatedTimestamp");
            }
        }

        public string Status
        {
            get { return _status; }
            set
            {
                _status = value;
                OnPropertyChanged("Status");
            }
        }

        public bool IsChecked { get { return _isChecked; } set { _isChecked = value; OnPropertyChanged("IsChecked"); } }

        public bool IsDeleted { get { return _isDelete; } set { _isDelete = value; OnPropertyChanged("IsDeleted"); } }

        public bool CanDeleteRecord { get { return _canDeleteRecord; } set { _canDeleteRecord = value; OnPropertyChanged("CanDeleteRecord"); } }

        public bool CanShareRecord { get { return _canShareRecord; } set { _canShareRecord = value; OnPropertyChanged("CanShareRecord"); } }


        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}

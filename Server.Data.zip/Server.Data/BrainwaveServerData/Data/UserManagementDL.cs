﻿
using Brainwave.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace Brainwave.Data
{
    public class UserManagementDL : BaseDL
    {
        #region Declaration
        List<ListItem> lstSystemGroups = new List<ListItem>();
        #endregion

        public List<ListItem> GetSystemGroups()
        {
            try
            {
                ListGroups();
                return lstSystemGroups;
            }

            catch (Exception ex)
            {
                throw;
            }
        }

        private void ListGroups()
        {
            try
            {
                PrincipalContext oPrincipalContext = GetPrincipalContext();

                GroupPrincipal insGroupPrincipal = new GroupPrincipal(oPrincipalContext);
                insGroupPrincipal.Name = "BF_*"; // For Showing only thos groups whose name start with BF_
                //insGroupPrincipal.Name = "*"; // For Showing all groups
                SearchGroups(insGroupPrincipal);
            }

            catch (Exception ex)
            {
                throw;
            }
        }

        private void SearchGroups(GroupPrincipal parGroupPrincipal)
        {
            try
            {
                PrincipalSearcher insPrincipalSearcher = new PrincipalSearcher();
                insPrincipalSearcher.QueryFilter = parGroupPrincipal;

                ListItem item = null;
                PrincipalSearchResult<Principal> results = insPrincipalSearcher.FindAll();

                foreach (Principal p in results)
                {
                    item = new ListItem();
                    item.Value = p.Sid.ToString();
                    item.Text = p.Name;
                    lstSystemGroups.Add(item);
                }
            }

            catch (Exception ex)
            {
                throw;
            }

        }

        public bool IsUserExistInDB(string SID)
        {
            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@SID", SqlDbType.NVarChar, 100) { Value = SID.Trim() };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                    "GetUserDetail", sqlParams);
                if (reader.HasRows)
                {
                    reader.Close();
                    return true;
                }
                else
                {
                    reader.Close();
                    return false;
                }


            }
            catch (Exception ex)
            {
                throw;
            }

            return false;

        }

        public bool IsUserExistInDBByUserName(string UserName)
        {
            try
            {
                UserEntity UserInfo = GetUserDetailsByUserName(UserName);

                if (UserInfo == null) return true;


            }
            catch (Exception ex)
            {
                throw;
            }

            return false;

        }

        public bool IsUserInBFGroup()
        {
            const string ManagerRole = "BF_Managers";
            const string OperatorRole = "BF_Operators";
            const string SupervisorRole = "BF_Supervisors";
            const string InvestigatorRole = "BF_Investigators";

            bool result = false;
            try
            {
                UserPrincipal user = GetUser(Environment.UserName);

                foreach (Principal gp in user.GetGroups())
                {
                    //System.Diagnostics.Debug.WriteLine(gp.Name.ToString());
                    if (gp.Name.ToString() == ManagerRole || gp.Name.ToString() == OperatorRole ||
                        gp.Name.ToString() == SupervisorRole || gp.Name.ToString() == InvestigatorRole)
                    {
                        result = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return result;

        }

        public bool IsUserInManagerGroup()
        {
            const string ManagerRole = "BF_Managers";
            bool result = false;
            try
            {
                UserPrincipal user = GetUser(Environment.UserName);

                foreach (Principal gp in user.GetGroups())
                {
                    //System.Diagnostics.Debug.WriteLine(gp.Name.ToString());
                    if (gp.Name.ToString() == ManagerRole)
                    {
                        result = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return result;

        }

        public bool IsUserInDBManager(string UserName)
        {
            const string ManagerRole = "BF_Managers";
            try
            {
                UserEntity UserInfo = GetUserDetailsByUserName(UserName);

                if (UserInfo.Role == ManagerRole) return true;
            }
            catch (Exception ex)
            {
                throw;
            }

            return false;

        }

        public int GetActiveUserCount()
        {
            try
            {
                int activeUserCount = (int)SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "GetActiveUserRecords");

                return activeUserCount;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public int GetUserLicenseCount()
        {
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ReturnedValue", SqlDbType.Int);
                arParms[0].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CheckUserLicense", arParms);

                string[] arReturnParms = new string[1];
                arReturnParms[0] = arParms[0].Value.ToString();

                int userLicenseCount = Convert.ToInt32(arReturnParms[0].ToString());

                return userLicenseCount;
            }

            catch (Exception ex)
            {
                throw;
            }


        }

        public void AddUserDetails(UserEntity info)
        {
            //Saving User info to DB///
            var sqlParams = new SqlParameter[5];
            sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = info.SID };
            sqlParams[1] = new SqlParameter("@Username", SqlDbType.NVarChar, 50) { Value = info.UserName.Trim() };
            sqlParams[2] = new SqlParameter("@Role", SqlDbType.VarChar, 50) { Value = info.Role };
            sqlParams[3] = new SqlParameter("@uid", SqlDbType.UniqueIdentifier) { Value = null };
            sqlParams[4] = new SqlParameter("@gid", SqlDbType.UniqueIdentifier) { Value = null };

            SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "CreateUserRecord", sqlParams);
            while (reader.Read())
            {
                string UID = reader["UID"].ToString();
                string GID = reader["GID"].ToString();
            }
        }

        public int TruncateUserTableData()
        {
            int result = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "TruncateUserInfo";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    result = 1;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return result;
        }

        public bool CheckDefaultUserCreated()
        {
            bool result = false;
            try
            {
                SqlParameter[] arParms = new SqlParameter[1];

                arParms[0] = new SqlParameter("@ReturnedValue", SqlDbType.Int);
                arParms[0].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CheckDefaultUserCreated", arParms);

                string[] arReturnParms = new string[1];
                arReturnParms[0] = arParms[0].Value.ToString();

                int userCount = Convert.ToInt32(arReturnParms[0].ToString());
                if (userCount > 0)
                {
                    result = true;
                }

            }

            catch (Exception ex)
            {
                throw;
            }

            return result;
        }

        //public int AddDefaultUserDetails(UserEntity info)
        //{
        //    int result = 0;

        //    try
        //    {

        //        info.SID = Utility.GetSIDFromUserName(info.UserName);

        //        //Saving User info to DB///
        //        var sqlParams = new SqlParameter[5];
        //        sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = info.SID };

        //        sqlParams[1] = new SqlParameter("@IsActive", SqlDbType.Bit) { Value = info.IsActive };

        //        sqlParams[2] = new SqlParameter("@IsDeleted", SqlDbType.Bit) { Value = info.IsDeleted };

        //        sqlParams[3] = new SqlParameter("@Username", SqlDbType.NVarChar, 100) { Value = info.UserName };

        //        sqlParams[4] = new SqlParameter("@Role", SqlDbType.VarChar, 50) { Value = info.Role };

        //        SqlHelper.ExecuteNonQuery(ConnectionString, "AddUserInfo", sqlParams);
        //        ///////////////////////////

        //        result = 1;
        //    }

        //    catch (Exception ex)
        //    {
        //        //if (result == -2)
        //        //{
        //        //    throw new ApplicationException("Group Error", ex);
        //        //}
        //        result = 0;
        //        throw;
        //    }

        //    return result;

        //}

        public UserEntity GetUserDetails(string SID)
        {
            UserEntity userEntityObj = new UserEntity();
            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 100) { Value = SID };



                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                     "GetUserDetail", sqlParams);
                while (reader.Read())
                {
                    userEntityObj.UserName = reader["UserName"] == null ? "" : reader["UserName"].ToString(); 
                    userEntityObj.SID = reader["SID"] == null ? "" : reader["SID"].ToString();
                    userEntityObj.UID = reader["UID"] == null ? "" : reader["UID"].ToString();
                    userEntityObj.SupervisorID = reader["SupervisorSID"] == null ? "" : reader["SupervisorSID"].ToString();
                    userEntityObj.Role = reader["Role"] == null ? "" : reader["Role"].ToString();

                    userEntityObj.Capabilities = reader["Capabilities"] == null ? "" : reader["Capabilities"].ToString();


                }

                return userEntityObj;

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public UserEntity GetUserDetailsByUserName(string UserName)
        {
            UserEntity userEntityObj = new UserEntity();
            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 100) { Value = UserName };



                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                     "GetUserByName", sqlParams);
                while (reader.Read())
                {
                    userEntityObj.UserName = reader["UserName"] == null ? "" : reader["UserName"].ToString(); ;
                    userEntityObj.SID = reader["SID"] == null ? "" : reader["SID"].ToString();
                    userEntityObj.UID = reader["UID"] == null ? "" : reader["UID"].ToString();
                    userEntityObj.SupervisorID = reader["SupervisorSID"] == null ? "" : reader["SupervisorSID"].ToString();
                    userEntityObj.Role = reader["Role"] == null ? "" : reader["Role"].ToString();

                    userEntityObj.Capabilities = reader["Capabilities"] == null ? "" : reader["Capabilities"].ToString();


                }

                return userEntityObj;

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private UserPrincipal GetUser(string sUserName)
        {
            try
            {
                PrincipalContext objPrincipalContext = GetPrincipalContext();

                UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, sUserName);

                return objUserPrincipal;



            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public UserEntity GetDomainUser(string sUserName)
        {
            try
            {
                PrincipalContext objPrincipalContext = GetPrincipalContextByDomain(GetPrincipalDomain());

                UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, sUserName);

                var _userEntity = new UserEntity
                {
                    SID = objUserPrincipal.Sid.ToString(),
                    UserName = objUserPrincipal.SamAccountName.ToString(),

                    IsActive = Convert.ToBoolean(objUserPrincipal.Enabled),
                    //Capabilities = objUserPrincipal.Description == null ? "" : objUserPrincipal.Description,
                    Capabilities = "",
                    // IsInDB = IsUserExistInDB(objUserPrincipal.SamAccountName.ToString()),
                };
                return _userEntity;



            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private string GetSupervisorName(string SID)
        {
            try
            {
                PrincipalContext objPrincipalContext = GetPrincipalContext();

                UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, IdentityType.Sid, SID);
                if (objUserPrincipal != null)
                {
                    return objUserPrincipal.Name;
                }

            }
            catch (Exception ex)
            {
                return string.Empty;
                //throw;
            }

            return string.Empty;
        }

        private PrincipalContext GetPrincipalContext()
        {
            try
            {
                PrincipalContext objPrincipalContext = null;
                objPrincipalContext = new PrincipalContext(ContextType.Domain, Environment.UserDomainName.ToString());
                return objPrincipalContext;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private string GetPrincipalDomain()
        {
            try
            {
                DirectoryContext domainContext = new DirectoryContext(DirectoryContextType.Domain);
                var domain = System.DirectoryServices.ActiveDirectory.Domain.GetDomain(domainContext);
                var controller = domain.FindDomainController();
                return controller.Domain.ToString();

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private PrincipalContext GetPrincipalContextByDomain(string domain)
        {
            try
            {
                PrincipalContext objPrincipalContext = null;
                objPrincipalContext = new PrincipalContext(ContextType.Domain, domain);
                return objPrincipalContext;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public int DeleteUserDetails(string SID)
        {
            int result = 0;
            try
            {

                // Deleting Info from Database//

                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = SID };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure,
                                                    "DeleteUserDetails", sqlParams);
                result = 1;
                /////////////////////////////////


            }
            catch (Exception ex)
            {
                result = -1;
                throw;
            }

            return result;

        }

        public int UpdateUserDetials(UserEntity info)
        {
            int result = 0;
            try
            {

                //   try
                //   {
                //    PrincipalContext objPrincipalContext = GetPrincipalContext();

                //    UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, IdentityType.Sid, info.SID);
                //    objUserPrincipal.Enabled = info.IsActive;

                //    objUserPrincipal.Save();

                //    // Password reset not allow//
                //    //objUserPrincipal.SetPassword(info.Password);

                //    ////////////// If user previous group not same as current selected////////////////////
                //    if (info.PreviousGroupName != info.GroupName)
                //    {
                //        //Removing User from previous Group///
                //        GroupPrincipal gPRemove = GroupPrincipal.FindByIdentity(objPrincipalContext, info.PreviousGroupName);
                //        gPRemove.Members.Remove(objUserPrincipal);
                //        gPRemove.Save();

                //        //Adding User to Selected Group///
                //        GroupPrincipal gPc = GroupPrincipal.FindByIdentity(objPrincipalContext, info.GroupName);
                //        gPc.Members.Add(objUserPrincipal);
                //        gPc.Save();
                //    }
                //}
                //catch (Exception e)
                //{

                //}
                ///////////////////////////////////

                // Updating Info in Database/////

                var sqlParams = new SqlParameter[5];
                sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = info.SID };
                sqlParams[1] = new SqlParameter("@Role", SqlDbType.VarChar, 50) { Value = info.Role };
                sqlParams[2] = new SqlParameter("@SupervisorSID", SqlDbType.NVarChar, 100) { Value = info.SupervisorID };
                sqlParams[3] = new SqlParameter("@Capabilities", SqlDbType.NVarChar, 100) { Value = info.Capabilities };
                sqlParams[4] = new SqlParameter("@IsActive", SqlDbType.Bit) { Value = info.IsActive };





                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure,
                                                    "UpdateUserDetails", sqlParams);
                result = 1;


            }
            catch (Exception ex)
            {
                result = -1;
                throw;
            }

            return result;

        }

        public List<UserEntity> GetDBUserRecords()
        {
            List<UserEntity> lstUserEntity = new List<UserEntity>();
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                   "GetDBUsers");
                while (reader.Read())
                {
                    var _userEntity = new UserEntity
                    {
                        SID = reader["SID"].ToString(),
                        UID =  reader["UID"].ToString(),
                        UserName = reader["Username"].ToString(),
                        SupervisorID =  reader["SupervisorSID"]==null?"":reader["SupervisorSID"].ToString(),
                        SupervisorName = reader["SupervisorName"] == null ? "" : reader["SupervisorName"].ToString(),                      
                        Role = reader["Role"].ToString(),
                        Capabilities = reader["Capabilities"] != null ? reader["Capabilities"].ToString() : "",
                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };

                    lstUserEntity.Add(_userEntity);
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lstUserEntity;
        }

        public List<UserEntity> GetDomainUserRecords()
        {
            List<UserEntity> lstUserEntity = new List<UserEntity>();
            try
            {
                string groupName = "Domain Users";
                PrincipalContext ctx = GetPrincipalContextByDomain(GetPrincipalDomain());
                GroupPrincipal grp = GroupPrincipal.FindByIdentity(ctx, IdentityType.SamAccountName, groupName);

                if (grp != null)
                {
                    foreach (UserPrincipal user in grp.GetMembers(false))
                    {
                        var _userEntity = new UserEntity
                        {
                            SID = user.Sid.ToString(),
                            UserName = user.SamAccountName.ToString(),
                            Role = groupName,
                            IsActive = Convert.ToBoolean(user.Enabled),
                            Capabilities = user.Description == null ? "" : user.Description,
                            IsInDB = IsUserExistInDB(user.Sid.ToString()),
                        };
                        lstUserEntity.Add(_userEntity);
                    }


                    grp.Dispose();
                    ctx.Dispose();
                }
                //foreach (var item in GetSystemGroups())
                //{
                //    string groupName = item.Text;
                //    using (var group = GroupPrincipal.FindByIdentity(GetPrincipalContext(), groupName))
                //    {
                //        var users = group.GetMembers(true);
                //        foreach (UserPrincipal user in users)
                //        {
                //            var _userEntity = new UserEntity
                //            {
                //                SID = user.Sid.ToString(),
                //                UserName = user.SamAccountName.ToString(),
                //                Role = groupName,
                //                IsActive = Convert.ToBoolean(user.Enabled),
                //                Capabilities = user.Description == null ? "" : user.Description,
                //            };
                //            lstUserEntity.Add(_userEntity);
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
            return lstUserEntity;
        }

        private string GetGroupName(string groupID)
        {
            try
            {
                PrincipalContext oPrincipalContext = GetPrincipalContext();
                GroupPrincipal oGroupPrincipal = GroupPrincipal.FindByIdentity(oPrincipalContext, IdentityType.Sid, groupID);

                return oGroupPrincipal.Name;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<CapabilitiesEntity> GetAllCapabilities()
        {
            List<CapabilitiesEntity> lstCapabilities = new List<CapabilitiesEntity>();

            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@tablename", SqlDbType.VarChar, 100) { Value = "BF_Capabilities" };



                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                    "GetAllValuesFromTable", sqlParams);
                while (reader.Read())
                {
                    var _capability = new CapabilitiesEntity
                    {
                        ID = reader["GUID"].ToString(),
                        Capability = reader["Capability"].ToString(),
                        ManagerRights = reader["ManagerRights"].ToString(),
                        SupervisorRights = reader["SupervisorRights"].ToString(),
                        InvestigatorRights = reader["InvestigatorRights"].ToString(),
                        OperatorRights = reader["OperatorRights"].ToString(),

                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };

                    lstCapabilities.Add(_capability);
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return lstCapabilities.FindAll(x => x.IsActive);
        }

        public void UpdateCapalities(string UserID, string Capabilities)
        {
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@userId", SqlDbType.NVarChar, 250) { Value = UserID };
                sqlParams[1] = new SqlParameter("@cabilities", SqlDbType.NVarChar, 250) { Value = Capabilities };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure,
                                                    "UpdateUserCapabilities", sqlParams);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        /// <summary>
        /// Method for getting the Capability Record using Capability Name
        /// </summary>
        /// <param name="CapabilityText"></param>
        /// <returns></returns>
        public CapabilitiesEntity GetCapabilityInfo(string CapabilityText)
        {
            CapabilitiesEntity _capability = null;
            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@CapabilityName", SqlDbType.NVarChar, 100) { Value = CapabilityText };



                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                    "GetCapabilityInfo", sqlParams);
                while (reader.Read())
                {
                    _capability = new CapabilitiesEntity
                    {
                        ID = reader["GUID"].ToString(),
                        Capability = reader["Capability"].ToString(),
                        ManagerRights = reader["ManagerRights"].ToString(),
                        SupervisorRights = reader["SupervisorRights"].ToString(),
                        InvestigatorRights = reader["InvestigatorRights"].ToString(),
                        OperatorRights = reader["OperatorRights"].ToString(),

                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };


                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return _capability;
        }

        public List<CapabilitiesEntity> GetUserCapabilities(string UserName)
        {
            List<CapabilitiesEntity> lstCapabilities = new List<CapabilitiesEntity>();

            try
            {
                var sqlParams = new SqlParameter[1];

                sqlParams[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 100) { Value = UserName };



                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,
                                                     "GetUserDetail", sqlParams);
                while (reader.Read())
                {
                    string CapabilityNames = reader["Capabilities"] == null ? "" : reader["Capabilities"].ToString();
                    if (CapabilityNames != "")
                    {
                        string[] CapabiltyNames = CapabilityNames.Split(',');
                        foreach (string Capability in CapabiltyNames)
                        {
                            var _Capability = GetCapabilityInfo(Capability);
                            if (_Capability != null) lstCapabilities.Add(_Capability);
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                throw;
            }
            return lstCapabilities;
        }
    }
}

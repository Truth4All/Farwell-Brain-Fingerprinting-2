﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Brainwave.Entities;
using System.IO;
using System.Xml.Serialization;

namespace Brainwave.Data
{
    public class CatalogDL : BaseDL
    {
        public DataTable GetCatalog()
        {
            //Source DataSet
            DataSet CatalogDS = new DataSet("Catalog");
            CatalogDS.ReadXmlSchema(SchemaDirectory + "Catalog.xsd");
            CatalogDS.ReadXml(SourceDirectory + "Catalog.xml");

            //Result DataTable
            var result = new DataTable();
            DataColumn column;
            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "GUID";
            result.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "JurisdictionID";
            result.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "CaseName";
            result.Columns.Add(column);

            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "CaseSummary";
            result.Columns.Add(column);

            column = new DataColumn();
            column.DataType = System.Type.GetType("System.Int32");
            column.ColumnName = "Serial";
            result.Columns.Add(column);

            DataRow row;

            foreach (DataRow dr in CatalogDS.Tables["Case"].Rows)
            {
                row = result.NewRow();
                row["GUID"] = dr["GUID"];
                row["JurisdictionID"] = dr["JurisdictionID"];
                row["Serial"] = dr["Serial"];
                row["CaseName"] = dr["CaseName"];
                row["CaseSummary"] = dr["CaseSummary"];
                result.Rows.Add(row);
            }
            return result;
        }

        public void CreateCatalogRecord(int Serial, string CaseGUID, string JurisdictionID, string CaseName, string CaseSummary, string UserSID,string UID)
        {
            string _UserName = Utility.GetUserNameFromSID(UserSID);
            if (ReadCatalogRecord(CaseGUID) == null)
            {
                var _GUID = new Guid();
                if (Guid.TryParse(CaseGUID.Trim(), out _GUID))
                {
                    var sqlParams = new SqlParameter[8];
                    sqlParams[0] = new SqlParameter("@GUID", SqlDbType.UniqueIdentifier) { Value = _GUID };
                    sqlParams[1] = new SqlParameter("@Serial", SqlDbType.Int) { Value = Serial };
                    sqlParams[2] = new SqlParameter("@JurisdictionID", SqlDbType.NVarChar, 50) { Value = JurisdictionID };
                    sqlParams[3] = new SqlParameter("@CaseName", SqlDbType.NVarChar, 100) { Value = CaseName };
                    sqlParams[4] = new SqlParameter("@CaseSummary", SqlDbType.NVarChar, 100) { Value = CaseSummary };
                    sqlParams[5] = new SqlParameter("@ModifiedBy", SqlDbType.NVarChar, 100) { Value = _UserName };
                    sqlParams[6] = new SqlParameter("@OwnedBy", SqlDbType.NVarChar, 100) { Value = _UserName };
                    sqlParams[7] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value =  new Guid( UID) };

                    SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CreateCatalogRecord", sqlParams);
                }
            }
            return;
        }

        public CatalogEntity ReadCatalogRecord(string GUID)
        {
            CatalogEntity _cr = new CatalogEntity();

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GUID", SqlDbType.NChar, 100) { Value = GUID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadCatalogRecord", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _cr.GUID              = reader["GUID"].ToString();
                        _cr.Serial            = (int)reader["Serial"];
                        _cr.Sync              = (bool)reader["Sync"];
                        _cr.IsActive          = (bool)reader["IsActive"];
                        _cr.IsDeleted         = (bool)reader["IsDeleted"];
                        _cr.IsLocked          = (bool)reader["IsLocked"];
                        _cr.JurisdictionID    = reader["JurisdictionID"].ToString();
                        _cr.CaseName          = reader["CaseName"].ToString();
                        _cr.CaseSummary       = reader["CaseSummary"].ToString();
                        _cr.ModifiedBy        = reader["ModifiedBy"].ToString();
                        _cr.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                        _cr.OwnedBy           = reader["OwnedBy"].ToString();
                        _cr.GID               = reader["GID"].ToString();
                        _cr.CreatedTimestamp  = reader["CreatedTimestamp"].ToString();
                        _cr.LockedBy          = reader["LockedBy"].ToString();
                    }
                    reader.Close();
                    return _cr;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<CatalogEntity> ReadCatalogRecords()
        {
            List<CatalogEntity> _crds = new List<CatalogEntity>();

            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadCatalogRecords");
                if (reader.HasRows)
                {
                    CatalogEntity _cr = null;

                    while (reader.Read())
                    {
                        _cr = new CatalogEntity();
                        _cr.GUID              = reader["GUID"].ToString();
                        _cr.Serial            = (int)reader["Serial"];
                        _cr.Sync              = (bool)reader["Sync"];
                        _cr.IsActive          = (bool)reader["IsActive"];
                        _cr.IsDeleted         = (bool)reader["IsDeleted"];
                        _cr.IsLocked          = (bool)reader["IsLocked"];
                        _cr.JurisdictionID    = reader["JurisdictionID"].ToString();
                        _cr.CaseName          = reader["CaseName"].ToString();
                        _cr.CaseSummary       = reader["CaseSummary"].ToString();
                        _cr.ModifiedBy        = reader["ModifiedBy"].ToString();
                        _cr.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                        _cr.OwnedBy           = reader["OwnedBy"].ToString();
                        _cr.GID               = reader["GID"].ToString();
                        _cr.CreatedTimestamp  = reader["CreatedTimestamp"].ToString();
                        _cr.LockedBy          = reader["LockedBy"].ToString();

                        _crds.Add(_cr);
                    }
                    reader.Close();
                    return _crds;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public void UpdateCatalogRecord(int Serial, string CaseGUID, string JurisdictionID, string CaseName, string CaseSummary, string UserSID)
        {
            try
            {
                string _UserName = Utility.GetUserNameFromSID(UserSID);

                var _GUID = new Guid();
                if (Guid.TryParse(CaseGUID, out _GUID))
                {
                    var sqlParams = new SqlParameter[9];
                    sqlParams[0] = new SqlParameter("@GUID", SqlDbType.UniqueIdentifier) { Value = _GUID };
                    sqlParams[1] = new SqlParameter("@Serial", SqlDbType.Int) { Value = Serial };
                    sqlParams[2] = new SqlParameter("@IsLocked", SqlDbType.Bit) { Value = 0 };
                    sqlParams[3] = new SqlParameter("@JurisdictionID", SqlDbType.NVarChar, 50) { Value = JurisdictionID };
                    sqlParams[4] = new SqlParameter("@CaseName", SqlDbType.NVarChar, 100) { Value = CaseName };
                    sqlParams[5] = new SqlParameter("@CaseSummary", SqlDbType.NVarChar, 100) { Value = CaseSummary };
                    sqlParams[6] = new SqlParameter("@ModifiedBy", SqlDbType.VarChar, 60) { Value = _UserName };
                    sqlParams[7] = new SqlParameter("@ModifiedTimestamp", SqlDbType.DateTime) { Value = DateTime.Now };
                    sqlParams[8] = new SqlParameter("@LockedBy", SqlDbType.VarChar, 60) { Value = "" };

                    SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UpdateCatalogRecord", sqlParams);
                }
            }
            catch (Exception)
            {
            }

        }

        public void UnlockCase(string CaseGUID, string UserName)
        {
            try
            {

                var sqlParams = new SqlParameter[3];
                sqlParams[0] = new SqlParameter("@GUID", SqlDbType.VarChar, 60) { Value = CaseGUID };
                sqlParams[1] = new SqlParameter("@ModifiedBy", SqlDbType.VarChar, 60) { Value = UserName };
                sqlParams[2] = new SqlParameter("@ModifiedTimestamp", SqlDbType.DateTime) { Value = DateTime.Now };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UnlockCatalogRecord", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public string AccessCatalogRecord(string CaseGUID, string UserSID)
        {
            string returnValue = "N";
            try
            {
                var _GUID = new Guid();
                if (Guid.TryParse(CaseGUID.Trim(), out _GUID))
                {
                    var sqlParams = new SqlParameter[2];
                    sqlParams[0] = new SqlParameter("@GUID", SqlDbType.UniqueIdentifier) { Value = _GUID };
                    sqlParams[1] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = UserSID };
                    SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "AccessCatalogRecord", sqlParams);
                    if (reader.HasRows)
                    {
                        reader.Read();
                        returnValue = reader["Access"].ToString();
                        reader.Close();
                        return returnValue;
                    }
                    return returnValue;
                }
                return returnValue;
            }
            catch (Exception)
            {
                return returnValue;
            }
        }

        public void LockCatalogRecord(string CaseGUID, string UserSID)
        {
            try
            {
                string _UserName = Utility.GetUserNameFromSID(UserSID);

                var _GUID = new Guid();
                if (Guid.TryParse(CaseGUID.Trim(), out _GUID))
                {
                    var sqlParams = new SqlParameter[2];
                    sqlParams[0] = new SqlParameter("@GUID", SqlDbType.UniqueIdentifier) { Value = _GUID };
                    sqlParams[1] = new SqlParameter("@LockedBy", SqlDbType.VarChar, 60) { Value = _UserName };

                    SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "LockCatalogRecord", sqlParams);
                }
            }
            catch (Exception)
            {
            }
        }

        public void DeleteCatalogRecord(string GUID)
        {
        }

        public void CreateCatalogCache()
        {
            DataSet Catalog = new DataSet();
            Catalog.ReadXmlSchema(SchemaDirectory + "Catalog.xsd");
            Catalog.WriteXml(SourceDirectory + "Catalog.xml");
        }

        public void UpdateCatalogCache()
        {
            //CatalogDL cl = new CatalogDL();
            List<CatalogEntity> _lc = new List<CatalogEntity>();
            _lc = ReadCatalogRecords();

            if (_lc != null)
            {
                DataSet Catalog = new DataSet();
                Catalog.ReadXmlSchema(SchemaDirectory + "Catalog.xsd");

                foreach (CatalogEntity ce in _lc)
                {
                    if (ce.IsDeleted == true) break;
                    DataRow newRecord = Catalog.Tables["Case"].NewRow();
                    newRecord["GUID"] = ce.GUID;
                    newRecord["Serial"] = ce.Serial;
                    newRecord["Sync"] = ce.Sync;
                    newRecord["IsActive"] = ce.IsActive;
                    newRecord["IsDeleted"] = ce.IsDeleted;
                    newRecord["IsLocked"] = ce.IsLocked;
                    newRecord["JurisdictionID"] = ce.JurisdictionID;
                    newRecord["CaseName"] = ce.CaseName;
                    newRecord["CaseSummary"] = ce.CaseSummary;
                    newRecord["ModifiedBy"] = ce.ModifiedBy;
                    newRecord["ModifiedTimestamp"] = ce.ModifiedTimestamp;
                    newRecord["OwnedBy"] = ce.OwnedBy;
                    newRecord["CreatedTimestamp"] = ce.CreatedTimestamp;
                    newRecord["LockedBy"] = ce.LockedBy;
                    Catalog.Tables["Case"].Rows.Add(newRecord);
                }
                Catalog.WriteXml(SourceDirectory + "Catalog.xml");
            }

        }

        public FolioMetaData GetFolioMetaData(string GUID, string UserSID)
        {
            CatalogDL cl = new CatalogDL();
            GroupDL dl = new GroupDL();

            FolioMetaData _fmd = new FolioMetaData();
            CatalogEntity _ce = new CatalogEntity();

            // Serial, IsActive, IsDeleted, IsLocked
            // CaseName, CaseSummary
            // ModifiedBy, ModifiedTimestamp
            // OwnedBy, CreatedTimestamp
            // LockedBy -> get it from BF_Catalog
            _ce = cl.ReadCatalogRecord(GUID);

            // Copy the Catalog object into FolioMetaData object
            Utility.CopyPropertyValues(_ce, _fmd);

            // Access Get it from BF_Catalog <> BF_Groups <> BF_GroupMembership
            _fmd.Access = cl.AccessCatalogRecord(GUID, UserSID);

            _fmd.GID = _ce.GID;
            _fmd.GroupName = dl.GetGroupName(_ce.GID);

            return _fmd;
        }

        public void UpdateCatalogWithFolio(int Serial, string CaseGUID, string JurisdictionID, string CaseName, string CaseSummary, string UserSID, string MachineName)
        {
            UserManagementDL UserData = new UserManagementDL();
            UserEntity UserObj = UserData.GetUserDetails(UserSID);


            //CatalogDL cl = new CatalogDL();
            if (ReadCatalogRecord(CaseGUID) == null)
            {
                // Create Catalog
                CreateCatalogRecord(Serial, CaseGUID, JurisdictionID, CaseName, CaseSummary, UserSID, UserObj.UID);
            }
            else
            {
                // Update Catalog
                UpdateCatalogRecord(Serial, CaseGUID, JurisdictionID, CaseName, CaseSummary, UserSID);
            }
        }

        public List<CatalogEntity> GetCasesForGroupId(string GID)
        {
            List<CatalogEntity> GroupsCases = new List<CatalogEntity>();
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetCasesForGID", sqlParams);
                if (reader.HasRows)
                {

                    CatalogEntity _cr = null;

                   
                        while (reader.Read())
                        {
                             _cr = new CatalogEntity();
                            _cr.GUID = reader["GUID"].ToString();
                            _cr.Serial = (int)reader["Serial"];
                            _cr.Sync = (bool)reader["Sync"];
                            _cr.IsActive = (bool)reader["IsActive"];
                            _cr.IsDeleted = (bool)reader["IsDeleted"];
                            _cr.IsLocked = (bool)reader["IsLocked"];
                            _cr.JurisdictionID = reader["JurisdictionID"].ToString();
                            _cr.CaseName = reader["CaseName"].ToString();
                            _cr.CaseSummary = reader["CaseSummary"].ToString();
                            _cr.ModifiedBy = reader["ModifiedBy"].ToString();
                            _cr.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                            _cr.OwnedBy = reader["OwnedBy"].ToString();
                            _cr.GID = reader["GID"].ToString();
                            _cr.CreatedTimestamp = reader["CreatedTimestamp"].ToString();
                            _cr.LockedBy = reader["LockedBy"].ToString();
                        GroupsCases.Add(_cr);
                        }
                       
                }
                reader.Close();
            }
            catch (Exception ex)
            {

                throw;
            }

            return GroupsCases;
        }

        public List<CatalogEntity> GetCasesForUser(string GID,string UID)
        {
            List<CatalogEntity> GroupsCases = new List<CatalogEntity>();
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };
                sqlParams[1] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value = new Guid(UID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetCasesOwnedByUID", sqlParams);
                if (reader.HasRows)
                {

                    CatalogEntity _cr = null;


                    while (reader.Read())
                    {
                        _cr = new CatalogEntity();
                        _cr.GUID = reader["GUID"].ToString();
                        _cr.Serial = (int)reader["Serial"];
                        _cr.Sync = (bool)reader["Sync"];
                        _cr.IsActive = (bool)reader["IsActive"];
                        _cr.IsDeleted = (bool)reader["IsDeleted"];
                        _cr.IsLocked = (bool)reader["IsLocked"];
                        _cr.JurisdictionID = reader["JurisdictionID"].ToString();
                        _cr.CaseName = reader["CaseName"].ToString();
                        _cr.CaseSummary = reader["CaseSummary"].ToString();
                        _cr.ModifiedBy = reader["ModifiedBy"].ToString();
                        _cr.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                        _cr.OwnedBy = reader["OwnedBy"].ToString();
                        _cr.GID = reader["GID"].ToString();
                        _cr.CreatedTimestamp = reader["CreatedTimestamp"].ToString();
                        _cr.LockedBy = reader["LockedBy"].ToString();
                        GroupsCases.Add(_cr);
                    }

                }
                reader.Close();
            }
            catch (Exception ex)
            {

                throw;
            }

            return GroupsCases;
        }

        public void UpdateGIDForCase(string GID,string CaseId)
        {
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };
                sqlParams[1] = new SqlParameter("@CaseId", SqlDbType.UniqueIdentifier) { Value = new Guid(CaseId) };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UpdateGIDForCatalog", sqlParams);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

    }
}

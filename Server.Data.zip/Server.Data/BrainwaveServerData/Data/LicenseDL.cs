﻿using Brainwave.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;

namespace Brainwave.Data
{
    public class LicenseDL : BaseDL
    {
        public double UpdateLoopPeriod = 5;

        // Reads the number of test license, return 0 if tampered
        public int ReadValidTestLicenseCount()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckTestLicense", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return Convert.ToInt32(parm.Value);
        }

        // Debit Test licenses, recompute the tamper protection value
        public bool DebitTestLicense(int count)
        {
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@Count", SqlDbType.Int) { Value = count };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure,
                                                    "DebitTestLicense", sqlParams);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        // Read the number of user licenses, return -1 if tampered
        public int ReadValidUserLicenseCount()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckUserLicense", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return Convert.ToInt32(parm.Value);
        }

        // Check for issuse licenses attributed to machines.
        public int CheckIssuedUserLicence()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckIssuedUserLicence", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return Convert.ToInt32(parm.Value);
        }

        // Check for Application license expiration (true if expired)
        public bool CheckForApplicationLicenseExpiration()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckForApplicationLicenseExpiration", conn); // return 0 = not expired, return 1 if expired or tampered
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            int status = Convert.ToInt32(parm.Value);
            if (status == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Check for user license expiration (true if expired)
        public bool CheckForUserLicenseExpiration()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckForUserLicenseExpiration", conn); // return 0 = not expired, return 1 if expired or tampered
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            int status = Convert.ToInt32(parm.Value);
            if (status == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Check for Test license expiration (true if expired)
        public bool CheckForTestLicenseExpiration()
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("CheckForUserLicenseExpiration", conn); // return 0 = not expired, return 1 if expired or tampered
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
            parm.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            int status = Convert.ToInt32(parm.Value);
            if(status == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void PurgeIssuedUserLicense()
        {
            List<MachineEntity> machines = ReadMachineRecords();
            foreach (MachineEntity machine in machines)
            {
                DateTime lastModified = Convert.ToDateTime(machine.ModifiedTimestamp);

                if (lastModified.Add(TimeSpan.FromMinutes(UpdateLoopPeriod * 2.5)) < DateTime.Now)
                {
                    machine.OnlineStatus = "offline";
                    machine.LicenseStatus = "expired";
                    machine.ModifiedTimestamp = DateTime.Now.ToString();
                    UpdateMachineRecord(machine);
                }
            }
        }

        public UserEntity GetUserRecord(string userSID)
        {
            UserEntity _userRecord = new UserEntity();

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UserSID", SqlDbType.NChar, 100) { Value = userSID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadUserRecord", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _userRecord.SID = reader["SID"].ToString();
                        _userRecord.UserName = reader["Username"].ToString();
                        _userRecord.Role = reader["Role"].ToString();
                        _userRecord.Capabilities = reader["Capabilities"].ToString();
                        _userRecord.SupervisorID = reader["SupervisorSID"].ToString();
                    }
                    reader.Close();
                    return _userRecord;
                }
                return null;
            }
            catch (Exception  ex)
            {
                return null;
            }
        }

        public void CreateMachineRecord(MachineEntity machine)
        {
            if (ReadMachineRecord(machine.MachineName) == null)
            {

                var sqlParams = new SqlParameter[6];
                sqlParams[0] = new SqlParameter("@MachineName", SqlDbType.NChar, 100) { Value = machine.MachineName.Trim() };
                sqlParams[1] = new SqlParameter("@MachineIP", SqlDbType.NChar, 100) { Value = machine.MachineIP.Trim() };
                sqlParams[2] = new SqlParameter("@UserSID", SqlDbType.VarChar, 60) { Value = machine.UserSID.Trim() };
                sqlParams[3] = new SqlParameter("@OnlineStatus", SqlDbType.NChar, 10) { Value = machine.OnlineStatus.Trim() };
                sqlParams[4] = new SqlParameter("@LicenseStatus", SqlDbType.NChar, 10) { Value = machine.LicenseStatus.Trim() };
                sqlParams[5] = new SqlParameter("@ModifiedTimestamp", SqlDbType.DateTime) { Value = DateTime.Now };

                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CreateMachineRecord", sqlParams);
            }
            return;
        }

        public MachineEntity ReadMachineRecord(string machineName)
        {
            MachineEntity _machine = new MachineEntity();

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@MachineName", SqlDbType.NChar, 100) { Value = machineName };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadMachineRecord", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _machine.MachineName = reader["MachineName"].ToString();
                        _machine.MachineIP = reader["MachineIP"].ToString();
                        _machine.UserSID = reader["UserSID"].ToString();
                        _machine.OnlineStatus = reader["OnlineStatus"].ToString();
                        _machine.LicenseStatus = reader["LicenseStatus"].ToString();
                        _machine.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                    }
                    reader.Close();
                    return _machine;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<MachineEntity> ReadMachineRecords()
        {
            List<MachineEntity> _machines = new List<MachineEntity>();
            UserManagementDL UserData = new UserManagementDL();
            UserEntity UserInfo = null;
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadMachineRecords");
                if (reader.HasRows)
                {
                    MachineEntity _machine = null;

                    while (reader.Read())
                    {
                        _machine = new MachineEntity();
                        _machine.MachineName = reader["MachineName"].ToString();
                        _machine.MachineIP = reader["MachineIP"].ToString();
                        _machine.UserSID = reader["UserSID"].ToString();

                        UserInfo = UserData.GetUserDetails(_machine.UserSID);
                        _machine.UserName = UserInfo.UserName;
                        _machine.OnlineStatus = reader["OnlineStatus"].ToString();
                        _machine.LicenseStatus = reader["LicenseStatus"].ToString();
                        _machine.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();

                        _machines.Add(_machine);
                    }
                    reader.Close();
                    return _machines;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void UpdateMachineRecord(MachineEntity machine)
        {
            var sqlParams = new SqlParameter[6];
            sqlParams[0] = new SqlParameter("@MachineName", SqlDbType.NChar, 100) { Value = machine.MachineName.Trim() };
            sqlParams[1] = new SqlParameter("@MachineIP", SqlDbType.NChar, 100) { Value = machine.MachineIP.Trim() };
            sqlParams[2] = new SqlParameter("@UserSID", SqlDbType.VarChar, 60) { Value = machine.UserSID.Trim() };
            sqlParams[3] = new SqlParameter("@OnlineStatus", SqlDbType.NChar, 10) { Value = machine.OnlineStatus.Trim() };
            sqlParams[4] = new SqlParameter("@LicenseStatus", SqlDbType.NChar, 10) { Value = machine.LicenseStatus.Trim() };
            sqlParams[5] = new SqlParameter("@ModifiedTimestamp", SqlDbType.DateTime) { Value = DateTime.Now };

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UpdateMachineRecord", sqlParams);
        }


       

    }
}

﻿using Brainwave.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Brainwave.Data
{
    public class LicenseManagementDL : BaseDL
    {
        public int AddLicenseInfo(LicenseEntity info)
        {
            int result = 0;
            try
            {
                var sqlParams = new SqlParameter[10];

                sqlParams[0] = new SqlParameter("@IsActive", SqlDbType.Bit) { Value = info.IsActive };
                sqlParams[1] = new SqlParameter("@IsDeleted", SqlDbType.Bit) { Value = info.IsDeleted };
                sqlParams[2] = new SqlParameter("@ProductID", SqlDbType.Int) { Value = info.ProductID };
                sqlParams[3] = new SqlParameter("@ProductName", SqlDbType.VarChar, 255) { Value = info.ProductName };
                sqlParams[4] = new SqlParameter("@LicenseCode", SqlDbType.VarChar, 255) { Value = info.LicenseCode.Trim() };
                sqlParams[5] = new SqlParameter("@LicenseExpiration", SqlDbType.DateTime) { Value = info.LicenseExpiration };
                sqlParams[6] = new SqlParameter("@OriginalCount", SqlDbType.Int) { Value = info.OriginalCount };
                sqlParams[7] = new SqlParameter("@LicenseCount", SqlDbType.Int) { Value = info.LicenseCount };
                sqlParams[8] = new SqlParameter("@ActivationCode", SqlDbType.Int) { Value = info.ActivationCode };
                sqlParams[9] = new SqlParameter("@MachineID", SqlDbType.VarChar,255) { Value = info.MachineId };

                SqlHelper.ExecuteNonQuery(ConnectionString, "AddLicenseInfo", sqlParams);
                result = 1;
            }
            catch (Exception ex)
            {
                result = 0;
                throw;
            }
            return result;
        }

        public List<LicenseEntity> GetLicenseRecords()
        {
            List<LicenseEntity> _LinceseList = new List<LicenseEntity>();
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetLicenseRecords");
                if (reader.HasRows)
                {
                    LicenseEntity _LicenseEntity = null;

                    while (reader.Read())
                    {
                        _LicenseEntity = new LicenseEntity();

                        _LicenseEntity.GUID = reader["GUID"].ToString();
                        _LicenseEntity.Serial = reader["Serial"].ToString();
                        _LicenseEntity.Sync = reader["Sync"].ToString();
                        _LicenseEntity.ProductID = Convert.ToInt32(reader["ProductID"]);
                        _LicenseEntity.ProductName = reader["ProductName"].ToString();
                        _LicenseEntity.LicenseCode = reader["LicenseCode"].ToString();
                        _LicenseEntity.ActivationCode = reader["ActivationCode"].ToString();
                        _LicenseEntity.LicenseExpiration = System.DBNull.Value.Equals(reader["LicenseExpiration"]) ? DateTime.MinValue : Convert.ToDateTime(reader["LicenseExpiration"]);
                        _LicenseEntity.OriginalCount = Convert.ToInt32(reader["OriginalCount"]);
                        _LicenseEntity.LicenseCount = Convert.ToInt32(reader["LicenseCount"]);
                        _LicenseEntity.OwnedBy = reader["OwnedBy"].ToString();
                        _LicenseEntity.CreatedTimestamp = reader["CreatedTimestamp"].ToString();
                        _LicenseEntity.ModifiedBy = reader["ModifiedBy"].ToString();
                        _LicenseEntity.ModifiedTimestamp = reader["ModifiedTimestamp"].ToString();
                        _LicenseEntity.LockedBy = reader["LockedBy"].ToString();
                        _LicenseEntity.IsActive = Convert.ToBoolean(reader["IsActive"]);
                        _LicenseEntity.IsDeleted = Convert.ToBoolean(reader["IsDeleted"]);
                        _LicenseEntity.LockedBy = reader["LockedBy"].ToString();
                        _LicenseEntity.IsLocked = Convert.ToBoolean(reader["IsLocked"]);

                        _LinceseList.Add(_LicenseEntity);
                    }
                    reader.Close();
                    return _LinceseList;
                }
                return null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public Dictionary<string, int> GetLicenseSummary()
        {
            Dictionary<string, int> LicenseSummary = new Dictionary<string, int>();
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure,"GetLicenseSummaryInfo");
                while (reader.Read())
                {
                    LicenseSummary.Add("ApplicationLicenseTotal", Convert.ToInt32(reader["ApplicationLicenseTotal"]));
                    LicenseSummary.Add("ApplicationLicenseRemaining", Convert.ToInt32(reader["ApplicationLicenseRemaining"]));
                    LicenseSummary.Add("UserLicenseTotal", Convert.ToInt32(reader["UserLicenseTotal"]));
                    LicenseSummary.Add("UserLicensePending", Convert.ToInt32(reader["UserLicensePending"]));
                    LicenseSummary.Add("TestLicenseTotal", Convert.ToInt32(reader["TestLicenseTotal"]));
                    LicenseSummary.Add("TestLicenseRemaining", Convert.ToInt32(reader["TestLicenseRemaining"]));
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return LicenseSummary;
        }
    }
}

﻿using System;
using System.Collections.ObjectModel;
using System.DirectoryServices.AccountManagement;
using System.Text.RegularExpressions;

namespace Brainwave.Data
{
    public static class Utility
    {

        public static string GetUserNameFromSID(string SID)
        {
            try
            {
                PrincipalContext objPrincipalContext = GetPrincipalContext();
                UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, IdentityType.Sid, SID);
                if (objUserPrincipal != null)
                {
                    return objUserPrincipal.Name;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
                //throw;
            }
            return string.Empty;
        }

        public static string GetSIDFromUserName(string userName)
        {
            try
            {
                PrincipalContext objPrincipalContext = GetPrincipalContext();
                UserPrincipal objUserPrincipal = UserPrincipal.FindByIdentity(objPrincipalContext, userName);
                if (objUserPrincipal != null)
                {
                    return objUserPrincipal.Sid.ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
            return string.Empty;
        }

        private static PrincipalContext GetPrincipalContext()
        {
            try
            {
                PrincipalContext objPrincipalContext = new PrincipalContext(ContextType.Domain, null, null, null, null);
                return objPrincipalContext;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public static bool IsNumber(string text)
        {
            Regex regex = new Regex("[^0-9.-]+"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        public static void CopyPropertyValues(object source, object destination)
        {
            var destProperties = destination.GetType().GetProperties();
            foreach (var sourceProperty in source.GetType().GetProperties())
            {
                foreach (var destProperty in destProperties)
                {
                    if (destProperty.Name == sourceProperty.Name &&
                destProperty.PropertyType.IsAssignableFrom(sourceProperty.PropertyType))
                    {
                        destProperty.SetValue(destination, sourceProperty.GetValue(
                            source, new object[] { }), new object[] { });
                        break;
                    }
                }
            }
        }

    }

    public static class ObservableCollectionExtensions
    {
        public static void RemoveAll<T>(this ObservableCollection<T> collection)
        {
            for (int i = collection.Count - 1; i >= 0; i--)
            {
                collection.RemoveAt(i);
            }
        }
    }
}

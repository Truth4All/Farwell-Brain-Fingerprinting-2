﻿using Brainwave.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

namespace Brainwave.Data
{
    public class CommonDL : BaseDL
    {
        public bool CheckApplicationKeyActivation()
        {
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetAppLicenseKey");
                if (reader.HasRows)
                {
                    return true;  // Key Exists
                }
                else
                {
                    return false; // No Key
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public bool CheckUserKeyActivation()
        {
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetUserLicenseKey");
                if (reader.HasRows)
                {
                    return true;  // Key Exists
                }
                else
                {
                    return false; // No Key
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public bool CheckTestKeyActivation()
        {
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetTestLicenseKey");
                if (reader.HasRows)
                {
                    return true;  // Key Exists
                }
                else
                {
                    return false; // No Key
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public bool DoesTestsLicenseExpired()
        {
            try
            {
                object o = SqlHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, "DoesTestsLicenseExpired");
                var count = (int)o;
                if (count == 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public bool DoesAnyTestLicensesLeft()
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("CheckTestLicense", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter parm = new SqlParameter("@ReturnedValue", SqlDbType.Int);
                parm.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(parm);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                int Val = Convert.ToInt32(parm.Value);
                if (Val > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public string GetRegistryEntry(string KeyGuid)
        {
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@KeyClassGUID", SqlDbType.NVarChar, 255) { Value = KeyGuid };
                sqlParams[1] = new SqlParameter("@KeyValue", SqlDbType.VarChar, 255);
                sqlParams[1].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "GetRegistryEntry", sqlParams);
                return sqlParams[1].Value.ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
            return string.Empty;
        }

        public string GetUserRegistryEntry(string KeyGuid)
        {
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@KeyClassGUID", SqlDbType.NVarChar, 255) { Value = KeyGuid };
                sqlParams[1] = new SqlParameter("@KeyValue", SqlDbType.NVarChar, 255);
                sqlParams[1].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "GetUserRegistryEntry", sqlParams);
                return sqlParams[1].Value.ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
            return string.Empty;
        }

        public void UpdateRegistryEntry(string KeyGuid, string KeyValue)
        {
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@KeyClassGUID", SqlDbType.NVarChar, 255) { Value = KeyGuid };
                sqlParams[1] = new SqlParameter("@KeyValue", SqlDbType.NVarChar, 255) { Value = KeyValue };
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "UpdateRegistryEntry", sqlParams);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string[] GetApplicationLicenseKey()
        {
            string[] keyData = new string[3];
            try
            {
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetAppLicenseKey");
                while (reader.Read())
                {
                    keyData[0] = reader["LicenseCode"].ToString();
                    keyData[1] = (Convert.ToDateTime(reader["LicenseExpiration"])).ToString();
                    keyData[2] = reader["ActivationCode"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return keyData;
        }

        public string GetRoleOfLoggedInUser()
        {
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@Role", SqlDbType.VarChar, 100);
                sqlParams[0].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "GetRoleOfLoggedInUser", sqlParams);
                string[] arReturnParms = new string[1];
                arReturnParms[0] = sqlParams[0].Value.ToString();
                return arReturnParms[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            return "";
        }

        public int GetUserCount()
        {
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UserCount", SqlDbType.Int);
                sqlParams[0].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "GetUserCount", sqlParams);
                int[] arReturnParms = new int[1];
                arReturnParms[0] = Convert.ToInt32(sqlParams[0].Value);
                return arReturnParms[0];
            }
            catch (Exception ex)
            {
                throw;
            }
            return 0;
        }

        //public void LoadUserInitialSetting()
        //{
        //    try
        //    {
        //        using (SqlConnection con = new SqlConnection(ConnectionString))
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = con;
        //            cmd.CommandText = "InitUserProfile";
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.ExecuteNonQuery();
        //            con.Close();
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //      throw;
        //    }
        //}

        /// <summary>
        /// Method which returns the Langauges which has the IsTranslated flag true
        /// </summary>
        /// <returns></returns>

        public bool IsRowExists(string GUID, string TableName)
        {
            try
            {
                var sqlParams = new SqlParameter[3];
                sqlParams[0] = new SqlParameter("@tablename", SqlDbType.VarChar, 100) { Value = TableName };
                sqlParams[1] = new SqlParameter("@guid", SqlDbType.VarChar, 255) { Value = GUID };
                sqlParams[2] = new SqlParameter("@TotalCnt", SqlDbType.Int);
                sqlParams[2].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "IsGUIDExists", sqlParams);
                int RowCount = Convert.ToInt32(sqlParams[2].Value);
                if (RowCount > 0) return true;
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public UserEntity GetUserInfo(string UserName)
        {
            UserEntity _userEntity = null;
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 100) { Value = UserName };
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetUserDetail", sqlParams);
                while (reader.Read())
                {
                    _userEntity = new UserEntity
                    {
                        SID = reader["SID"].ToString(),
                        UserName = reader["Username"].ToString(),
                        SupervisorID = reader["SupervisorSID"].ToString(),
                        Role = reader["Role"].ToString(),
                        Capabilities = reader["Capabilities"] != null ? reader["Capabilities"].ToString() : "",
                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return _userEntity;
        }

        public List<CapabilitiesEntity> GetUserCapabilities(string UserName)
        {
            List<CapabilitiesEntity> lstCapabilities = new List<CapabilitiesEntity>();
            try
            {
                var sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 100) { Value = UserName };
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetUserDetail", sqlParams);
                while (reader.Read())
                {
                    string CapabilityNames = reader["Capabilities"] == null ? "" : reader["Capabilities"].ToString();
                    if (CapabilityNames != "")
                    {
                        string[] CapabiltyNames = CapabilityNames.Split(',');
                        foreach (string Capability in CapabiltyNames)
                        {
                            var _Capability = GetCapabilityInfo(Capability);
                            if (_Capability != null) lstCapabilities.Add(_Capability);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return lstCapabilities;
        }

        /// <summary>
        /// Method for getting the Capability Record using Capability Name
        /// </summary>
        /// <param name="CapabilityText"></param>
        /// <returns></returns>
        public CapabilitiesEntity GetCapabilityInfo(string CapabilityText)
        {
            CapabilitiesEntity _capability = null;
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@CapabilityName", SqlDbType.NVarChar, 100) { Value = CapabilityText };
                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetCapabilityInfo", sqlParams);
                while (reader.Read())
                {
                    _capability = new CapabilitiesEntity
                    {
                        ID = reader["GUID"].ToString(),
                        Capability = reader["Capability"].ToString(),
                        ManagerRights = reader["ManagerRights"].ToString(),
                        SupervisorRights = reader["SupervisorRights"].ToString(),
                        InvestigatorRights = reader["InvestigatorRights"].ToString(),
                        OperatorRights = reader["OperatorRights"].ToString(),
                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return _capability;
        }

    }
}

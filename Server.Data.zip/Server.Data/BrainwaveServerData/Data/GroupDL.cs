﻿using Brainwave.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;

namespace Brainwave.Data
{
    public class GroupDL : BaseDL
    {
        public string GetUIDFromSID(string SID)
        {
            string _UID = "";

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@SID", SqlDbType.VarChar, 60) { Value = SID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetUIDFromSID", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _UID = reader["GUID"].ToString();
                    }
                    reader.Close();
                    return _UID;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetSIDFromUID(string UID)
        {
            string _SID = "";

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value = UID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetSIDFromUID", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _SID = reader["SID"].ToString();
                    }
                    reader.Close();
                    return _SID;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #region Groups
        public List<GroupEntity> GetMyGroups(string UID)
        {
            List<GroupEntity> _gl = new List<GroupEntity>();

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value = UID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "ReadGroupRecords");
                if (reader.HasRows)
                {
                    GroupEntity _gr = null;

                    while (reader.Read())
                    {
                        _gr = new GroupEntity();
                        _gr.GID = reader["GID"].ToString();
                        _gr.GroupName = reader["GroupName"].ToString();
                        _gr.OwnerUID = reader["OwnerUID"].ToString();

                        _gl.Add(_gr);
                    }
                    reader.Close();
                    return _gl;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string CreateGroup(string GroupName, string OwnerUID)
        {

            var sqlParams = new SqlParameter[3];
            Guid gid = Guid.NewGuid();
            sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = gid };
            sqlParams[1] = new SqlParameter("@GroupName", SqlDbType.NVarChar, 100) { Value = GroupName };
            sqlParams[2] = new SqlParameter("@OwnerUID", SqlDbType.UniqueIdentifier) { Value = new Guid(OwnerUID)  };

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "CreateGroup", sqlParams);

             return gid.ToString();
        }

        public string GetGroupName(string GID)
        {
            string _groupName = "";

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = GID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetGroupName", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _groupName = reader["GroupName"].ToString();
                    }
                    reader.Close();
                    return _groupName;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetGroupOwner(string GID)
        {
            string _ownerUID = "";

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = GID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetGroupOwner", sqlParams);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        _ownerUID = reader["OwnerUID"].ToString();
                    }
                    reader.Close();
                    return _ownerUID;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public void DeleteGroup(string GID)
        {
            var sqlParams = new SqlParameter[1];
            sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid( GID) };
            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "DeleteGroup", sqlParams);
        }
        #endregion 

        #region Group Membership
        public List<GroupMembershipEntity> GetMembership(string GID)
        {
            List<GroupMembershipEntity> _gml = new List<GroupMembershipEntity>();

            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = GID };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetMembership");
                if (reader.HasRows)
                {
                    GroupMembershipEntity _gr = null;

                    while (reader.Read())
                    {
                        _gr = new GroupMembershipEntity();
                        _gr.GID = reader["GID"].ToString();
                        _gr.MemberUID = reader["MemberUID"].ToString();
                        _gr.Access = reader["Access"].ToString();

                        _gml.Add(_gr);
                    }
                    reader.Close();
                    return _gml;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public void AddMembership(string GID, string MemberUID, string Access)
        {
            var sqlParams = new SqlParameter[3];
            sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };
            sqlParams[1] = new SqlParameter("@MemberUID", SqlDbType.UniqueIdentifier) { Value = new Guid(MemberUID) };
            sqlParams[2] = new SqlParameter("@Access", SqlDbType.NChar, 10) { Value = Access };

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "AddMembership", sqlParams);
        }

        public void DeleteMembership(string GID, string MemberUID)
        {
            var sqlParams = new SqlParameter[2];
            sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };
            sqlParams[1] = new SqlParameter("@MemberUID", SqlDbType.UniqueIdentifier) { Value = new Guid(MemberUID) };

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "DeleteMembership", sqlParams);
        }


        /// <summary>
        /// Gets groups owned by selected User
        /// </summary>
        /// <param name="UID"></param>
        /// <returns></returns>
        public List<GroupEntity> GetGroupsOwnedByUser(string UID)
        {
            List<GroupEntity> GroupsOwnedByUser = new List<GroupEntity>();
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value = new Guid(UID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetGroupsOwnedByUser",sqlParams);
                if (reader.HasRows)
                {

                    GroupEntity _gr = null;

                    while (reader.Read())
                    {
                        _gr = new GroupEntity();
                        _gr.GID = reader["GID"].ToString();
                        _gr.GroupName = reader["GroupName"].ToString();

                        GroupsOwnedByUser.Add(_gr);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return GroupsOwnedByUser;
        }

        public List<GroupMembershipEntity> GetGroupsUsers(string GID)
        {
            List<GroupMembershipEntity> GroupsUser = new List<GroupMembershipEntity>();
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetGroupUsers", sqlParams);
                if (reader.HasRows)
                {

                    GroupMembershipEntity _gr = null;

                    while (reader.Read())
                    {
                        _gr = new GroupMembershipEntity();
                        _gr.MemberUID = reader["MemberUID"].ToString();
                        _gr.MemberName = reader["Username"].ToString();
                        _gr.Access = reader["Access"].ToString();
                        GroupsUser.Add(_gr);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return GroupsUser;
        }

        public void DeleteGroupMemberships(string GID)
        {
            var sqlParams = new SqlParameter[1];
            sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };

            SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, "DeleteGroupMembers", sqlParams);
        }

        public GroupEntity GetDefaultGroupForUser(string UID)
        {
            GroupEntity _gr = null;
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@UID", SqlDbType.UniqueIdentifier) { Value = new Guid(UID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetDefaultGroup", sqlParams);
                if (reader.HasRows)
                {

                   

                    while (reader.Read())
                    {
                        _gr = new GroupEntity();
                        _gr.GID = reader["GID"].ToString();

                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return _gr;
        }
        public List<UserEntity> GetUnassingedUsers(string GID)
        {
            List<UserEntity> Users = new List<UserEntity>();
            try
            {
                var sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@GID", SqlDbType.UniqueIdentifier) { Value = new Guid(GID) };

                SqlDataReader reader = SqlHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, "GetUsersNotInSelectedGroup", sqlParams);
                if (reader.HasRows)
                {

                    UserEntity _gr = null;

                    while (reader.Read())
                    {
                        _gr = new UserEntity();
                        _gr.UID = reader["UID"].ToString();
                        _gr.UserName = reader["Username"].ToString();
                       
                        Users.Add(_gr);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return Users;
        }

        #endregion
    }
}

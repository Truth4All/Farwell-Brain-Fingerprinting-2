﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Brainwave.Data
{
    public class ServerInfoDL
    {
        public static string GetServerHostName()
        {
            return System.Environment.MachineName.ToString();
        }

        public static string GetServerIP()
        {
            var localIpAddress = Dns.GetHostAddresses(Dns.GetHostName()).First(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            return localIpAddress.ToString();
        }
    }
}

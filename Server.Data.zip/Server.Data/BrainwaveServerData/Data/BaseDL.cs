﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brainwave.Data
{
    public abstract class BaseDL
    {
        public string SchemaDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\BrainwaveServer\config\";
        public string SourceDirectory = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + @"\BrainwaveServer\documents\";
        public Configuration CustomConfig;

        public string ConnectionString
        {
            get
            {
                string configFilePath = string.Format(@"{0}Brainwave.config", SchemaDirectory);

                ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
                configFileMap.ExeConfigFilename = configFilePath;
                CustomConfig = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);

                return CustomConfig.ConnectionStrings.ConnectionStrings["BrainwaveDBConnectionString"].ToString();
            }
        }

    }
}

﻿using System;
using System.IO;
using System.Threading;
using FTD2XX_NET;
using System.Windows.Forms;

namespace BWS.Brainwave.HeadsetStatus
{
    public partial class EEGStream
    {
        public class DataBlock
        {
            //Read
            private int[] ChannelSet = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 0, 0, 0, 0, 0 };
            private int[] ResolutionSet = { 24, 16 };
            private int[] GainSet = { 1, 2, 3, 4, 6, 8, 12 };
            private int[] intArrayLeadOnOff = { 1, 2, 4, 8, 16, 32, 64, 128, 1, 2, 4, 8, 16, 32, 64, 128 };
            //private float floatMathPow = (float)Math.Pow(2, 31) - 1; // ADS 1298 TI manual
            private float floatMathPow = (float)Math.Pow(2, 32); // Quick-20 Raw Access.docx document

            private double[] m_Data;             //Calculated EEG values

            int intMin = 0;
            int intMax = 15;
            int intGetCounter;
            int intGetDataLose = 0;
            int intLostByte = 0;

            public double this[int pos]
            {
                get { return m_Data[pos]; }
            }

            public void ReadHeaderAndCheckCounter(FTDI sr)
            {
                if (sr != null)
                {
                    // wait for xFF header
                    while (ReadByte(sr) != 255) { };
                }
            }

            /// <summary>
            /// Receives one sample data point for each channel and place it in m_Data[channel#]
            /// Presently ignores accelerometers, battery, impedance checks and triggers
            /// </summary>
            /// <param name="sr"></param>
            /// <param name="m_Channel"></param>
            /// <param name="m_SampleRate"></param>
            /// <param name="m_Resolution"></param>
            /// <param name="m_PreAmpGain"></param>
            /// <param name="m_RefVoltage"></param>
            public void readData(FTDI sr, int m_Channel, int m_SampleRate, int m_Resolution, int m_PreAmpGain, float m_RefVoltage, double alpha)
            {
                m_Data = new double[m_Channel];

                int _msb;
                int _lsb2;
                int _lsb1;

                int temp;

                // Packet header detection
                while (ReadByte(sr) != 0xFF) { };

                // Read the packet counter
                intGetCounter = ReadByte(sr);

                // For the number of EEG channels
                for (int j = 0; j < m_Channel; j++)
                {
                    // Read 3 bytes per channel (we have fix resolution here)
                    _msb  = ReadByte(sr);
                    _lsb2 = ReadByte(sr);
                    _lsb1 = ReadByte(sr);

                    temp = (_msb << 24) | (_lsb2 << 17) | (_lsb1 << 10);     // repack into int32

                    m_Data[j] = (double)((temp * m_RefVoltage) / floatMathPow); // Conversion to volts

                    m_Data[j] = DCblock.DCremove(j, m_Data[j], alpha); // DC Blocker

                    // Square wave generator based on packet counter and generating +/- 5 microvolts
                    //if (j == 2) { m_Data[j] = 0.000005F; }
                    //if (j == 2 && intGetCounter > 68 ) { m_Data[j] = -0.000005F; }
                }

                // Read 3 bytes for A2 (we have fix resolution here) 
                _msb = ReadByte(sr);
                _lsb2 = ReadByte(sr);
                _lsb1 = ReadByte(sr);

                // For the 3 accelerometer channels
                for (int j = 0; j < 3; j++)
                {
                    // Read 3 bytes perchannel (we have fix resolution here)
                    _msb = ReadByte(sr);
                    _lsb2 = ReadByte(sr);
                    _lsb1 = ReadByte(sr);

                    temp = (_msb << 24) | (_lsb2 << 17) | (_lsb1 << 10); //repack into int32
                }

                //read packet tail
                int impStatus = ReadByte(sr);

                //read battery voltage
                int batteryByte = ReadByte(sr);

                //read the trigger event byte
                int triggerMSB = ReadByte(sr);
                int triggerLSB = ReadByte(sr);
            }

            public void resetDataLoss()
            {
                intGetDataLose = 0;
            }
        }

        private int m_Channel, m_SampleRate, m_Resolution, m_Gain, m_PreAmpGain;
        private float m_RefVoltage;
        private double m_Alpha;
        public int datalost;
        public int saturation;
        public float[] offset;

        public EEGStream(int inChannel, int inSampleRate, int inResolution, int inGain, int inPreAmpGain, float inRefVoltage, double alpha)
        {
            m_Channel = inChannel;
            m_SampleRate = inSampleRate;
            m_Resolution = inResolution;
            m_Gain = inGain;
            m_PreAmpGain = inPreAmpGain;
            m_RefVoltage = inRefVoltage;
            m_Alpha = alpha;
            m_Data = new DataBlock();
            //offset = new float[m_Channel];


        }

        public FTDI connectBT(string address, string NoConnectMessage) // Connect to Cognionics
        {
            FTDI.FT_STATUS ftStatus = FTDI.FT_STATUS.FT_OK;
            FTDI myFtdiDevice = new FTDI();

            // Open first device in our list by serial number
            ftStatus = myFtdiDevice.OpenBySerialNumber(address);
            if (ftStatus == FTDI.FT_STATUS.FT_OK)
            {
                ftStatus = myFtdiDevice.SetBaudRate(3000000);
                if (ftStatus == FTDI.FT_STATUS.FT_OK)
                {
                    // Set data characteristics - Data bits, Stop bits, Parity
                    ftStatus = myFtdiDevice.SetDataCharacteristics(FTDI.FT_DATA_BITS.FT_BITS_8, FTDI.FT_STOP_BITS.FT_STOP_BITS_1, FTDI.FT_PARITY.FT_PARITY_NONE);
                    if (ftStatus == FTDI.FT_STATUS.FT_OK)
                    {
                        ftStatus = myFtdiDevice.SetFlowControl(FTDI.FT_FLOW_CONTROL.FT_FLOW_RTS_CTS, 0x11, 0x13);
                        if (ftStatus == FTDI.FT_STATUS.FT_OK)
                        {
                            ftStatus = myFtdiDevice.SetTimeouts(5000, 0);
                            if (ftStatus == FTDI.FT_STATUS.FT_OK)
                            {
                                ftStatus = myFtdiDevice.SetLatency(2);
                                if (ftStatus != FTDI.FT_STATUS.FT_OK)
                                return null;
                            }
                        }
                    }
                }
            }
            return myFtdiDevice;
        }

        public static byte ReadByte(FTDI sr)
        {
            UInt32 bytesRead = 0;
            byte[] t_data = new byte[1];
            sr.Read(t_data, 1, ref bytesRead);
            return t_data[0];
        }

        public void WriteByte(FTDI sr, byte dat)
        {
            UInt32 bytesWritten = 0;
            byte[] data = new byte[1];
            data[0] = dat;
            sr.Write(data, 1, ref bytesWritten);
        }

        public void read(FTDI sr)
        {
            //m_Data.ReadHeaderAndCheckCounter(sr); // Now performed in readData (below)
            m_Data.readData(sr, m_Channel, m_SampleRate, m_Resolution, m_PreAmpGain, m_RefVoltage, m_Alpha);
        }

        public void resetDataLoss()
        {
            m_Data.resetDataLoss();
        }

        private DataBlock m_Data;

        public DataBlock Data
        {
            get { return m_Data; }
        }

        private byte SetCommand1()//Set 3-byte command
        {
            int R, X;

            if (m_Resolution == 24)
                R = 0;
            else
                R = 1;

            X = (int)Math.Log(m_SampleRate, 2);

            return (byte)((R << 4) + X);
        }

        private byte SetCommand2()//Set 4-byte command
        {
            int G, Y;

            if (m_Gain == 6) // Correction for the non-contiguous gain parameters
                G = 0;
            else if (m_Gain == 8)
                G = 5;
            else if (m_Gain == 12)
                G = 6;
            else
                G = m_Gain;

            Y = (int)Math.Log(m_Channel, 2);

            return (byte)((G << 4) + Y);
        }

        public void Start(FTDI sr)
        {
            if (sr != null)
            {
                sr.Purge(FTDI.FT_PURGE.FT_PURGE_RX);
                sr.Purge(FTDI.FT_PURGE.FT_PURGE_TX);
            }
        }

        public void Stop(FTDI sr)
        {
            if (sr != null)
            {
                sr.Purge(FTDI.FT_PURGE.FT_PURGE_RX);
                sr.Purge(FTDI.FT_PURGE.FT_PURGE_TX);
                sr.Close();
            }
        }

        public void Restart(FTDI sr)
        {
            sr.Purge(FTDI.FT_PURGE.FT_PURGE_RX);
            sr.Purge(FTDI.FT_PURGE.FT_PURGE_TX);
        }

        public void ChangeGain(FTDI sr)//Change the Gain
        {
            //byte[] gainCmd = { 0xFE, 0x02, SetCommand1(), SetCommand2(), 0xFF };
            //sr.Write(gainCmd, 0, 5);
            ////sr.Flush();
        }

        public void EnableImpedanceCheck(FTDI sr)
        {
            Byte command = 0x11;
            WriteByte(sr, command);
        }

        public void DisableImpedanceCheck(FTDI sr)
        {
            Byte command = 0x12;
            WriteByte(sr, command);
        }

        public void ChangeNotch(FTDI sr, bool NotchState) //Notch Filter ON/OFF
        {
            if (NotchState == true)//ON
            {
                Byte command = 0x11;
                WriteByte(sr, command);
            }
            else //OFF
            {
                Byte command = 0x12;
                WriteByte(sr, command);
            }
        }

        public void uploadEvent(FTDI sr, int eventcode)
        {
        }

        public int Gain
        {
            set { m_Gain = value; }
            get { return m_Gain; }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWS.Brainwave.HeadsetStatus
{
    public static class DCblock
    {
        public static double[] previousinput = { 0, 0, 0, 0 };
        public static double[] previousoutput = { 0, 0, 0, 0 };

        public static double DCremove(int channel, double input, double alpha)
        {
            double output = input - previousinput[channel] + (alpha * previousoutput[channel]);
            previousinput[channel] = input;
            previousoutput[channel] = output;
            return output;
        }
    }
}

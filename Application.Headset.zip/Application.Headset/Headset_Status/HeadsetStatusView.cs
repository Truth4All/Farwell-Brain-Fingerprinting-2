﻿using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using FTD2XX_NET;

namespace BWS.Brainwave.HeadsetStatus
{
    public partial class HeadsetStatusView : Form
    {
        private Thread btThread;
        // Set initial value of relevant variables
        public static EEGStream ms;

        private int Channels = 4;
        private int SamplingRate = 500;
        private int Resolution = 24;

        private int Gain = 1;
        private int DisplayTime = 4000; // in mS
        private int PreAmpGain = 1; // integer of front-end gain
        private float RefVoltage = 1.33f; // float value of the reference voltage (2.33)

        private double[] currentData;
        private float[] offsetData;
        public string btAddress;
        public static FTDI sr;
        private float[] Vmax;
        private float[] Vmin;


        public HeadsetStatusView(string DeviceAddress)
        {
            this.btAddress = DeviceAddress;
            InitializeComponent();
        }

        private void HeadsetStatus_Load(object sender, EventArgs e)
        {
            sr = null;
            currentData = new double[Channels]; // New array for holding the capture data

            // Search Bluetooth Thread
            btThread = new Thread(new ThreadStart(this.ReceiveSignalAndDraw_));
            btThread.IsBackground = true;
            btThread.Start();
        }

        private void ReceiveSignalAndDraw_()
        {
            try
            {
                // Setup the EEG Stream configuration
                ms = new EEGStream(Channels, SamplingRate, Resolution, Gain, PreAmpGain, RefVoltage, 0.995);

                string HeadsetOn = "Make sure the headset is turn on, or configured properly";

                sr = ms.connectBT(btAddress, HeadsetOn);
                if (sr == null)
                {
                    this.Close();
                }

                // Setup the EEGwage display and start EEG stream
                EEGwave.setting(Channels, SamplingRate, Resolution, Gain, DisplayTime, false);

                ms.Start(sr);

                while (sr != null)
                {
                    ms.read(sr);

                    for (int j = 0; j < Channels; j++)
                    {
                        currentData[j] = ms.Data[j]; // Offset compensation removed
                    }

                    //draw raw data
                    EEGwave.Draw(currentData);
                }
            }
            catch (Exception)
            {
                //TopMostMessageBox.Show("Error occured while drawing the Graph");
                //MessageBox.Show("Error occured while drawing the Graph");
                //this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ms.Stop(sr);
            this.Close();
        }
    }
}

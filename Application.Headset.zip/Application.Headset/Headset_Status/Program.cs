﻿using System;
using System.Windows.Forms;


namespace BWS.Brainwave.HeadsetStatus
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            string btnAddress = args[0].ToString();
            //string btnAddress = "AL224JRQ";

            Application.SetCompatibleTextRenderingDefault(false);
            Application.EnableVisualStyles();
            Application.Run(new HeadsetStatusView(btnAddress));
        }
    }
}
